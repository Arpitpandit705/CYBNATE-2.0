with open('app/src/main/java/com/example/ui/screens/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Add argument
if "onNavigateToVoiceEnrollment: () -> Unit" not in content:
    content = content.replace("onResetProgress: () -> Unit\n)", "onResetProgress: () -> Unit,\n    onNavigateToVoiceEnrollment: () -> Unit\n)")

# Add button
btn_code = """
                    // Voice Biometric Enrollment Button
                    Button(
                        onClick = onNavigateToVoiceEnrollment,
                        colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = CybNateGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ENROLL VOICE BIOMETRIC", color = CybNateGreen, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
"""
if "ENROLL VOICE BIOMETRIC" not in content:
    content = content.replace("                    // Test Voice Mic Activation Button", btn_code + "                    // Test Voice Mic Activation Button")

with open('app/src/main/java/com/example/ui/screens/SettingsScreen.kt', 'w') as f:
    f.write(content)
