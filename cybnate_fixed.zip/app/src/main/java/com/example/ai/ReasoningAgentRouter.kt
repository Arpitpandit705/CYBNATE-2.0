package com.example.ai

import android.content.Context
import android.util.Log

/**
 * Inspired by awesome-llm-apps (https://github.com/Shubhamsaboo/awesome-llm-apps):
 * "Reasoning Agents" (Chain-of-Thought) and "Agent with Database & Intent Routing".
 *
 * Provides structured multi-step reasoning for complex JEE STEM questions
 * and intelligent routing between specialized sub-agents.
 */
object ReasoningAgentRouter {
    private const val TAG = "ReasoningAgentRouter"

    enum class QueryIntent {
        MATH_PHYSICS_PROBLEM,
        STUDY_SCHEDULE_PACE,
        REVISION_FLASHCARD,
        SYSTEM_ACTION,
        GENERAL_COACH
    }

    /**
     * Autonomous Intent Router: Classifies student requests into optimal processing channels.
     */
    fun classifyIntent(query: String): QueryIntent {
        val q = query.lowercase()

        // 1. System actions
        if (q.contains("flashlight") || q.contains("torch") || q.contains("battery") ||
            q.contains("volume") || q.contains("open youtube") || q.contains("open camera") ||
            q.contains("open whatsapp") || q.contains("open settings")) {
            return QueryIntent.SYSTEM_ACTION
        }

        // 2. Schedule & Pace
        if (q.contains("pace") || q.contains("deadline") || q.contains("schedule") ||
            q.contains("how many lecture") || q.contains("behind") || q.contains("streak") ||
            q.contains("syllabus") || q.contains("backlog")) {
            return QueryIntent.STUDY_SCHEDULE_PACE
        }

        // 3. Flashcards / Active Quiz
        if (q.contains("quiz me") || q.contains("test my") || q.contains("ask me a question") ||
            q.contains("flashcard") || q.contains("formula test")) {
            return QueryIntent.REVISION_FLASHCARD
        }

        // 4. STEM Problem Solving (Physics, Math, Chem)
        if (q.contains("solve") || q.contains("calculate") || q.contains("derive") ||
            q.contains("find the") || q.contains("velocity") || q.contains("integral") ||
            q.contains("force") || q.contains("electric") || q.contains("magnetic") ||
            q.contains("hybridization") || q.contains("equilibrium") || q.contains("matrix")) {
            return QueryIntent.MATH_PHYSICS_PROBLEM
        }

        return QueryIntent.GENERAL_COACH
    }

    /**
     * Builds Chain-of-Thought (CoT) system prompt template based on awesome-llm-apps Reasoning pattern.
     */
    fun buildReasoningSystemPrompt(context: Context, basePrompt: String): String {
        val memoryContext = StudentMemoryEngine.buildMemoryPromptContext(context)
        val reasoningEnabled = StudentMemoryEngine.isReasoningModeEnabled(context)

        return buildString {
            appendLine(basePrompt)
            appendLine()
            if (memoryContext.isNotBlank()) {
                appendLine(memoryContext)
                appendLine()
            }

            if (reasoningEnabled) {
                appendLine("=== DEEP MULTI-STEP REASONING PROTOCOL (awesome-llm-apps) ===")
                appendLine("For all technical, physics, chemistry, and mathematics questions:")
                appendLine("1. 🎯 GIVEN & OBJECTIVE: State what is given and exactly what must be found.")
                appendLine("2. 📐 CORE CONCEPT: Identify governing physical laws / mathematical theorems.")
                appendLine("3. 🧮 STEP-BY-STEP DERIVATION: Write clear, clean mathematical transitions.")
                appendLine("4. ⚠️ JEE EXAM TRAP: Highlight common negative marking errors (-1 traps).")
                appendLine("5. 💡 VERIFICATION: Provide a 5-second dimensional or boundary-value sanity check.")
                appendLine("Format clearly with bold headings and clean visual spacing.")
            }
        }
    }

    /**
     * Generates an instant active recall flashcard drill question based on active subject.
     */
    fun generateQuickRecallDrill(subject: String, chapterName: String): String {
        return when (subject.uppercase()) {
            "PHYSICS" -> "⚡ Quick JEE Drill ($chapterName):\n\n" +
                    "Question: In uniform circular motion of radius R with speed v, what is the work done by the centripetal force over half a revolution?\n\n" +
                    "A) 2mv²\nB) 0 Joules\nC) πmv²\nD) mv²\n\n" +
                    "👉 Say or type your answer to verify!"

            "MATHEMATICS" -> "📐 Quick JEE Drill ($chapterName):\n\n" +
                    "Question: Evaluate the limit: lim(x→0) [sin(5x) / tan(2x)]\n\n" +
                    "A) 1\nB) 2/5\nC) 5/2\nD) 0\n\n" +
                    "👉 Say or type your answer to verify!"

            "INORGANIC_CHEMISTRY", "CHEMISTRY" -> "🧪 Quick JEE Drill ($chapterName):\n\n" +
                    "Question: Which of the following species has square planar geometry according to VSEPR theory?\n\n" +
                    "A) NH₄⁺\nB) XeF₄\nC) SF₄\nD) BF₄⁻\n\n" +
                    "👉 Say or type your answer to verify!"

            else -> "🎯 Quick JEE Drill ($chapterName):\n\n" +
                    "State the fundamental condition for maximum range in projectile motion on horizontal ground, assuming no air resistance.\n\n" +
                    "👉 Reply with your formula or answer!"
        }
    }
}
