package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiPart(val text: String? = null)

@JsonClass(generateAdapter = true)
data class GeminiContent(val parts: List<GeminiPart>?)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    val responseMimeType: String? = "application/json",
    val temperature: Float? = 0.2f
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val generationConfig: GeminiGenerationConfig? = GeminiGenerationConfig()
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(val content: GeminiContent?)

@JsonClass(generateAdapter = true)
data class GeminiResponse(val candidates: List<GeminiCandidate>?)

@JsonClass(generateAdapter = true)
data class AiStudyCoachStructuredResponse(
    val answer: String = "",
    val actionableGuidance: List<String> = emptyList(),
    val statusBadge: String? = null,
    val subjectContext: String? = null
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): Response<GeminiResponse>
}

object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val loggingInterceptor = HttpLoggingInterceptor { message ->
        Log.d("GeminiApiClient", message)
    }.apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApi::class.java)
    }

    suspend fun askGeminiStructured(prompt: String): AiStudyCoachStructuredResponse? = withContext(Dispatchers.IO) {
        val apiKey = try {
            val k1 = BuildConfig.GEMINI_API_KEY
            val k2 = BuildConfig.GEMINI_API_KEY2
            if (k1.isNotBlank() && k1 != "MY_GEMINI_API_KEY") k1
            else if (k2.isNotBlank() && k2 != "MY_GEMINI_API_KEY") k2
            else ""
        } catch (e: Throwable) {
            Log.e("GeminiApiClient", "Error reading BuildConfig key: ${e.message}")
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("GeminiApiClient", "Gemini API key is missing or placeholder")
            return@withContext null
        }

        try {
            val req = GeminiRequest(
                contents = listOf(
                    GeminiContent(parts = listOf(GeminiPart(text = prompt)))
                ),
                generationConfig = GeminiGenerationConfig(
                    responseMimeType = "application/json",
                    temperature = 0.2f
                )
            )
            Log.d("GeminiApiClient", "Sending structured prompt: ${prompt.take(60)}...")
            val response = api.generateContent(apiKey, req)

            if (!response.isSuccessful) {
                val errorBody = response.errorBody()?.string()
                Log.e("GeminiApiClient", "HTTP Error ${response.code()}: $errorBody")
                return@withContext null
            }

            val body = response.body()
            val jsonText = body?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText.isNullOrBlank()) {
                Log.w("GeminiApiClient", "Empty candidate response received from Gemini")
                return@withContext null
            }

            Log.d("GeminiApiClient", "Received JSON: ${jsonText.take(100)}...")

            // Parse structured JSON response
            try {
                val adapter = moshi.adapter(AiStudyCoachStructuredResponse::class.java)
                val cleanJson = jsonText.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                adapter.fromJson(cleanJson)
            } catch (jsonEx: Exception) {
                Log.e("GeminiApiClient", "Failed to parse structured JSON: ${jsonEx.message}. Falling back to plain text answer.", jsonEx)
                AiStudyCoachStructuredResponse(answer = jsonText.trim())
            }
        } catch (e: Exception) {
            Log.e("GeminiApiClient", "Gemini API call network/runtime failure: ${e.message}", e)
            null
        }
    }

    suspend fun askGemini(prompt: String): String? = withContext(Dispatchers.IO) {
        val structured = askGeminiStructured(prompt)
        structured?.let {
            val sb = StringBuilder()
            if (it.answer.isNotBlank()) {
                sb.append(it.answer)
            }
            if (it.actionableGuidance.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append("\n\nAction Steps:\n")
                it.actionableGuidance.forEach { step ->
                    sb.append("• ").append(step).append("\n")
                }
            }
            sb.toString().trim()
        }
    }
}
