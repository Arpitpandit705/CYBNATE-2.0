package com.example.ai

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Configuration manager for Hugging Face speech-to-speech integration.
 * Repository: https://github.com/huggingface/speech-to-speech
 */
object HfSpeechToSpeechConfig {
    private const val PREFS_NAME = "cyb_hf_speech_to_speech"
    private const val KEY_ENABLED = "hf_s2s_enabled"
    private const val KEY_SERVER_URL = "hf_server_url"
    private const val KEY_HF_TOKEN = "hf_token"
    private const val KEY_MODEL = "hf_model"

    const val DEFAULT_SERVER_URL = "wss://huggingface-speech-to-speech.hf.space/ws"
    const val DEFAULT_MODEL = "huggingface/speech-to-speech"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_ENABLED, false)
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun getServerUrl(context: Context): String {
        return getPrefs(context).getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
    }

    fun setServerUrl(context: Context, url: String) {
        getPrefs(context).edit().putString(KEY_SERVER_URL, url.trim()).apply()
    }

    fun getHfToken(context: Context): String {
        return getPrefs(context).getString(KEY_HF_TOKEN, "") ?: ""
    }

    fun setHfToken(context: Context, token: String) {
        getPrefs(context).edit().putString(KEY_HF_TOKEN, token.trim()).apply()
    }

    fun getModel(context: Context): String {
        return getPrefs(context).getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
    }

    fun setModel(context: Context, model: String) {
        getPrefs(context).edit().putString(KEY_MODEL, model.trim()).apply()
    }
}

/**
 * Client for communicating with Hugging Face speech-to-speech pipeline
 * (https://github.com/huggingface/speech-to-speech) over WebSocket and HTTP.
 */
object HfSpeechToSpeechClient {
    private const val TAG = "HfSpeechToSpeechClient"

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Test connection to the Hugging Face speech-to-speech server.
     */
    suspend fun testConnection(serverUrl: String, token: String): Result<String> = withContext(Dispatchers.IO) {
        return@withContext try {
            val cleanUrl = serverUrl.trim()
            if (cleanUrl.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("Server URL cannot be empty"))
            }

            if (cleanUrl.startsWith("ws://") || cleanUrl.startsWith("wss://")) {
                // Test WebSocket handshake
                val requestBuilder = Request.Builder().url(cleanUrl)
                if (token.isNotBlank()) {
                    requestBuilder.addHeader("Authorization", "Bearer $token")
                }

                var connectionSuccess = false
                var errorMsg = ""
                val latch = java.util.concurrent.CountDownLatch(1)

                val ws = okHttpClient.newWebSocket(requestBuilder.build(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        connectionSuccess = true
                        webSocket.close(1000, "Connection test successful")
                        latch.countDown()
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        errorMsg = t.message ?: "Handshake failed"
                        latch.countDown()
                    }
                })

                val completed = latch.await(6, TimeUnit.SECONDS)
                if (!completed) {
                    ws.cancel()
                    Result.failure(Exception("Connection timed out after 6 seconds"))
                } else if (connectionSuccess) {
                    Result.success("Connected to Hugging Face S2S server successfully!")
                } else {
                    Result.failure(Exception("Connection failed: $errorMsg"))
                }
            } else {
                // Test HTTP endpoint
                val httpUrl = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                    "https://$cleanUrl"
                } else cleanUrl

                val requestBuilder = Request.Builder().url(httpUrl)
                if (token.isNotBlank()) {
                    requestBuilder.addHeader("Authorization", "Bearer $token")
                }

                val response = okHttpClient.newCall(requestBuilder.build()).execute()
                if (response.isSuccessful || response.code in 200..399) {
                    Result.success("Connected to Hugging Face server (HTTP ${response.code})")
                } else {
                    Result.failure(Exception("HTTP error ${response.code}: ${response.message}"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Connection test failed", e)
            Result.failure(e)
        }
    }

    /**
     * Sends voice query text to Hugging Face speech-to-speech / LLM pipeline
     * and returns the generated text response.
     */
    suspend fun querySpeechPipeline(
        context: Context,
        query: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val serverUrl = HfSpeechToSpeechConfig.getServerUrl(context)
        val token = HfSpeechToSpeechConfig.getHfToken(context)

        try {
            // First try WebSocket OpenAI Realtime format
            if (serverUrl.startsWith("ws://") || serverUrl.startsWith("wss://")) {
                val wsResult = queryViaWebSocket(serverUrl, token, query)
                if (wsResult.isSuccess) return@withContext wsResult
            }

            // Fallback: Hugging Face Inference API / HTTP chat completions
            return@withContext queryViaHfInferenceApi(token, query)
        } catch (e: Exception) {
            Log.e(TAG, "Error in querySpeechPipeline", e)
            Result.failure(e)
        }
    }

    private suspend fun queryViaWebSocket(
        serverUrl: String,
        token: String,
        query: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val latch = java.util.concurrent.CountDownLatch(1)
        var responseText = ""
        var errorMsg = ""

        val requestBuilder = Request.Builder().url(serverUrl)
        if (token.isNotBlank()) {
            requestBuilder.addHeader("Authorization", "Bearer $token")
        }

        val ws = okHttpClient.newWebSocket(requestBuilder.build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                // Send query in OpenAI Realtime / HF speech-to-speech format
                val eventJson = JSONObject().apply {
                    put("type", "conversation.item.create")
                    put("item", JSONObject().apply {
                        put("type", "message")
                        put("role", "user")
                        put("content", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("type", "input_text")
                                put("text", query)
                            })
                        })
                    })
                }
                webSocket.send(eventJson.toString())

                // Trigger generation response
                val responseCreate = JSONObject().apply {
                    put("type", "response.create")
                }
                webSocket.send(responseCreate.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    val type = json.optString("type")
                    if (type == "response.text.delta" || type == "response.audio_transcript.delta") {
                        val delta = json.optString("delta")
                        responseText += delta
                    } else if (type == "response.text.done" || type == "response.audio_transcript.done") {
                        val transcript = json.optString("transcript")
                        if (transcript.isNotBlank()) responseText = transcript
                        webSocket.close(1000, "Done")
                        latch.countDown()
                    } else if (type == "response.done") {
                        webSocket.close(1000, "Done")
                        latch.countDown()
                    }
                } catch (e: Exception) {
                    // Raw text response fallback
                    if (responseText.isBlank()) responseText = text
                    latch.countDown()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                errorMsg = t.message ?: "WebSocket failure"
                latch.countDown()
            }
        })

        val completed = latch.await(12, TimeUnit.SECONDS)
        if (!completed) {
            ws.cancel()
            return@withContext Result.failure(Exception("WebSocket query timed out"))
        }

        if (responseText.isNotBlank()) {
            Result.success(responseText.trim())
        } else if (errorMsg.isNotBlank()) {
            Result.failure(Exception(errorMsg))
        } else {
            Result.failure(Exception("No response received from speech-to-speech pipeline"))
        }
    }

    private suspend fun queryViaHfInferenceApi(
        token: String,
        query: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val hfUrl = "https://api-inference.huggingface.co/models/Qwen/Qwen2.5-Coder-7B-Instruct/v1/chat/completions"
            val payload = JSONObject().apply {
                put("model", "Qwen/Qwen2.5-Coder-7B-Instruct")
                put("messages", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "system")
                        put("content", "You are CybNate, powered by Hugging Face Speech-to-Speech pipeline. Give concise, intelligent, encouraging answers for JEE students.")
                    })
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", query)
                    })
                })
                put("max_tokens", 300)
            }

            val mediaType = "application/json".toMediaTypeOrNull()
            val requestBody = payload.toString().toRequestBody(mediaType)
            val requestBuilder = Request.Builder()
                .url(hfUrl)
                .post(requestBody)

            if (token.isNotBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = okHttpClient.newCall(requestBuilder.build()).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                val json = JSONObject(body)
                val choices = json.optJSONArray("choices")
                val content = choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                if (!content.isNullOrBlank()) {
                    return@withContext Result.success(content.trim())
                }
            }
            Result.failure(Exception("Hugging Face API returned code ${response.code}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
