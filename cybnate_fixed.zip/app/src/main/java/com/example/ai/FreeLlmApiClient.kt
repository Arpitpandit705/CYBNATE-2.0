package com.example.ai

import android.util.Log
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class OpenAiChatMessage(
    val role: String = "user",
    val content: String
)

@JsonClass(generateAdapter = true)
data class OpenAiChatRequest(
    val model: String = "llama-3.3-70b-versatile",
    val messages: List<OpenAiChatMessage>,
    val temperature: Float = 0.2f
)

@JsonClass(generateAdapter = true)
data class OpenAiChoiceMessage(
    val role: String? = null,
    val content: String? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiChoice(
    val message: OpenAiChoiceMessage? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiChatResponse(
    val choices: List<OpenAiChoice>? = null
)

interface FreeLlmApi {
    @POST
    suspend fun chatCompletions(
        @Url url: String,
        @Header("Authorization") authorization: String,
        @Body request: OpenAiChatRequest
    ): Response<OpenAiChatResponse>
}

/**
 * Client capable of making API requests to any free OpenAI-compatible LLM provider
 * featured in open-free-llm-api/awesome-freellm-apis (e.g. Groq, OpenRouter, Together AI, DeepSeek, Cerebras, etc.)
 */
object FreeLlmApiClient {
    private const val TAG = "FreeLlmApiClient"

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val api: FreeLlmApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.groq.com/") // Base URL placeholder; dynamic full URL used in Retrofit call
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(FreeLlmApi::class.java)
    }

    // Popular Free LLM Providers from awesome-freellm-apis
    val GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
    val OPENROUTER_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"
    val TOGETHER_ENDPOINT = "https://api.together.xyz/v1/chat/completions"
    val DEEPSEEK_ENDPOINT = "https://api.deepseek.com/v1/chat/completions"

    suspend fun askFreeLlm(
        prompt: String,
        apiKey: String,
        endpointUrl: String = GROQ_ENDPOINT,
        modelName: String = "llama-3.3-70b-versatile"
    ): String? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            Log.w(TAG, "API key is empty")
            return@withContext null
        }

        try {
            val authHeader = if (apiKey.startsWith("Bearer ")) apiKey else "Bearer $apiKey"
            val req = OpenAiChatRequest(
                model = modelName,
                messages = listOf(OpenAiChatMessage(role = "user", content = prompt)),
                temperature = 0.2f
            )

            Log.d(TAG, "Calling Free LLM endpoint $endpointUrl with model $modelName...")
            val response = api.chatCompletions(endpointUrl, authHeader, req)

            if (!response.isSuccessful) {
                Log.e(TAG, "HTTP error ${response.code()}: ${response.errorBody()?.string()}")
                return@withContext null
            }

            val reply = response.body()?.choices?.firstOrNull()?.message?.content
            Log.d(TAG, "Received response length: ${reply?.length ?: 0}")
            reply
        } catch (e: Exception) {
            Log.e(TAG, "Error communicating with Free LLM API ($endpointUrl): ${e.message}", e)
            null
        }
    }
}
