package com.example.ai

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import org.json.JSONArray

/**
 * Inspired by awesome-llm-apps (https://github.com/Shubhamsaboo/awesome-llm-apps):
 * "AI Agent with Personalized Memory" & "Autonomous Memory Pipeline".
 *
 * Stores and manages long-term student memory, weak topic tracking,
 * learning preferences, and exam targets to provide contextual, hyper-personalized answers.
 */
object StudentMemoryEngine {
    private const val TAG = "StudentMemoryEngine"
    private const val PREFS_NAME = "cyb_student_memory_prefs"
    private const val KEY_MEMORIES = "student_memories_list"
    private const val KEY_REASONING_MODE = "reasoning_mode_enabled"

    private val DEFAULT_MEMORIES = listOf(
        "Exam Target: JEE Main & JEE Advanced 2026",
        "Syllabus Protocol: Strict chapter sequence (Organic unlocked after Physical/Inorganic)",
        "Study Target: 5 lectures/day at 1.25x speed (96 minutes/lecture)"
    )

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Retrieves all stored personalized student memories.
     */
    fun getMemories(context: Context): List<String> {
        val prefs = getPrefs(context)
        val raw = prefs.getString(KEY_MEMORIES, null) ?: return DEFAULT_MEMORIES
        return try {
            val jsonArray = JSONArray(raw)
            val list = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
            if (list.isEmpty()) DEFAULT_MEMORIES else list
        } catch (e: Exception) {
            DEFAULT_MEMORIES
        }
    }

    /**
     * Adds a new memory item to the persistent memory store.
     */
    fun addMemory(context: Context, memory: String) {
        val trimmed = memory.trim()
        if (trimmed.isBlank()) return

        val current = getMemories(context).toMutableList()
        if (!current.contains(trimmed)) {
            current.add(0, trimmed)
            saveMemories(context, current)
            Log.d(TAG, "Added memory: $trimmed")
        }
    }

    /**
     * Removes a specific memory item.
     */
    fun removeMemory(context: Context, memory: String) {
        val current = getMemories(context).toMutableList()
        if (current.remove(memory)) {
            saveMemories(context, current)
            Log.d(TAG, "Removed memory: $memory")
        }
    }

    /**
     * Clears and resets memories back to default.
     */
    fun resetMemories(context: Context) {
        saveMemories(context, DEFAULT_MEMORIES)
    }

    private fun saveMemories(context: Context, list: List<String>) {
        val jsonArray = JSONArray()
        list.take(25).forEach { jsonArray.put(it) } // Keep top 25 high-priority memories
        getPrefs(context).edit().putString(KEY_MEMORIES, jsonArray.toString()).apply()
    }

    /**
     * Checks whether Deep Multi-Step Reasoning Mode (Chain-of-Thought) is active.
     */
    fun isReasoningModeEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_REASONING_MODE, true)
    }

    fun setReasoningModeEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_REASONING_MODE, enabled).apply()
    }

    /**
     * Automatically extracts weak spots, student goals, or study habits from user input
     * and updates memory (Autonomous Memory Agent pattern).
     */
    fun autoExtractMemory(context: Context, userQuery: String) {
        val q = userQuery.lowercase()
        when {
            q.contains("i am weak in") || q.contains("i struggle with") || q.contains("confused about") -> {
                val topic = extractSubjectTopic(userQuery)
                if (topic != null) {
                    addMemory(context, "Weakness Area: Student struggles with $topic. Give extra foundational intuition.")
                }
            }
            q.contains("my target is") || q.contains("aiming for") || q.contains("target rank") -> {
                addMemory(context, "Goal: \"${userQuery.take(80)}\"")
            }
            q.contains("prefer formula") || q.contains("shortcuts only") -> {
                addMemory(context, "Preference: Prefers quick formulas and speed shortcuts.")
            }
            q.contains("explain from basics") || q.contains("zero level") -> {
                addMemory(context, "Preference: Explain from zero level / first principles.")
            }
        }
    }

    private fun extractSubjectTopic(text: String): String? {
        val lower = text.lowercase()
        val keywords = listOf(
            "rotational", "mechanics", "thermo", "optics", "calculus",
            "integration", "vectors", "chemical bonding", "coordination",
            "organic", "electrostatics", "current electricity", "probability"
        )
        for (kw in keywords) {
            if (lower.contains(kw)) return kw.replaceFirstChar { it.uppercase() }
        }
        return null
    }

    /**
     * Builds memory context block for injection into prompt.
     */
    fun buildMemoryPromptContext(context: Context): String {
        val memories = getMemories(context)
        if (memories.isEmpty()) return ""
        return buildString {
            appendLine("=== AGENTIC STUDENT MEMORY (Personalized Profile) ===")
            memories.take(8).forEach { appendLine("• $it") }
        }
    }
}
