package com.example.ai

import com.example.data.UserStatsEntity
import org.json.JSONObject

data class FocusTelemetry(
    val subject: String,
    val chapterName: String,
    val taskType: String,
    val itemIndex: Int,
    val sessionDurationMinutes: Int,
    val targetDurationMinutes: Int = 96,
    val playbackSpeed: Float = 1.25f,
    val learningAppUsagePercent: Float = 0.90f,
    val distractionAttempts: Int = 0,
    val optInScreenMonitoring: Boolean = true
)

data class AiVerificationDecision(
    val status: String, // "VERIFIED", "NEEDS_CONFIRMATION", "FAILED_VERIFICATION"
    val confidence: Float, // 0.0f to 1.0f
    val reason: String,
    val recommendedAction: String // "COMPLETE_LECTURE", "RETRY_LECTURE", "FLAG_FOR_REVIEW"
)

object LectureVerificationEngine {

    suspend fun evaluateLectureCompletion(
        telemetry: FocusTelemetry,
        userStats: UserStatsEntity
    ): AiVerificationDecision {
        val prompt = """
            System Instruction: You are CybNate AI Verification Engine for JEE Study.
            Analyze the following study session telemetry and determine if the lecture completion should be verified.
            
            Telemetry Data:
            - Subject: ${telemetry.subject}
            - Chapter: ${telemetry.chapterName}
            - Task: ${telemetry.taskType} ${telemetry.itemIndex}
            - Target Duration: ${telemetry.targetDurationMinutes} minutes (2 hr lecture at ${telemetry.playbackSpeed}x playback speed)
            - Actual Session Duration: ${telemetry.sessionDurationMinutes} minutes
            - Learning App Usage: ${(telemetry.learningAppUsagePercent * 100).toInt()}%
            - Distraction Attempts: ${telemetry.distractionAttempts}
            - Opt-In Focus Verification: ${telemetry.optInScreenMonitoring}
            
            Return STRICT JSON only matching this exact format:
            {
              "status": "VERIFIED",
              "confidence": 0.92,
              "reason": "Clear session duration and minimal distraction attempts.",
              "recommendedAction": "COMPLETE_LECTURE"
            }
            
            Valid status options: "VERIFIED", "NEEDS_CONFIRMATION", "FAILED_VERIFICATION".
            Valid recommendedAction options: "COMPLETE_LECTURE", "RETRY_LECTURE", "FLAG_FOR_REVIEW".
        """.trimIndent()

        val rawResponse = GeminiApiClient.askGemini(prompt)

        if (!rawResponse.isNullOrBlank()) {
            try {
                // Extract JSON block if needed
                val cleanJson = rawResponse.substringAfter("{").substringBeforeLast("}")
                val json = JSONObject("{$cleanJson}")
                return AiVerificationDecision(
                    status = json.optString("status", "VERIFIED"),
                    confidence = json.optDouble("confidence", 0.90).toFloat(),
                    reason = json.optString("reason", "Verified by CybNate AI Intelligence."),
                    recommendedAction = json.optString("recommendedAction", "COMPLETE_LECTURE")
                )
            } catch (e: Exception) {
                // Fallback to deterministic validation
            }
        }

        // Fallback Deterministic Engine
        val isVerified = telemetry.sessionDurationMinutes >= 15 && telemetry.distractionAttempts <= 3
        return if (isVerified) {
            AiVerificationDecision(
                status = "VERIFIED",
                confidence = 0.95f,
                reason = "Focus threshold met (${telemetry.sessionDurationMinutes} mins, ${telemetry.distractionAttempts} distraction attempts).",
                recommendedAction = "COMPLETE_LECTURE"
            )
        } else {
            AiVerificationDecision(
                status = "NEEDS_CONFIRMATION",
                confidence = 0.60f,
                reason = "Short session duration (${telemetry.sessionDurationMinutes} mins). Extra review suggested.",
                recommendedAction = "RETRY_LECTURE"
            )
        }
    }
}
