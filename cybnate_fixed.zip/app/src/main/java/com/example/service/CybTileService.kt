package com.example.service

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class CybTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()
        val tile = qsTile ?: return
        val isCurrentlyActive = tile.state == Tile.STATE_ACTIVE

        if (isCurrentlyActive) {
            CybFloatingIslandService.stop(this)
        } else {
            CybFloatingIslandService.start(this)
        }
        // Refresh immediately from the new desired state; onStartListening/onClick
        // will reconcile again when the service actually starts or stops.
        setTile(!isCurrentlyActive)
    }

    private fun updateTileState() {
        // Reflect the real running state of the island instead of always "Listening".
        setTile(CybFloatingIslandService.isRunning)
    }

    private fun setTile(active: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "CybNate AI"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (active) "Listening" else "CybNate Off"
        }
        tile.updateTile()
    }
}
