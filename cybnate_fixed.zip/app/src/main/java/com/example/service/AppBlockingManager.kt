package com.example.service

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.app.usage.UsageStatsManager

object AppBlockingManager {

    val DEFAULT_BLOCKED_PACKAGES = setOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.google.android.youtube.tv",
        "com.google.android.apps.youtube.kids",
        "com.google.android.apps.youtube.music",
        "com.facebook.katana",
        "com.twitter.android",
        "com.snapchat.android",
        "com.zhiliaoapp.musically", // TikTok
        "com.netflix.mediaclient",
        "com.android.chrome",
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.telegram.messenger",
        "org.telegram.messenger",
        "com.discord",
        "com.reddit.frontpage",
        "com.spotify.music",
        "com.tencent.mm",
        "com.ss.android.ugc.trill",
        "tv.twitch.android.app"
    )

    private const val PREFS_NAME = "cybnate_lock_prefs"
    private const val KEY_FOCUS_ACTIVE = "key_focus_session_active"
    private const val KEY_BLOCKED_PACKAGES = "key_custom_blocked_packages"
    private const val KEY_PRIMARY_LEARNING_APP = "key_primary_learning_app"

    fun getCustomBlockedPackages(context: Context): Set<String> {
        return try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.getStringSet(KEY_BLOCKED_PACKAGES, DEFAULT_BLOCKED_PACKAGES) ?: DEFAULT_BLOCKED_PACKAGES
        } catch (e: Exception) {
            DEFAULT_BLOCKED_PACKAGES
        }
    }

    fun saveCustomBlockedPackages(context: Context, packages: Set<String>) {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putStringSet(KEY_BLOCKED_PACKAGES, packages)
                .apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getPrimaryLearningApp(context: Context): String {
        return try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_PRIMARY_LEARNING_APP, "com.physicswallah") ?: "com.physicswallah"
        } catch (e: Exception) {
            "com.physicswallah"
        }
    }

    fun setPrimaryLearningApp(context: Context, pkg: String) {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_PRIMARY_LEARNING_APP, pkg)
                .apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isUsagePermissionGranted(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun isOverlayPermissionGranted(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun isAccessibilityPermissionGranted(context: Context): Boolean {
        val expectedService = "${context.packageName}/${CybNateAccessibilityService::class.java.canonicalName}"
        val altService = "${context.packageName}/${CybNateAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(expectedService) || enabledServices.contains(altService)
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    @Volatile
    var isFocusActiveInMemory: Boolean = false

    fun setFocusSessionActive(context: Context, active: Boolean) {
        isFocusActiveInMemory = active
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_FOCUS_ACTIVE, active)
                .apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isFocusSessionActive(context: Context): Boolean {
        if (isFocusActiveInMemory) return true
        return try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_FOCUS_ACTIVE, false)
        } catch (e: Exception) {
            false
        }
    }

    fun openUsageAccessSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun openOverlaySettings(context: Context) {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun getForegroundAppPackage(context: Context): String? {
        if (!isUsagePermissionGranted(context)) return null
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - 10_000

        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        var lastForegroundPackage: String? = null

        val event = android.app.usage.UsageEvents.Event()
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                lastForegroundPackage = event.packageName
            }
        }
        return lastForegroundPackage
    }

    fun isPackageBlocked(
        packageName: String?,
        currentAppPackage: String,
        primaryLearningAppPackage: String,
        customBlockedPackages: Set<String>
    ): Boolean {
        if (packageName.isNullOrBlank()) return false
        if (packageName == currentAppPackage) return false
        
        // If YouTube or PW is the designated learning app, do not block it
        if (primaryLearningAppPackage.isNotBlank() && (packageName == primaryLearningAppPackage || packageName.contains(primaryLearningAppPackage))) {
            return false
        }
        
        // Always allow system launcher, calculator, keep notes, settings, system UI
        if (packageName.contains("launcher") || packageName.contains("calculator") || packageName.contains("keep") || packageName.contains("settings")) {
            return false
        }

        val activeBlockedList = if (customBlockedPackages.isNotEmpty()) customBlockedPackages else DEFAULT_BLOCKED_PACKAGES

        // Direct package match
        if (activeBlockedList.contains(packageName)) return true

        // Substring matching for YouTube, Instagram, Facebook, TikTok, Netflix, Snapchat
        val lowerPkg = packageName.lowercase()
        return (lowerPkg.contains("youtube") && !primaryLearningAppPackage.contains("youtube")) ||
                lowerPkg.contains("instagram") ||
                lowerPkg.contains("tiktok") ||
                lowerPkg.contains("musically") ||
                lowerPkg.contains("facebook") ||
                lowerPkg.contains("twitter") ||
                lowerPkg.contains("snapchat") ||
                lowerPkg.contains("netflix")
    }
}
