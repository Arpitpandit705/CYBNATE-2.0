package com.example.service

object ScreenContextHolder {
    @Volatile
    var lastCapturedPackageName: String = ""

    @Volatile
    var lastCapturedScreenText: String = ""

    @Volatile
    var lastCapturedTimeMs: Long = 0L

    fun updateScreenContent(packageName: String, text: String) {
        if (text.isBlank()) return
        lastCapturedPackageName = packageName
        lastCapturedScreenText = text
        lastCapturedTimeMs = System.currentTimeMillis()
    }

    fun getFormattedScreenContext(): String {
        if (lastCapturedScreenText.isBlank()) {
            return "No screen content captured yet. (Make sure Accessibility Service is enabled in Android Settings)."
        }
        val ageSeconds = (System.currentTimeMillis() - lastCapturedTimeMs) / 1000
        return """
            [Active Screen Sight - $lastCapturedPackageName ($ageSeconds seconds ago)]
            $lastCapturedScreenText
        """.trimIndent()
    }
}
