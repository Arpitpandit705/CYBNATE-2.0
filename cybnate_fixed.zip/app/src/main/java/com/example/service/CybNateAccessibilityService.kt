package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.MainActivity

class CybNateAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "CybNateAccessibility"
    }

    private val launcherPackages = HashSet<String>()
    private val immunePackages = setOf(
        "android",
        "com.android.systemui",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "com.google.android.inputmethod.latin"
    )

    private var lastBlockedEventTime: Long = 0L

    override fun onCreate() {
        super.onCreate()
        refreshLauncherPackages()
    }

    private fun refreshLauncherPackages() {
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
            }
            val resolveInfos = packageManager.queryIntentActivities(
                intent,
                PackageManager.MATCH_DEFAULT_ONLY
            )
            synchronized(launcherPackages) {
                launcherPackages.clear()
                for (info in resolveInfos) {
                    info.activityInfo?.packageName?.let {
                        launcherPackages.add(it)
                    }
                }
            }
            Log.d(TAG, "Cached ${launcherPackages.size} launcher packages")
        } catch (e: Exception) {
            Log.e(TAG, "Error resolving launcher packages", e)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val eventType = event.eventType
        if (eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && 
            eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            return
        }

        val packageName = event.packageName?.toString() ?: return

        // 1. Capture screen text content for AI Vision continuously
        captureScreenContent(packageName)

        // Never intercept our own app for blocking
        if (packageName == this.packageName) return

        // Check if package is immune (System UI, package installer, launchers)
        val isImmune = immunePackages.contains(packageName) || synchronized(launcherPackages) {
            launcherPackages.contains(packageName)
        }
        if (isImmune) return

        // Verify if a focus study session is currently running
        val hasActiveSession = AppBlockingManager.isFocusSessionActive(this)
        
        // Retrieve user saved custom blocked packages and primary learning app
        val customBlocked = AppBlockingManager.getCustomBlockedPackages(this)
        val primaryApp = AppBlockingManager.getPrimaryLearningApp(this)

        // Check if package is in blocked apps list
        val isBlocked = AppBlockingManager.isPackageBlocked(
            packageName = packageName,
            currentAppPackage = this.packageName,
            primaryLearningAppPackage = primaryApp,
            customBlockedPackages = customBlocked
        )

        Log.d(TAG, "Window event: package=$packageName, hasActiveSession=$hasActiveSession, isBlocked=$isBlocked")

        if (!hasActiveSession) return

        if (isBlocked) {
            val now = System.currentTimeMillis()
            // Debounce within 500ms to avoid spamming intents
            if (now - lastBlockedEventTime < 500) return
            lastBlockedEventTime = now

            Log.w(TAG, "Distracting app detected during Focus Mode: $packageName. Enforcing lock!")

            // 1. Instantly exit the distracting app and route to home
            performGlobalAction(GLOBAL_ACTION_HOME)

            // 2. Summon CybNate intervention lock screen
            try {
                val blockIntent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("SHOW_LOCK_SCREEN", true)
                    putExtra("TRIGGER_DISTRACTION_INTERVENTION", true)
                    putExtra("BLOCKED_PACKAGE", packageName)
                }
                startActivity(blockIntent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to launch lock screen", e)
            }
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility Service onInterrupt called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Accessibility Service destroyed")
    }

    private fun captureScreenContent(packageName: String) {
        try {
            val rootNode = rootInActiveWindow ?: return
            val sb = StringBuilder()
            traverseNodeTree(rootNode, sb, maxChars = 2500)
            rootNode.recycle()
            val extractedText = sb.toString().trim()
            if (extractedText.isNotBlank()) {
                ScreenContextHolder.updateScreenContent(packageName, extractedText)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error capturing screen content", e)
        }
    }

    private fun traverseNodeTree(node: AccessibilityNodeInfo?, sb: StringBuilder, maxChars: Int) {
        if (node == null || sb.length >= maxChars) return
        if (node.isVisibleToUser) {
            val text = node.text?.toString()?.trim()
            val contentDesc = node.contentDescription?.toString()?.trim()
            if (!text.isNullOrBlank()) {
                if (!sb.contains(text)) {
                    sb.append(text).append("\n")
                }
            } else if (!contentDesc.isNullOrBlank()) {
                if (!sb.contains(contentDesc)) {
                    sb.append(contentDesc).append("\n")
                }
            }
        }
        for (i in 0 until node.childCount) {
            if (sb.length >= maxChars) break
            val child = node.getChild(i)
            if (child != null) {
                traverseNodeTree(child, sb, maxChars)
                child.recycle()
            }
        }
    }
}
