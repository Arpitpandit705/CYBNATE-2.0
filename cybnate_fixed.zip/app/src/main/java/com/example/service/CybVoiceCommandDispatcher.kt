package com.example.service

import android.content.Context
import com.example.ai.AIService
import com.example.data.CybNateDatabase
import com.example.viewmodel.CybNateViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import java.util.Locale

sealed class VoiceCommandResult {
    data class Executed(val spokenFeedback: String) : VoiceCommandResult()
    data class AskAi(val originalQuery: String) : VoiceCommandResult()
}

/**
 * CybVoiceCommandDispatcher
 *
 * Parses spoken natural language queries from the user into concrete actions:
 * - Start focus session / study lock
 * - Stop / pause session
 * - Check progress / remaining lectures
 * - Unlock or switch subjects
 * - Answer general questions via AI
 */
object CybVoiceCommandDispatcher {

    fun dispatch(rawText: String, viewModel: CybNateViewModel): VoiceCommandResult {
        val text = rawText.lowercase(Locale.ROOT).trim()

        // 1. "Start focus", "Start study", "Start lecture", "Focus now", "Lock phone"
        if (text.contains("start focus") || text.contains("start study") || text.contains("start lecture") ||
            text.contains("study now") || text.contains("begin focus") || text.contains("lock phone") || text.contains("start locking")
        ) {
            val state = viewModel.uiState.value
            val currentPhysics = state.allChapters.firstOrNull { it.subject == "PHYSICS" && it.unlocked && it.status != "COMPLETED" }
            val chapter = currentPhysics ?: state.allChapters.firstOrNull { it.unlocked && it.status != "COMPLETED" }
            
            if (chapter != null) {
                viewModel.startFocusSessionDirect(
                    subject = chapter.subject,
                    chapterName = chapter.chapterName,
                    chapterId = chapter.id,
                    itemIndex = chapter.completedLectures + 1,
                    taskType = "LECTURE"
                )
                return VoiceCommandResult.Executed(
                    "Starting your 96-minute focus session on ${chapter.subject}: ${chapter.chapterName}. Phone lock and distraction shields are active. Let's get to work!"
                )
            } else {
                return VoiceCommandResult.Executed("All scheduled chapters are currently complete! Check your progress.")
            }
        }

        // 2. "Stop focus", "Pause study", "Cancel focus", "Pause session"
        if (text.contains("stop focus") || text.contains("pause focus") || text.contains("pause study") ||
            text.contains("stop study") || text.contains("pause session") || text.contains("emergency pause")
        ) {
            val session = viewModel.uiState.value.activeFocusSession
            return if (session != null && session.isRunning) {
                viewModel.toggleFocusTimer()
                VoiceCommandResult.Executed("Focus session paused. Cyb will hold your timer. Resume whenever you are ready.")
            } else {
                VoiceCommandResult.Executed("No active focus session is currently running.")
            }
        }

        // 3. "Resume study", "Resume focus", "Continue session"
        if (text.contains("resume focus") || text.contains("resume study") || text.contains("continue study") || text.contains("unpause")) {
            val session = viewModel.uiState.value.activeFocusSession
            return if (session != null && !session.isRunning) {
                viewModel.toggleFocusTimer()
                VoiceCommandResult.Executed("Focus session resumed. Distraction shields back online.")
            } else {
                VoiceCommandResult.Executed("Your session is already running or none is queued.")
            }
        }

        // 4. "Complete lecture", "Mark finished", "Finished lecture"
        if (text.contains("finish lecture") || text.contains("complete lecture") || text.contains("lecture finished") || text.contains("done with lecture")) {
            val session = viewModel.uiState.value.activeFocusSession
            return if (session != null) {
                viewModel.completeTaskDirect(session.chapterId, session.taskType)
                VoiceCommandResult.Executed("Lecture marked complete! XP awarded and syllabus progress logged.")
            } else {
                VoiceCommandResult.Executed("No active lecture in progress to complete.")
            }
        }

        // 5. "What is my progress?", "How many lectures left?", "Tell me my status", "Days remaining"
        if (text.contains("progress") || text.contains("lectures left") || text.contains("how many left") ||
            text.contains("days left") || text.contains("status") || text.contains("streak")
        ) {
            val stats = viewModel.uiState.value.userStats
            val risk = viewModel.uiState.value.riskAnalysis
            val remaining = risk?.totalLecturesRemaining ?: 180
            val days = risk?.daysRemaining ?: 120
            val streak = stats.currentStreak
            return VoiceCommandResult.Executed(
                "You have $remaining lectures remaining with $days days until your target deadline. Your current focus streak is $streak days. Stay locked in!"
            )
        }

        // 6. "Open app picker", "Block apps", "Manage blocked apps"
        if (text.contains("block app") || text.contains("blocked apps") || text.contains("app picker") || text.contains("block instagram")) {
            viewModel.openAppPicker()
            return VoiceCommandResult.Executed("Opening the App Block Selector on your screen.")
        }

        // 7. "What can you do", "help", "features"
        if (text.contains("what can you do") || text == "help" || text.contains("help me") ||
            text.contains("your features") || text.contains("commands")
        ) {
            return VoiceCommandResult.Executed(
                "I can start or pause your focus sessions, mark lectures complete, report your progress and streak, manage blocked apps, switch between dark and light themes, and answer any study question. Just say Hey CybNate, then your command."
            )
        }

        // 8. "Dark theme", "Light mode"
        if (text.contains("dark theme") || text.contains("dark mode")) {
            return if (!viewModel.uiState.value.isDarkTheme) {
                viewModel.toggleTheme()
                VoiceCommandResult.Executed("Dark theme enabled. Easy on the eyes for late-night study.")
            } else {
                VoiceCommandResult.Executed("Dark theme is already active.")
            }
        }
        if (text.contains("light theme") || text.contains("light mode")) {
            return if (viewModel.uiState.value.isDarkTheme) {
                viewModel.toggleTheme()
                VoiceCommandResult.Executed("Light theme enabled for bright-day study.")
            } else {
                VoiceCommandResult.Executed("Light theme is already active.")
            }
        }

        // 9. General queries: Math, chemistry, doubt, or whatever user asks
        return VoiceCommandResult.AskAi(rawText)
    }

    suspend fun dispatchStandalone(rawText: String, context: Context): VoiceCommandResult {
        val text = rawText.lowercase(Locale.ROOT).trim()

        if (text.contains("start focus") || text.contains("start study") || text.contains("lock phone") || text.contains("start lecture")) {
            AppBlockingManager.setFocusSessionActive(context, true)
            try {
                FocusMonitorService.startService(context)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return VoiceCommandResult.Executed("Starting your focus session in background. Phone lock and distraction shields are now active.")
        }

        if (text.contains("stop focus") || text.contains("pause focus") || text.contains("pause study") || text.contains("stop study")) {
            AppBlockingManager.setFocusSessionActive(context, false)
            try {
                FocusMonitorService.stopService(context)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return VoiceCommandResult.Executed("Focus session paused.")
        }

        if (text.contains("progress") || text.contains("lectures left") || text.contains("days left") || text.contains("status") || text.contains("streak")) {
            return try {
                val db = CybNateDatabase.getDatabase(context, CoroutineScope(Dispatchers.IO))
                val dao = db.dao()
                val stats = dao.getUserStats().firstOrNull() ?: com.example.data.UserStatsEntity()
                val chapters = dao.getAllChapters().firstOrNull() ?: emptyList()
                val risk = AIService.analyzeDeadlineAndPace(stats, chapters)
                val remaining = risk.totalLecturesRemaining
                val days = risk.daysRemaining
                // stats is already non-null here (elvis default above) — removed the
                // redundant safe-call that generated a compiler warning.
                val streak = stats.currentStreak
                VoiceCommandResult.Executed("You have $remaining lectures remaining with $days days until your target deadline. Your current streak is $streak days.")
            } catch (e: Exception) {
                VoiceCommandResult.Executed("Your background study session is running smoothly. Keep up the great work!")
            }
        }

        return VoiceCommandResult.AskAi(rawText)
    }
}

