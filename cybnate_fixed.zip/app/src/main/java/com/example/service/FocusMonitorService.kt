package com.example.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.*

class FocusMonitorService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var isMonitoring = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_MONITORING) {
            stopMonitoring()
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CYBNATE — STUDY LOCK ACTIVE")
            .setContentText("Focus Mission in progress. Distracting apps restricted.")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (fallbackEx: Throwable) {
                fallbackEx.printStackTrace()
            }
        }

        startMonitoring()

        return START_STICKY
    }

    private fun startMonitoring() {
        if (isMonitoring) return
        isMonitoring = true

        serviceScope.launch {
            while (isMonitoring) {
                delay(3000L) // Check top app every 3 seconds
                val topPackage = AppBlockingManager.getForegroundAppPackage(applicationContext)
                val customBlocked = AppBlockingManager.getCustomBlockedPackages(applicationContext)
                val primaryLearningApp = AppBlockingManager.getPrimaryLearningApp(applicationContext)
                if (topPackage != null && AppBlockingManager.isPackageBlocked(
                        topPackage,
                        packageName,
                        primaryLearningApp,
                        customBlocked
                    )
                ) {
                    // Trigger Distraction Intervention Intent
                    val intent = Intent(applicationContext, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        putExtra("TRIGGER_DISTRACTION_INTERVENTION", true)
                        putExtra("BLOCKED_PACKAGE", topPackage)
                    }
                    startActivity(intent)
                }
            }
        }
    }

    private fun stopMonitoring() {
        isMonitoring = false
        serviceScope.cancel()
    }

    override fun onDestroy() {
        stopMonitoring()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "CybNate Study Lock",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when Hard Study Lock is protecting study time"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "cybnate_study_lock_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_MONITORING = "com.example.action.START_MONITORING"
        const val ACTION_STOP_MONITORING = "com.example.action.STOP_MONITORING"

        fun startService(context: Context) {
            try {
                val intent = Intent(context, FocusMonitorService::class.java).apply {
                    action = ACTION_START_MONITORING
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        fun stopService(context: Context) {
            try {
                val intent = Intent(context, FocusMonitorService::class.java).apply {
                    action = ACTION_STOP_MONITORING
                }
                context.startService(intent)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }
}
