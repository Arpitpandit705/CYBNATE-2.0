package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.R
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * CybFloatingIslandService
 *
 * Runs as a background service with an iOS Dynamic Island / Siri-style pill overlay.
 * Floating directly on top of Android system screen, across ANY app or home screen.
 * Wakes up automatically when the user says "CybNate" (or "Cyb") without opening the CybNate app!
 */
class CybFloatingIslandService : Service() {

    companion object {
        const val ACTION_START_ISLAND = "com.example.service.action.START_ISLAND"
        const val ACTION_STOP_ISLAND = "com.example.service.action.STOP_ISLAND"
        private const val CHANNEL_ID = "cybnate_voice_island_channel"
        private const val NOTIFICATION_ID = 4040
        private const val TAG = "CybFloatingIsland"

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, CybFloatingIslandService::class.java).apply {
                action = ACTION_START_ISLAND
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start island service", e)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, CybFloatingIslandService::class.java).apply {
                action = ACTION_STOP_ISLAND
            }
            try {
                context.startService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to stop island service", e)
            }
        }
    }

    private var windowManager: WindowManager? = null
    private var islandRootView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    // UI elements inside the Island
    private var islandContainer: LinearLayout? = null
    private var statusDot: View? = null
    private var waveIcon: ImageView? = null
    private var islandText: TextView? = null
    private var subText: TextView? = null

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_ISLAND) {
            removeFloatingIsland()
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundNotification()
        setupFloatingIsland()
        observeCybVoiceState()

        // Initialize voice assistant from foreground service; microphone stays strictly OFF by default
        CybVoiceAssistantManager.init(applicationContext)

        return START_STICKY
    }

    private fun startForegroundNotification() {
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CybNate Island Ready")
            .setContentText("Mic is OFF (Tap island to speak to CybNate)")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (fallback: Throwable) {
                Log.w(TAG, "Foreground service fallback", fallback)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Cyb Voice Assistant & Dynamic Island",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active status of Cyb Siri-like floating island and wake word recognition"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun setupFloatingIsland() {
        if (islandRootView != null) return

        // Check overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Log.w(TAG, "SYSTEM_ALERT_WINDOW permission not granted yet.")
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val density = resources.displayMetrics.density

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = (14 * density).toInt() // Positioned at top notch area like iOS Dynamic Island
        }

        buildIslandView(density)

        // Keep invisible initially: Siri-like behavior, only emerges when user says "CybNate"
        islandRootView?.visibility = View.GONE

        try {
            windowManager?.addView(islandRootView, layoutParams)
            Log.d(TAG, "Floating Dynamic Island added to window manager (hidden until triggered)")
        } catch (e: Exception) {
            Log.e(TAG, "Could not add Dynamic Island view", e)
        }
    }

    private fun buildIslandView(density: Float) {
        val context = this

        islandContainer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((14 * density).toInt(), (8 * density).toInt(), (14 * density).toInt(), (8 * density).toInt())

            // iOS Dynamic Island pill background: Deep Jet Black with subtle neon green border
            val backgroundDrawable = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 28 * density
                setColor(0xEE0B0E14.toInt()) // Sleek OLED pitch black
                setStroke((1.5f * density).toInt(), 0xFF00E676.toInt()) // Cyb Neon Green
            }
            background = backgroundDrawable
            elevation = 16 * density
        }

        // Green glowing pulsing dot
        statusDot = View(context).apply {
            val dotDrawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF00E676.toInt())
            }
            background = dotDrawable
            layoutParams = LinearLayout.LayoutParams((10 * density).toInt(), (10 * density).toInt()).apply {
                marginEnd = (8 * density).toInt()
            }
        }

        // Wave / Microphone icon
        waveIcon = ImageView(context).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setColorFilter(0xFF00E676.toInt())
            layoutParams = LinearLayout.LayoutParams((18 * density).toInt(), (18 * density).toInt()).apply {
                marginEnd = (8 * density).toInt()
            }
        }

        // Main text container
        val textContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }

        islandText = TextView(context).apply {
            text = "CybNate"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            maxLines = 1
        }

        subText = TextView(context).apply {
            text = "Say 'CybNate' to talk"
            setTextColor(0xFF8B9BB4.toInt())
            textSize = 9.5f
            maxLines = 2
        }

        textContainer.addView(islandText)
        textContainer.addView(subText)

        islandContainer?.addView(statusDot)
        islandContainer?.addView(waveIcon)
        islandContainer?.addView(textContainer)

        // Make island draggable & interactive
        setupIslandInteractivity(islandContainer!!, density)

        islandRootView = islandContainer
    }

    private fun setupIslandInteractivity(view: View, density: Float) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = false

        view.setOnTouchListener { _, event ->
            val lp = layoutParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = lp.x
                    initialY = lp.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        isClick = false
                    }
                    lp.x = initialX + dx
                    lp.y = initialY + dy
                    try {
                        windowManager?.updateViewLayout(islandRootView, lp)
                    } catch (e: Exception) {
                        // ignore
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        // Tap island to wake up or ask question immediately
                        onIslandTapped()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun onIslandTapped() {
        val state = CybVoiceAssistantManager.voiceState.value
        if (state.isListening) {
            CybVoiceAssistantManager.stopListening()
        } else {
            CybVoiceAssistantManager.wakeUpAndListen()
        }
    }

    private fun observeCybVoiceState() {
        serviceScope.launch {
            CybVoiceAssistantManager.voiceState.collectLatest { state ->
                updateIslandUI(state)
            }
        }
    }

    private fun updateIslandUI(state: CybVoiceState) {
        val density = resources.displayMetrics.density
        val lp = layoutParams ?: return

        when {
            state.isListening -> {
                // Pop up Dynamic Island like Siri / iOS Dynamic Island
                islandRootView?.visibility = View.VISIBLE

                islandText?.text = "Cyb is Listening..."
                subText?.text = if (state.recognizedText.isNotBlank()) state.recognizedText else "Speak your question or study doubt..."
                statusDot?.visibility = View.VISIBLE
                waveIcon?.visibility = View.VISIBLE
                waveIcon?.setColorFilter(0xFF00E676.toInt())

                (islandContainer?.background as? GradientDrawable)?.apply {
                    setStroke((2f * density).toInt(), 0xFF00E676.toInt())
                    setColor(0xF0080B10.toInt())
                }
            }
            state.isSpeaking -> {
                // Active speaking state
                islandRootView?.visibility = View.VISIBLE

                islandText?.text = "CybNate Speaking"
                subText?.text = if (state.assistantResponse.isNotBlank()) state.assistantResponse.take(60) + "..." else "Explaining..."
                statusDot?.visibility = View.VISIBLE
                waveIcon?.visibility = View.VISIBLE
                waveIcon?.setColorFilter(0xFF00F0FF.toInt()) // Cyan glow while speaking

                (islandContainer?.background as? GradientDrawable)?.apply {
                    setStroke((2f * density).toInt(), 0xFF00F0FF.toInt())
                    setColor(0xF005111B.toInt())
                }
            }
            else -> {
                // When idle / waiting for wake word: Auto-hide after brief delay so screen is clean!
                // Only show briefly if user just closed or completed, otherwise vanish completely
                islandRootView?.postDelayed({
                    val currentState = CybVoiceAssistantManager.voiceState.value
                    if (!currentState.isListening && !currentState.isSpeaking) {
                        islandRootView?.visibility = View.GONE
                    }
                }, 1800)
            }
        }

        try {
            windowManager?.updateViewLayout(islandRootView, lp)
        } catch (e: Exception) {
            // view might not be attached yet
        }
    }

    private fun removeFloatingIsland() {
        try {
            if (islandRootView != null) {
                windowManager?.removeView(islandRootView)
                islandRootView = null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing dynamic island view", e)
        }
    }

    override fun onDestroy() {
        isRunning = false
        super.onDestroy()
        serviceScope.cancel()
        removeFloatingIsland()
    }
}
