package com.example.service

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class CybVoiceState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val recognizedText: String = "",
    val assistantResponse: String = "",
    val isWakeWordListening: Boolean = true,
    val isVoiceModalVisible: Boolean = false,
    val isIslandVisible: Boolean = true
)

/**
 * CybVoiceAssistantManager
 *
 * Handles:
 * 1. Background Wake Word Detection for "CybNate" / "Cyb"
 * 2. System-wide speech recognition without opening the app or needing typing
 * 3. Text-to-Speech vocal responses
 * 4. Automatic loop restart so it remains always ready in the background
 */
object CybVoiceAssistantManager : RecognitionListener, TextToSpeech.OnInitListener {

    private const val TAG = "CybVoiceAssistant"
    private const val UTTERANCE_ID_PREFIX = "CYB_TTS_"

    private const val PREFS_NAME = "cybnate_voice_prefs"
    private const val KEY_ALWAYS_LISTEN = "always_listen_wake_word"


    private fun updateWakeLock(context: Context, enabled: Boolean) {
        try {
            if (partialWakeLock == null) {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                partialWakeLock = powerManager?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "CybNate::VoiceAssistantWakeLock"
                )?.apply {
                    setReferenceCounted(false)
                }
            }
            if (enabled) {
                if (partialWakeLock?.isHeld == false) {
                    // 1-hour safety timeout so a stuck lock can never drain the battery forever;
                    // it is re-acquired on every wake-word listening restart.
                    partialWakeLock?.acquire(60 * 60 * 1000L)
                }
            } else {
                if (partialWakeLock?.isHeld == true) {
                    partialWakeLock?.release()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating WakeLock", e)
        }
    }

    fun isAlwaysListenEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_ALWAYS_LISTEN, false) // Default FALSE: Mic strictly OFF by default
    }

    fun setAlwaysListenEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ALWAYS_LISTEN, enabled)
            .apply()
            
        updateWakeLock(context, enabled)

        if (!enabled) {
            stopListening()
            _voiceState.value = _voiceState.value.copy(
                isListening = false,
                isWakeWordListening = false
            )
        } else {
            startWakeWordListening()
        }
    }

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var appContext: Context? = null
    private var wakeIntent: Intent? = null
    private var partialWakeLock: PowerManager.WakeLock? = null
    // Siri-style wake phrases: "Hey CybNate", "Hello CybNate", "Hi CybNate", "OK CybNate",
    // "Hey Cyb", "Hello Cyb", or just "Cyb" / "CybNate" on their own — plus common
    // speech-recognizer mishearings (cibnate, syb nate, sid nate, cyber nate, ...).
    private val WAKE_WORD_REGEX = Regex(
        "(?i)\\b(?:(?:hey|hello|hi|ok|okay|yo)\\s+)?(?:cyb\\s*nate|cybnate|cib\\s*nate|cibnate|syb\\s*nate|sybnate|sib\\s*nate|cyber\\s*nate|cy\\s*nate|cyb\\s*net|signate|side\\s*nate|cynate|cyb|cib|syb|sib)\\b"
    )

    // Polite Siri-style dismissals that should NOT be sent to the AI
    private val DISMISS_REGEX = Regex(
        "(?i)\\s*(never\\s*mind|cancel|stop\\s*listening|go\\s*to\\s*sleep|nothing|that'?s\\s*all|thank\\s*you|thanks|ok\\s*thanks|bye|goodbye)[.!\\s]*"
    )

    private val _voiceState = MutableStateFlow(CybVoiceState(isListening = false, isWakeWordListening = false))
    val voiceState: StateFlow<CybVoiceState> = _voiceState.asStateFlow()

    private var onUserSpokeCallback: ((String) -> Unit)? = null
    private var isTtsReady = false

    // Mode: WAITING_FOR_WAKE_WORD vs RECORDING_USER_QUERY
    private enum class Mode {
        IDLE,
        LISTENING_FOR_WAKE_WORD,
        LISTENING_FOR_QUERY
    }

    private var currentMode = Mode.IDLE
    private val mainHandler = Handler(Looper.getMainLooper())
    private val autoOffHandler = Handler(Looper.getMainLooper())
    private var autoOffRunnable: Runnable? = null

    private fun schedule5SecondAutoMicOff() {
        cancelAutoMicOffTimer()
        autoOffRunnable = Runnable {
            if (currentMode == Mode.LISTENING_FOR_QUERY) {
                Log.d(TAG, "5-Second silence timeout reached. Closing active query mic.")
                _voiceState.value = _voiceState.value.copy(
                    isListening = false,
                    recognizedText = "",
                    isWakeWordListening = appContext?.let { isAlwaysListenEnabled(it) } ?: false
                )
                try {
                    speechRecognizer?.stopListening()
                    speechRecognizer?.cancel()
                } catch (e: Exception) {}
                currentMode = Mode.IDLE
                val ctx = appContext
                if (ctx != null && isAlwaysListenEnabled(ctx)) {
                    mainHandler.postDelayed({
                        startWakeWordListening()
                    }, 300)
                }
            }
        }
        autoOffHandler.postDelayed(autoOffRunnable!!, 5000)
    }

    private fun cancelAutoMicOffTimer() {
        autoOffRunnable?.let { autoOffHandler.removeCallbacks(it) }
        autoOffRunnable = null
    }

    fun init(context: Context, onUserSpoke: ((String) -> Unit)? = null) {
        appContext = context.applicationContext
        if (onUserSpoke != null) {
            onUserSpokeCallback = onUserSpoke
        }

        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }

        // Privacy-First: Default state of the microphone is strictly OFF.
        currentMode = Mode.IDLE
        val alwaysListen = isAlwaysListenEnabled(context)
        _voiceState.value = _voiceState.value.copy(
            isListening = false,
            isWakeWordListening = alwaysListen,
            // Clear any stale modal flag left over from a previous process death
            isVoiceModalVisible = false
        )

        // Only start background listening if user explicitly enabled always-listen in Settings
        if (alwaysListen) {
            mainHandler.post {
                ensureSpeechRecognizer()
                startWakeWordListening()
            }
        }
    }

    private fun ensureSpeechRecognizer() {
        val context = appContext ?: return
        if (speechRecognizer == null && SpeechRecognizer.isRecognitionAvailable(context)) {
            try {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(this@CybVoiceAssistantManager)
                }
                Log.d(TAG, "SpeechRecognizer created")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize SpeechRecognizer", e)
            }
        }
    }

    private fun destroySpeechRecognizer() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error destroying speech recognizer", e)
        } finally {
            speechRecognizer = null
        }
    }

    private fun resetRecognizerAndRetry() {
        destroySpeechRecognizer()
        mainHandler.postDelayed({
            startWakeWordListening()
        }, 500)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { engine ->
                val indicLocale = Locale("en", "IN")
                val langResult = engine.setLanguage(indicLocale)
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(Locale.US)
                }
                isTtsReady = true

                // Flush any response that was queued while the engine was still warming up
                pendingSpeech?.let { queued ->
                    pendingSpeech = null
                    mainHandler.postDelayed({ speak(queued) }, 400)
                }

                // Configure Assistant Audio Attributes for clear speech output
                try {
                    val audioAttr = android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                    engine.setAudioAttributes(audioAttr)
                } catch (e: Throwable) {
                    Log.w(TAG, "AudioAttributes setup fallback: ${e.message}")
                }

                // Human conversational cadence: 1.00f pitch & 1.06f speech rate (fluent, natural pacing)
                engine.setPitch(1.00f)
                engine.setSpeechRate(1.06f)

                // Select AI4Bharat Indic-TTS / Indian English / Hinglish neural voice
                try {
                    val availableVoices = engine.voices
                    if (!availableVoices.isNullOrEmpty()) {
                        val indicVoice = availableVoices.firstOrNull { voice ->
                            val name = voice.name.lowercase(Locale.ROOT)
                            name.contains("indic") || name.contains("ai4bharat") ||
                            name.contains("en-in") || name.contains("en_in") ||
                            name.contains("hi-in") || name.contains("hi_in")
                        } ?: availableVoices.firstOrNull { voice ->
                            val name = voice.name.lowercase(Locale.ROOT)
                            name.contains("neural") || name.contains("wavenet") || name.contains("en-us")
                        }

                        if (indicVoice != null) {
                            engine.voice = indicVoice
                            Log.i(TAG, "Selected Indic-TTS / Indian Voice Profile: ${indicVoice.name}")
                        } else {
                            Log.i(TAG, "Using Indic locale profile on default TTS engine")
                        }
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Could not enumerate voices, using Indic pitch profile: ${e.message}")
                }

                Log.d(TAG, "Cyb Indic-TTS Voice Engine initialized successfully")

                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _voiceState.value = _voiceState.value.copy(isSpeaking = true)
                    }

                    override fun onDone(utteranceId: String?) {
                        _voiceState.value = _voiceState.value.copy(isSpeaking = false)
                        val ctx = appContext
                        if (ctx != null && isAlwaysListenEnabled(ctx)) {
                            mainHandler.postDelayed({
                                startWakeWordListening()
                            }, 500)
                        } else {
                            stopListening()
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        _voiceState.value = _voiceState.value.copy(isSpeaking = false)
                        val ctx = appContext
                        if (ctx != null && isAlwaysListenEnabled(ctx)) {
                            startWakeWordListening()
                        } else {
                            stopListening()
                        }
                    }
                })
            }
        }
    }

    private fun playWakeChime() {
        // Siri-style ascending double tone, then release the generator
        try {
            val toneG = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 75)
            toneG.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 110)
            mainHandler.postDelayed({
                try {
                    toneG.startTone(android.media.ToneGenerator.TONE_PROP_BEEP2, 130)
                } catch (e: Exception) {}
            }, 150)
            mainHandler.postDelayed({
                try {
                    toneG.release()
                } catch (e: Exception) {}
            }, 650)
        } catch (e: Exception) {
            Log.w(TAG, "Tone generator error", e)
        }
    }

    private fun sanitizeForSpeech(text: String): String {
        var cleaned = text.trim()
        if (cleaned.startsWith("{") && cleaned.endsWith("}")) {
            try {
                val json = org.json.JSONObject(cleaned)
                if (json.has("answer")) {
                    cleaned = json.getString("answer")
                }
            } catch (e: Exception) {
                // Ignore fallback
            }
        }

        return cleaned
            .replace(Regex("```[a-zA-Z]*"), "") // remove code block fences
            .replace(Regex("\\*\\*|\\*|#+|_|`|~"), "") // remove markdown bold/italic/headers/inline code
            .replace("•", ", ") // replace bullet points with natural commas for breath pauses
            .replace(Regex("(?i)\\bDPP\\b|\\bDPPs\\b"), "Daily Practice Problems")
            .replace(Regex("(?i)\\bPW\\b"), "Physics Wallah")
            .replace(Regex("(?i)\\bJEE\\b"), "J E E")
            .replace(Regex("(?i)\\bNEET\\b"), "Neet")
            .replace(Regex("(?i)\\bCYB\\b|\\bCybNate\\b"), "Sib nate")
            .replace(Regex("(\\d+(?:\\.\\d+)?)x"), "$1 times speed") // e.g. "1.25x" -> "1.25 times speed"
            .replace(Regex("(\\d+)m\\b"), "$1 minutes") // e.g. "96m" -> "96 minutes"
            .replace(Regex("(\\d+)h\\b"), "$1 hours") // e.g. "2h" -> "2 hours"
            .replace("+", " plus ")
            .replace("=", " equals ")
            .replace("%", " percent ")
            .replace("/", " divided by ")
            .replace(Regex("(?m)^\\s*\\d+\\.\\s*"), "") // remove numbered list prefixes like "1. ", "2. "
            .replace(Regex("\\n+"), ". ") // convert line breaks to natural sentence pauses
            .replace(Regex("\\s+"), " ") // normalize whitespace
            .trim()
    }

    private var audioFocusRequest: AudioFocusRequest? = null

    private fun requestAudioFocus() {
        try {
            val audioManager = appContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attributes)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener { }
                    .build()
                audioFocusRequest = request
                audioManager.requestAudioFocus(request)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            }
        } catch (e: Exception) {
            Log.w(TAG, "AudioFocus request error", e)
        }
    }

    private fun abandonAudioFocus() {
        try {
            val audioManager = appContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        } catch (e: Exception) {
            Log.w(TAG, "AudioFocus abandon error", e)
        }
    }

    fun stopSpeaking() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping TTS", e)
        }
        abandonAudioFocus()
        _voiceState.value = _voiceState.value.copy(isSpeaking = false)
    }


    private fun restartWakeWordListeningIfNeeded() {
        val ctx = appContext
        if (ctx != null && isAlwaysListenEnabled(ctx)) {
            mainHandler.postDelayed({
                startWakeWordListening()
            }, 500)
        } else {
            stopListening()
        }
    }

    // Response that arrived before the TTS engine finished initializing
    private var pendingSpeech: String? = null

    fun speak(text: String, isGreeting: Boolean = false) {
        if (!isTtsReady || tts == null) {
            // BUGFIX: previously the answer was silently dropped. Queue it and
            // make sure the engine is on its way up instead.
            Log.w(TAG, "TTS not ready, queueing: $text")
            pendingSpeech = text
            val ctx = appContext
            if (tts == null && ctx != null) {
                try {
                    tts = TextToSpeech(ctx, this)
                } catch (e: Exception) {
                    Log.e(TAG, "Could not lazily create TTS engine", e)
                }
            }
            return
        }

        val cleanText = text.trim()
        // Never speak if empty or if user is uttering the "cybnate" wake word
        if (cleanText.isBlank() || cleanText.equals("cybnate", ignoreCase = true) || cleanText.equals("cyb nate", ignoreCase = true)) {
            restartWakeWordListeningIfNeeded()
            return
        }

        requestAudioFocus()

        val speechFormattedText = sanitizeForSpeech(cleanText)
        if (speechFormattedText.isBlank()) {
            restartWakeWordListeningIfNeeded()
            return
        }

        try {
            tts?.setPitch(1.00f)
            tts?.setSpeechRate(1.06f)
        } catch (e: Exception) {}

        _voiceState.value = _voiceState.value.copy(
            isSpeaking = true,
            assistantResponse = cleanText
        )

        val utteranceId = "CYB_TTS_ANSWER_${System.currentTimeMillis()}"
        val params = Bundle()
        tts?.speak(speechFormattedText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)

        // Keep background speech listener alive during TTS so user can barge-in and interrupt only if always-listen is enabled
        mainHandler.postDelayed({
            val ctx = appContext
            if (currentMode == Mode.LISTENING_FOR_WAKE_WORD && ctx != null && isAlwaysListenEnabled(ctx)) {
                try {
                    wakeIntent?.let { speechRecognizer?.startListening(it) } ?: startWakeWordListening()
                } catch (e: Exception) {
                    Log.w(TAG, "Could not start barge-in listener", e)
                }
            }
        }, 300)
    }

    fun speakDistractionWarning(appName: String = "that app") {
        val warnings = listOf(
            "Cyb alert! Stop looking at $appName and return to your study target right now.",
            "Hey! You are in an active study session. Close $appName immediately.",
            "Distraction detected on $appName. Stay focused on your study mission."
        )
        speak(warnings.random(), isGreeting = false)
    }

    /**
     * Continuous background listening for wake word "CybNate" or "Cyb"
     * Optimized for low latency & minimal CPU overhead
     */
    fun startWakeWordListening() {
        val context = appContext ?: return
        if (currentMode == Mode.LISTENING_FOR_QUERY || _voiceState.value.isSpeaking) {
            return
        }

        // Keep the CPU alive for the listening loop (timeout-guarded acquire)
        if (isAlwaysListenEnabled(context)) {
            updateWakeLock(context, true)
        }

        currentMode = Mode.LISTENING_FOR_WAKE_WORD
        _voiceState.value = _voiceState.value.copy(
            isListening = false,
            isWakeWordListening = true
        )

        try {
            ensureSpeechRecognizer()
            if (wakeIntent == null) {
                wakeIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toString())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1) // Top candidate only -> lower CPU/memory
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true) // Instant wakeup on partial matches
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 600L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
                }
            }
            speechRecognizer?.startListening(wakeIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting wake word listener", e)
            resetRecognizerAndRetry()
        }
    }

    /**
     * Explicit trigger (or when wake word "CybNate" is detected)
     * Transitions silently and immediately to listening for user query.
     */
    fun wakeUpAndListen() {
        playWakeChime()
        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Error cancelling recognizer on wake", e)
        }

        currentMode = Mode.LISTENING_FOR_QUERY
        _voiceState.value = _voiceState.value.copy(
            isListening = true,
            isSpeaking = false,
            recognizedText = "",
            isWakeWordListening = false
        )

        schedule5SecondAutoMicOff()
        mainHandler.post {
            startListeningForQuery()
        }
    }

    fun startListeningForQuery() {
        val context = appContext ?: return
        currentMode = Mode.LISTENING_FOR_QUERY
        _voiceState.value = _voiceState.value.copy(
            isListening = true,
            recognizedText = "",
            isSpeaking = false
        )
        schedule5SecondAutoMicOff()

        mainHandler.postDelayed({
            try {
                ensureSpeechRecognizer()
                val queryIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toString())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2200L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                }
                speechRecognizer?.startListening(queryIntent)
                Log.d(TAG, "Query SpeechRecognizer listening started successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error starting query speech listener", e)
                cancelAutoMicOffTimer()
                _voiceState.value = _voiceState.value.copy(isListening = false)
                currentMode = Mode.IDLE
                val ctx = appContext
                if (ctx != null && isAlwaysListenEnabled(ctx)) {
                    startWakeWordListening()
                }
            }
        }, 100)
    }

    fun stopListening() {
        cancelAutoMicOffTimer()
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recognition", e)
        }
        currentMode = Mode.IDLE
        val alwaysListen = appContext?.let { isAlwaysListenEnabled(it) } ?: false
        _voiceState.value = _voiceState.value.copy(
            isListening = false,
            isWakeWordListening = alwaysListen
        )
        // Strictly do NOT restart listening unless user opted into continuous wake word
        if (alwaysListen) {
            mainHandler.postDelayed({
                startWakeWordListening()
            }, 500)
        }
    }

    // In-app modal helper — BUGFIX: actually show the assistant sheet.
    // Previously isVoiceModalVisible was never set to true anywhere, so tapping
    // the mic button woke the recognizer but the UI never appeared.
    fun openVoiceAssistant() {
        _voiceState.value = _voiceState.value.copy(isVoiceModalVisible = true)
        wakeUpAndListen()
    }

    fun closeVoiceAssistant() {
        stopListening()
        tts?.stop()
        _voiceState.value = _voiceState.value.copy(
            isVoiceModalVisible = false,
            isListening = false,
            isSpeaking = false
        )
    }

    // --- Speech Recognition Callbacks ---

    override fun onReadyForSpeech(params: Bundle?) {
        if (currentMode == Mode.LISTENING_FOR_QUERY) {
            _voiceState.value = _voiceState.value.copy(isListening = true)
        }
    }

    override fun onBeginningOfSpeech() {
        // Barge-in Interruption: If the user begins speaking while Cyb is speaking, stop TTS immediately!
        if (_voiceState.value.isSpeaking || tts?.isSpeaking == true) {
            Log.i(TAG, "Barge-in speech detected! Interrupting Cyb voice synthesis.")
            stopSpeaking()
        }
    }
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        val partial = matches.firstOrNull() ?: return

        // Barge-in / Interruption: If user speaks while Cyb is speaking out loud, stop TTS immediately!
        if (_voiceState.value.isSpeaking || tts?.isSpeaking == true) {
            Log.i(TAG, "Barge-in speech detected during TTS: stopping speech output!")
            stopSpeaking()
        }

        if (currentMode == Mode.LISTENING_FOR_WAKE_WORD) {
            if (matches.any { checkWakeWord(it) }) {
                Log.i(TAG, "Wake word partially detected in background!")
                try {
                    speechRecognizer?.stopListening()
                } catch (e: Exception) {}
                wakeUpAndListen()
            }
        } else if (currentMode == Mode.LISTENING_FOR_QUERY) {
            _voiceState.value = _voiceState.value.copy(recognizedText = partial)
        }
    }

    override fun onEndOfSpeech() {
        cancelAutoMicOffTimer()
        if (currentMode == Mode.LISTENING_FOR_QUERY) {
            _voiceState.value = _voiceState.value.copy(isListening = false)
        }
    }

    override fun onError(error: Int) {
        cancelAutoMicOffTimer()
        Log.d(TAG, "Speech error code: $error, currentMode=$currentMode")
        val ctx = appContext
        val alwaysListen = ctx != null && isAlwaysListenEnabled(ctx)

        if (currentMode == Mode.LISTENING_FOR_QUERY) {
            _voiceState.value = _voiceState.value.copy(isListening = false)
            currentMode = Mode.IDLE
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (e: Exception) {}
            if (alwaysListen) {
                mainHandler.postDelayed({
                    startWakeWordListening()
                }, 600)
            }
        } else if (currentMode == Mode.LISTENING_FOR_WAKE_WORD) {
            if (!alwaysListen) {
                currentMode = Mode.IDLE
                _voiceState.value = _voiceState.value.copy(isListening = false, isWakeWordListening = false)
                return
            }
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    // Fast warm restart on silence or non-matching audio without destroying SpeechRecognizer object
                    mainHandler.postDelayed({
                        if (currentMode == Mode.LISTENING_FOR_WAKE_WORD && !_voiceState.value.isSpeaking && (appContext?.let { isAlwaysListenEnabled(it) } == true)) {
                            try {
                                wakeIntent?.let { speechRecognizer?.startListening(it) } ?: startWakeWordListening()
                            } catch (e: Exception) {
                                resetRecognizerAndRetry()
                            }
                        }
                    }, 100)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    // BUGFIX: mic permission was revoked. Previously this fell into the
                    // generic else-branch and restarted every 300 ms forever, hammering
                    // the recognizer and draining battery. Stop cleanly instead.
                    Log.w(TAG, "Mic permission missing — stopping wake-word loop until re-enabled.")
                    currentMode = Mode.IDLE
                    _voiceState.value = _voiceState.value.copy(
                        isListening = false,
                        isWakeWordListening = false
                    )
                }
                SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> {
                    // Back off hard; retrying immediately only makes it worse
                    mainHandler.postDelayed({
                        if (currentMode == Mode.LISTENING_FOR_WAKE_WORD &&
                            appContext?.let { isAlwaysListenEnabled(it) } == true) {
                            startWakeWordListening()
                        }
                    }, 5000)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT -> {
                    resetRecognizerAndRetry()
                }
                SpeechRecognizer.ERROR_SERVER,
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                    // Transient backend issues: warm restart with a longer backoff
                    mainHandler.postDelayed({
                        if (currentMode == Mode.LISTENING_FOR_WAKE_WORD && !_voiceState.value.isSpeaking &&
                            appContext?.let { isAlwaysListenEnabled(it) } == true) {
                            try {
                                wakeIntent?.let { speechRecognizer?.startListening(it) } ?: startWakeWordListening()
                            } catch (e: Exception) {
                                resetRecognizerAndRetry()
                            }
                        }
                    }, 1500)
                }
                else -> {
                    mainHandler.postDelayed({
                        if (appContext?.let { isAlwaysListenEnabled(it) } == true) {
                            startWakeWordListening()
                        }
                    }, 300)
                }
            }
        }
    }

    override fun onResults(results: Bundle?) {
        cancelAutoMicOffTimer()
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        val detectedText = matches.firstOrNull() ?: ""

        Log.d(TAG, "onResults mode=$currentMode, matches=$matches")

        when (currentMode) {
            Mode.LISTENING_FOR_WAKE_WORD -> {
                val matchedPhrase = matches.firstOrNull { checkWakeWord(it) }
                if (matchedPhrase != null) {
                    Log.i(TAG, "Wake word 'CybNate' detected in background! Full utterance: $matchedPhrase")
                    val queryAfterWake = stripWakeWord(matchedPhrase)
                    if (queryAfterWake.isNotBlank()) {
                        Log.i(TAG, "Continuous query detected in single utterance: '$queryAfterWake'")
                        playWakeChime()
                        try {
                            speechRecognizer?.cancel()
                        } catch (e: Exception) {
                            Log.w(TAG, "Error cancelling recognizer", e)
                        }
                        processSpokenQuery(queryAfterWake)
                    } else {
                        mainHandler.post {
                            wakeUpAndListen()
                        }
                    }
                } else {
                    val ctx = appContext
                    if (ctx != null && isAlwaysListenEnabled(ctx)) {
                        mainHandler.postDelayed({
                            if (currentMode == Mode.LISTENING_FOR_WAKE_WORD && !_voiceState.value.isSpeaking) {
                                try {
                                    wakeIntent?.let { speechRecognizer?.startListening(it) } ?: startWakeWordListening()
                                } catch (e: Exception) {
                                    resetRecognizerAndRetry()
                                }
                            }
                        }, 100)
                    } else {
                        currentMode = Mode.IDLE
                        _voiceState.value = _voiceState.value.copy(isListening = false, isWakeWordListening = false)
                    }
                }
            }

            Mode.LISTENING_FOR_QUERY -> {
                _voiceState.value = _voiceState.value.copy(
                    isListening = false,
                    recognizedText = detectedText
                )

                if (detectedText.isNotBlank()) {
                    processSpokenQuery(detectedText)
                } else {
                    restartWakeWordListeningIfNeeded()
                }
            }

            Mode.IDLE -> {
                // Mic strictly OFF
            }
        }
    }

    private fun processSpokenQuery(queryText: String) {
        val cleanQuery = stripWakeWord(queryText).ifBlank { queryText }

        // Siri-style polite dismissal — close the mic without hitting the AI
        if (DISMISS_REGEX.matches(cleanQuery)) {
            speak("Okay. Just say Hey CybNate whenever you need me.")
            return
        }

        _voiceState.value = _voiceState.value.copy(
            isListening = false,
            recognizedText = cleanQuery
        )

        // Close and cancel the speech recognizer immediately so the microphone is strictly OFF
        currentMode = Mode.IDLE
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (e: Exception) {}

        if (onUserSpokeCallback != null) {
            onUserSpokeCallback?.invoke(cleanQuery)
            return
        }

        val context = appContext ?: return
        CoroutineScope(Dispatchers.IO).launch {
            when (val result = CybVoiceCommandDispatcher.dispatchStandalone(cleanQuery, context)) {
                is VoiceCommandResult.Executed -> {
                    withContext(Dispatchers.Main) {
                        speak(result.spokenFeedback)
                    }
                }
                is VoiceCommandResult.AskAi -> {
                    try {
                        // 1. Check if Hugging Face Speech-to-Speech is enabled
                        if (com.example.ai.HfSpeechToSpeechConfig.isEnabled(context)) {
                            val hfResult = com.example.ai.HfSpeechToSpeechClient.querySpeechPipeline(context, cleanQuery)
                            if (hfResult.isSuccess && !hfResult.getOrNull().isNullOrBlank()) {
                                withContext(Dispatchers.Main) {
                                    speak(hfResult.getOrThrow())
                                }
                                return@launch
                            }
                        }

                        // 2. Primary / Local Fallback
                        val db = com.example.data.CybNateDatabase.getDatabase(context, CoroutineScope(Dispatchers.IO))
                        val dao = db.dao()
                        val stats = dao.getUserStats().firstOrNull() ?: com.example.data.UserStatsEntity()
                        val chapters = dao.getAllChapters().firstOrNull() ?: emptyList()
                        val answer = com.example.ai.AIService.answerStudyQuestion(
                            userQuery = cleanQuery,
                            stats = stats,
                            allChapters = chapters,
                            dailyTasks = emptyList(),
                            context = context
                        )
                        withContext(Dispatchers.Main) {
                            speak(answer)
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            speak("Offline command center active. Query logged.")
                        }
                    }
                }
            }
        }
    }

    private fun checkWakeWord(phrase: String): Boolean {
        if (phrase.isBlank()) return false
        return WAKE_WORD_REGEX.containsMatchIn(phrase)
    }

    private fun stripWakeWord(phrase: String): String {
        return phrase.replace(WAKE_WORD_REGEX, "").trim(' ', ',', '.', '!', '?')
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    fun shutdown() {
        try {
            currentMode = Mode.IDLE
            tts?.stop()
            tts?.shutdown()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
