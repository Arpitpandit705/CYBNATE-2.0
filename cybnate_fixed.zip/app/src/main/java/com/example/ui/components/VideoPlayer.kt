package com.example.ui.components

import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.media.MediaPlayer

@Composable
fun AlternatingVideoPlayer(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    
    // Store in shared preferences to alternate across dialog opens
    val prefs = context.getSharedPreferences("video_prefs", android.content.Context.MODE_PRIVATE)
    val useFirstVideo = prefs.getBoolean("use_first", true)
    
    DisposableEffect(Unit) {
        prefs.edit().putBoolean("use_first", !useFirstVideo).apply()
        onDispose { }
    }

    // Using placeholder URLs for the two uploaded videos. 
    // The user can replace these URLs with their actual video URLs or use local R.raw resources 
    // like: Uri.parse("android.resource://" + context.packageName + "/" + R.raw.video1)
    val videoUrl1 = "https://www.w3schools.com/html/mov_bbb.mp4" 
    val videoUrl2 = "https://www.w3schools.com/html/mov_bbb.mp4" 
    
    val currentUrl = if (useFirstVideo) videoUrl1 else videoUrl2

    val videoView = remember {
        VideoView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setVideoURI(Uri.parse(currentUrl))
            setOnPreparedListener { mp ->
                mp.isLooping = true
                mp.setVolume(1f, 1f)
                start()
            }
        }
    }

    AndroidView(
        factory = { videoView },
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(8.dp))
    )
}
