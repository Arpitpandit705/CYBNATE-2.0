package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.AppBlockingManager
import com.example.ui.theme.*

@Composable
fun StartFocusConfirmationDialog(
    taskType: String? = "LECTURE",
    targetDurationMinutes: Int = 96,
    playbackSpeed: Float = 1.25f,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = CardDarkElevated,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock",
                    tint = CybNateGreen,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Ready to focus?",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CybNateGreenGlow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (taskType == "LECTURE") "2 hr Lecture @ ${playbackSpeed}x = $targetDurationMinutes min focus session" else "$targetDurationMinutes min DPP Practice Session",
                        color = CybNateGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "CYBNATE will:",
                    color = CybNateGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text("• Start your $targetDurationMinutes-minute focus timer", color = TextPrimary, fontSize = 13.sp)
                Text("• Restrict distracting apps where supported", color = TextPrimary, fontSize = 13.sp)
                Text("• Monitor learning app activity", color = TextPrimary, fontSize = 13.sp)
                Text("• Track lecture & DPP progress", color = TextPrimary, fontSize = 13.sp)
                Text("• Verify completion with AI intelligence", color = TextPrimary, fontSize = 13.sp)
                Text("• Protect your focus until mission completion", color = TextPrimary, fontSize = 13.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("confirm_start_lock_btn")
            ) {
                Text("START LOCK", color = Color.Black, fontWeight = FontWeight.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) {
                Text("CANCEL", color = TextSecondary, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun PermissionsOnboardingDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val usageGranted = remember { AppBlockingManager.isUsagePermissionGranted(context) }
    val overlayGranted = remember { AppBlockingManager.isOverlayPermissionGranted(context) }
    val accessibilityGranted = remember { AppBlockingManager.isAccessibilityPermissionGranted(context) }
    var micGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        micGranted = isGranted
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardDarkElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = CybNateGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text("SYSTEM & VOICE PERMISSIONS", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "To enforce Hard Study Lock and use hands-free Cyb Voice Assistant (\"CybNate\" wake word & voice Q&A), grant the required permissions below:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                Button(
                    onClick = {
                        if (!micGranted) {
                            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (micGranted) SurfaceElevated else CybNateGreen),
                    modifier = Modifier.fillMaxWidth().testTag("grant_mic_btn")
                ) {
                    Text(
                        text = if (micGranted) "✓ MICROPHONE PERMISSION GRANTED" else "🎙️ GRANT MICROPHONE (VOICE ASSISTANT)",
                        color = if (micGranted) CybNateGreen else Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { AppBlockingManager.openAccessibilitySettings(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (accessibilityGranted) SurfaceElevated else CybNateGreen),
                    modifier = Modifier.fillMaxWidth().testTag("grant_accessibility_btn")
                ) {
                    Text(
                        text = if (accessibilityGranted) "✓ ACCESSIBILITY SERVICE ON" else "ENABLE ACCESSIBILITY LOCK",
                        color = if (accessibilityGranted) CybNateGreen else Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { AppBlockingManager.openUsageAccessSettings(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (usageGranted) SurfaceElevated else CybNateGreen),
                    modifier = Modifier.fillMaxWidth().testTag("grant_usage_btn")
                ) {
                    Text(
                        text = if (usageGranted) "✓ USAGE ACCESS GRANTED" else "GRANT USAGE ACCESS",
                        color = if (usageGranted) CybNateGreen else Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { AppBlockingManager.openOverlaySettings(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (overlayGranted) SurfaceElevated else CybNateGreen),
                    modifier = Modifier.fillMaxWidth().testTag("grant_overlay_btn")
                ) {
                    Text(
                        text = if (overlayGranted) "✓ DYNAMIC ISLAND & OVERLAY ON" else "ENABLE DYNAMIC ISLAND (OVERLAY)",
                        color = if (overlayGranted) CybNateGreen else Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen)
            ) {
                Text("CONTINUE", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun DistractionInterventionDialog(
    missionCompleted: Int,
    missionTotal: Int,
    onReturnToFocus: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onReturnToFocus,
        containerColor = CardDarkElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Block, contentDescription = null, tint = StatusYellow)
                Spacer(modifier = Modifier.width(8.dp))
                Text("FOCUS LOCK ACTIVE", color = StatusYellow, fontSize = 18.sp, fontWeight = FontWeight.Black)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StatusRed.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StatusRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = StatusRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CYB VOICE ALERT TRIGGERED",
                            color = StatusRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Text(
                    "This application is restricted during your active study mission. Cyb has intercepted this action.",
                    color = TextPrimary,
                    fontSize = 14.sp
                )
                
                AlternatingVideoPlayer()


                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CardDark,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("TODAY'S MISSION PROGRESS", color = CybNateGreen, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "$missionCompleted / $missionTotal Lectures Completed (${missionTotal - missionCompleted} remaining)",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    "Finish today's study mission to release Study Lock.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onReturnToFocus,
                colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                modifier = Modifier.fillMaxWidth().testTag("return_to_focus_btn")
            ) {
                Text("RETURN TO STUDY FOCUS", color = Color.Black, fontWeight = FontWeight.Black)
            }
        }
    )
}

@Composable
fun EmergencyPauseDialog(
    onConfirmPause: (String) -> Unit,
    onCancel: () -> Unit
) {
    var reasonText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = CardDarkElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PauseCircle, contentDescription = null, tint = StatusYellow)
                Spacer(modifier = Modifier.width(8.dp))
                Text("EMERGENCY PAUSE", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Enter a reason for pausing your focus session:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    placeholder = { Text("e.g. Break, Urgent call, Medical", color = TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CardDark,
                        unfocusedContainerColor = CardDark,
                        focusedBorderColor = CybNateGreen,
                        unfocusedBorderColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmPause(reasonText.ifBlank { "Unspecified pause" }) },
                colors = ButtonDefaults.buttonColors(containerColor = StatusYellow)
            ) {
                Text("PAUSE SESSION", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) {
                Text("RESUME STUDY", color = CybNateGreen, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun MissionCompleteCelebrationDialog(
    onClaimReward: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClaimReward,
        containerColor = CardDarkElevated,
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CybNateGreen, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("MISSION COMPLETE!", color = CybNateGreen, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = CybNateGreenGlow
                ) {
                    Text("STUDY LOCK RELEASED", color = CybNateGreen, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
                }

                Text(
                    "You have verified all 5 lectures for today! Normal app access is now restored.",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("+500 XP", color = StatusYellow, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Text("🔥 Streak Continued", color = CybNateGreen, fontSize = 16.sp, fontWeight = FontWeight.Black)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onClaimReward,
                colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                modifier = Modifier.fillMaxWidth().testTag("claim_mission_reward_btn")
            ) {
                Text("CLAIM REWARD & UNLOCK", color = Color.Black, fontWeight = FontWeight.Black)
            }
        }
    )
}
