package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChapterEntity
import com.example.ui.theme.*
import com.example.viewmodel.CybNateUiState
import java.util.Calendar

@Composable
fun HomeScreen(
    state: CybNateUiState,
    onStartFocusClicked: (String, String, Int, Int, String) -> Unit,
    onGoToPlan: () -> Unit,
    onGoToSubjects: () -> Unit,
    onGoToCoach: () -> Unit,
    onOpenAppPicker: () -> Unit,
    onOpenCybVoice: () -> Unit = {}
) {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 12 -> "GOOD MORNING"
        hour < 18 -> "GOOD AFTERNOON"
        else -> "GOOD EVENING"
    }

    val totalLectures = state.allChapters.sumOf { it.totalLectures }
    val completedLectures = state.allChapters.sumOf { it.completedLectures }
    val overallPercentage = if (totalLectures > 0) ((completedLectures.toFloat() / totalLectures) * 100).toInt() else 0

    val risk = state.riskAnalysis
    val activeChapter = state.activeChapters.values.firstOrNull { it != null }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SpotifyDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // --- TOP BRANDING HEADER ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = CybNateGreen,
                        modifier = Modifier.size(10.dp)
                    ) {}
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CYBNATE",
                        color = CybNateGreen,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = CardDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Streak",
                                tint = StatusYellow,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${state.userStats.currentStreak}d Streak",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- GREETING & FOCUS STATUS BADGE (Sections 1, 19) ---
        item {
            Column {
                Text(
                    text = greeting,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Ready to continue?",
                    color = TextPrimary,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // STUDY LOCK STATUS BADGE
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (state.isStudyLockActive) CybNateGreenGlow else CardDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (state.isStudyLockActive) CybNateGreen else BorderSubtle)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (state.isStudyLockActive) CybNateGreen else TextSecondary,
                            modifier = Modifier.size(8.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (state.isStudyLockActive) "STUDY LOCK ACTIVE • ${state.missionCompletedCount}/5 Complete" else "STUDY LOCK RELEASED • Mission Complete",
                            color = if (state.isStudyLockActive) CybNateGreen else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        // --- APP BLOCK SELECTOR (User requested block icon selector below streak) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(18.dp))
                    .clickable { onOpenAppPicker() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = StatusRed.copy(alpha = 0.2f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Block,
                                    contentDescription = "Block Apps",
                                    tint = StatusRed,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "SELECT APPS TO BLOCK",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${state.customBlocklist.size} device apps currently blocked",
                                color = CybNateGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open Picker",
                        tint = TextSecondary
                    )
                }
            }
        }

        // --- TODAY'S MISSION CARD (Sections 1, 13) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDarkElevated),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, CybNateGreenMuted, RoundedCornerShape(20.dp))
                    .testTag("todays_mission_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Lock",
                                tint = CybNateGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TODAY'S MISSION",
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }

                        Text(
                            text = "${state.missionCompletedCount} / 5",
                            color = CybNateGreen,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { state.missionCompletedCount / 5f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = CybNateGreen,
                        trackColor = SurfaceElevated
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "2h @ 1.25x speed • 96 min each",
                            color = CybNateGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Total Focus: 8 hrs",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 5-LECTURE SEQUENTIAL MISSION ITEMS (Section 13)
                    val curPhysics = state.activeChapters["PHYSICS"] ?: state.allChapters.firstOrNull { it.subject == "PHYSICS" && it.unlocked }
                    val curMath = state.activeChapters["MATHEMATICS"] ?: state.allChapters.firstOrNull { it.subject == "MATHEMATICS" && it.unlocked }
                    val curInorganic = state.activeChapters["INORGANIC_CHEMISTRY"] ?: state.allChapters.firstOrNull { it.subject == "INORGANIC_CHEMISTRY" && it.unlocked }
                    val curPhysical = state.activeChapters["PHYSICAL_CHEMISTRY"] ?: state.allChapters.firstOrNull { it.subject == "PHYSICAL_CHEMISTRY" && it.unlocked }

                    data class MissionSlot(
                        val slotIndex: Int,
                        val subjectKey: String,
                        val subjectTag: String,
                        val chapterName: String,
                        val chapterId: Int,
                        val lectureNum: Int,
                        val isCompleted: Boolean,
                        val isNext: Boolean
                    )

                    val missionSlots = listOf(
                        MissionSlot(
                            slotIndex = 0,
                            subjectKey = "PHYSICS",
                            subjectTag = "Physics",
                            chapterName = curPhysics?.chapterName ?: "Circular Motion",
                            chapterId = curPhysics?.id ?: 1,
                            lectureNum = (curPhysics?.completedLectures ?: 0) + 1,
                            isCompleted = 1 <= state.missionCompletedCount,
                            isNext = state.missionCompletedCount == 0
                        ),
                        MissionSlot(
                            slotIndex = 1,
                            subjectKey = "PHYSICS",
                            subjectTag = "Physics",
                            chapterName = curPhysics?.chapterName ?: "Circular Motion",
                            chapterId = curPhysics?.id ?: 1,
                            lectureNum = (curPhysics?.completedLectures ?: 0) + 2,
                            isCompleted = 2 <= state.missionCompletedCount,
                            isNext = state.missionCompletedCount == 1
                        ),
                        MissionSlot(
                            slotIndex = 2,
                            subjectKey = "MATHEMATICS",
                            subjectTag = "Mathematics",
                            chapterName = curMath?.chapterName ?: "Ch-04 : Trigonometric Functions",
                            chapterId = curMath?.id ?: 65,
                            lectureNum = (curMath?.completedLectures ?: 0) + 1,
                            isCompleted = 3 <= state.missionCompletedCount,
                            isNext = state.missionCompletedCount == 2
                        ),
                        MissionSlot(
                            slotIndex = 3,
                            subjectKey = "INORGANIC_CHEMISTRY",
                            subjectTag = "Inorganic Chem",
                            chapterName = curInorganic?.chapterName ?: "Ch-02 : Chemical Bonding",
                            chapterId = curInorganic?.id ?: 55,
                            lectureNum = (curInorganic?.completedLectures ?: 0) + 1,
                            isCompleted = 4 <= state.missionCompletedCount,
                            isNext = state.missionCompletedCount == 3
                        ),
                        MissionSlot(
                            slotIndex = 4,
                            subjectKey = "PHYSICAL_CHEMISTRY",
                            subjectTag = "Physical Chem",
                            chapterName = curPhysical?.chapterName ?: "Ch - 03: Solutions",
                            chapterId = curPhysical?.id ?: 46,
                            lectureNum = (curPhysical?.completedLectures ?: 0) + 1,
                            isCompleted = 5 <= state.missionCompletedCount,
                            isNext = state.missionCompletedCount == 4
                        )
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        missionSlots.forEach { slot ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = when {
                                    slot.isCompleted -> CybNateGreenGlow
                                    slot.isNext -> CardDark
                                    else -> SurfaceElevated.copy(alpha = 0.5f)
                                },
                                border = androidx.compose.foundation.BorderStroke(
                                    width = 1.dp,
                                    color = when {
                                        slot.isCompleted -> CybNateGreen.copy(alpha = 0.4f)
                                        slot.isNext -> StatusYellow.copy(alpha = 0.5f)
                                        else -> BorderSubtle
                                    }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onStartFocusClicked(
                                            slot.subjectKey,
                                            slot.chapterName,
                                            slot.chapterId,
                                            slot.lectureNum,
                                            "LECTURE"
                                        )
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = when {
                                                slot.isCompleted -> Icons.Default.CheckCircle
                                                slot.isNext -> Icons.Default.PlayCircle
                                                else -> Icons.Default.Lock
                                            },
                                            contentDescription = null,
                                            tint = when {
                                                slot.isCompleted -> CybNateGreen
                                                slot.isNext -> StatusYellow
                                                else -> TextMuted
                                            },
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = when (slot.subjectKey) {
                                                        "PHYSICS" -> CybNateGreenGlow
                                                        "MATHEMATICS" -> Color(0xFF2E3B55)
                                                        "INORGANIC_CHEMISTRY" -> Color(0xFF3B2E55)
                                                        else -> Color(0xFF553B2E)
                                                    }
                                                ) {
                                                    Text(
                                                        text = slot.subjectTag,
                                                        color = when (slot.subjectKey) {
                                                            "PHYSICS" -> CybNateGreen
                                                            "MATHEMATICS" -> Color(0xFF8AB4F8)
                                                            "INORGANIC_CHEMISTRY" -> Color(0xFFD7AEFB)
                                                            else -> Color(0xFFFDD663)
                                                        },
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "Lec ${slot.lectureNum} (96 min)",
                                                    color = TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = slot.chapterName,
                                                color = if (slot.isCompleted || slot.isNext) TextPrimary else TextSecondary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = when {
                                            slot.isCompleted -> CybNateGreen.copy(alpha = 0.15f)
                                            slot.isNext -> StatusYellow.copy(alpha = 0.2f)
                                            else -> SurfaceElevated
                                        }
                                    ) {
                                        Text(
                                            text = when {
                                                slot.isCompleted -> "✓ Done"
                                                slot.isNext -> "▶ START"
                                                else -> "Focus"
                                            },
                                            color = when {
                                                slot.isCompleted -> CybNateGreen
                                                slot.isNext -> StatusYellow
                                                else -> TextSecondary
                                            },
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val nextSlot = missionSlots.firstOrNull { !it.isCompleted } ?: missionSlots.first()

                    Button(
                        onClick = {
                            onStartFocusClicked(
                                nextSlot.subjectKey,
                                nextSlot.chapterName,
                                nextSlot.chapterId,
                                nextSlot.lectureNum,
                                "LECTURE"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("continue_focus_mission_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (state.isStudyLockActive) "START: ${nextSlot.subjectTag.uppercase()} (${nextSlot.chapterName.take(18)})" else "START EXTRA PRACTICE",
                                color = Color.Black,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        // --- PRIVACY-FIRST AI FOCUS VERIFICATION STATUS (Section 5, 6) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = "AI Verification",
                        tint = CybNateGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AI Focus Verification: ON",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Privacy Info",
                                tint = TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "Monitors learning app time and interaction signals locally. No permanent screenshots are stored.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // --- DEADLINE & PACE CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Event,
                                contentDescription = "Deadline",
                                tint = CybNateGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "DEADLINE: ${state.userStats.deadlineDate}",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (risk != null) {
                            val badgeBg = when (risk.status) {
                                "ON_TRACK" -> StatusGreen.copy(alpha = 0.2f)
                                "AT_RISK" -> StatusYellow.copy(alpha = 0.2f)
                                else -> StatusRed.copy(alpha = 0.2f)
                            }
                            val badgeTxt = when (risk.status) {
                                "ON_TRACK" -> StatusGreen
                                "AT_RISK" -> StatusYellow
                                else -> StatusRed
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = badgeBg
                            ) {
                                Text(
                                    text = risk.headline,
                                    color = badgeTxt,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = risk?.adviceMessage ?: "Calculating pace...",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Days Left", color = TextMuted, fontSize = 11.sp)
                            Text("${risk?.daysRemaining ?: 0}", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Column {
                            Text("Target Pace", color = TextMuted, fontSize = 11.sp)
                            Text("${risk?.requiredDailyLectures ?: 5} lec/day", color = CybNateGreen, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Column {
                            Text("Total XP", color = TextMuted, fontSize = 11.sp)
                            Text("${state.userStats.totalXp}", color = StatusYellow, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }

        // --- SUBJECT OVERVIEW CARDS ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "YOUR SUBJECTS",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                TextButton(onClick = onGoToSubjects) {
                    Text("VIEW ALL", color = CybNateGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(
            listOf(
                Triple("Physics", "PHYSICS", "2 lectures/day • Circular Motion"),
                Triple("Mathematics", "MATHEMATICS", "1 lecture/day • Ch-04 : Trigonometric Functions"),
                Triple("Inorganic Chemistry", "INORGANIC_CHEMISTRY", "1 lecture/day • Ch-02 : Chemical Bonding"),
                Triple("Physical Chemistry", "PHYSICAL_CHEMISTRY", "1 lecture/day • Ch - 03: Solutions"),
                Triple("Organic Chemistry", "ORGANIC_CHEMISTRY", if (state.userStats.organicActivated) "Active" else "🔒 Locked until Physical or Inorganic is completed")
            )
        ) { (title, key, targetText) ->
            val activeChapterItem = state.activeChapters[key] ?: state.allChapters.firstOrNull { it.subject == key && it.unlocked }
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                    .clickable { onGoToSubjects() }
            ) {
                Row(
                    modifier = Modifier
                        .padding(14.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        val chapDisplay = when {
                            activeChapterItem != null -> "Active: ${activeChapterItem.chapterName} (Lec ${(activeChapterItem.completedLectures) + 1}/${activeChapterItem.totalLectures})"
                            key == "ORGANIC_CHEMISTRY" && !state.userStats.organicActivated -> "Prerequisites Pending"
                            else -> "All Chapters Completed"
                        }
                        Text(
                            text = chapDisplay,
                            color = CybNateGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(targetText, color = TextSecondary, fontSize = 11.sp)
                    }

                    if (activeChapterItem != null && activeChapterItem.unlocked) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CybNateGreenGlow,
                            modifier = Modifier.clickable {
                                onStartFocusClicked(
                                    activeChapterItem.subject,
                                    activeChapterItem.chapterName,
                                    activeChapterItem.id,
                                    activeChapterItem.completedLectures + 1,
                                    "LECTURE"
                                )
                            }
                        ) {
                            Text(
                                text = "▶ FOCUS",
                                color = CybNateGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Go to subject",
                            tint = TextSecondary
                        )
                    }
                }
            }
        }
    }
}
