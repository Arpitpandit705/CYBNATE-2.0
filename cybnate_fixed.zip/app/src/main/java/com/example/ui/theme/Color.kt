package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// --- CYBNATE "AURORA MINT" COLOR SYSTEM ---
// Deep-space charcoal backgrounds with a vibrant mint accent and
// teal/violet supporting accents for a premium, modern look.

// Dark-First Primary Background (kept name for compatibility across screens)
val SpotifyDark = Color(0xFF0B0E13)

// Dark Charcoal Secondary Surfaces
val CardDark = Color(0xFF12171E)
val CardDarkElevated = Color(0xFF1A212B)
val SurfaceElevated = Color(0xFF232D3A)

// Primary Accent - CybNate Mint
val CybNateGreen = Color(0xFF2BE080)
val CybNateGreenMuted = Color(0xFF1DB864)
val CybNateGreenGlow = Color(0x332BE080)

// Supporting Accents
val CybTeal = Color(0xFF22D3EE)
val CybViolet = Color(0xFFA78BFA)
val CybAmber = Color(0xFFFBBF24)

// Brand Gradients
val CybAccentGradient: Brush = Brush.linearGradient(listOf(CybNateGreen, CybTeal))
val CybHeroGradient: Brush = Brush.linearGradient(listOf(CybNateGreen, CybTeal, CybViolet))

// Text Hierarchy
val TextPrimary = Color(0xFFF4F7FA)
val TextSecondary = Color(0xFFA9B4C0)
val TextMuted = Color(0xFF6B7684)

// Subtle Borders
val BorderSubtle = Color(0xFF222B36)
val BorderHighlight = Color(0xFF37434F)

// Status Colors
val StatusGreen = Color(0xFF2BE080)
val StatusYellow = Color(0xFFFBBF24)
val StatusRed = Color(0xFFF87171)
val StatusLocked = Color(0xFF4B5563)

// --- LIGHT THEME HIGH-CONTRAST PALETTE ---
val LightBackground = Color(0xFFF5F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE9EEF4)
val LightPrimaryGreen = Color(0xFF0E9F6E)
val LightPrimaryGreenMuted = Color(0xFF0B815A)
val LightAccentTeal = Color(0xFF0E7490)
val LightAccentViolet = Color(0xFF7C5CD6)
val LightTextPrimary = Color(0xFF0B1220)
val LightTextSecondary = Color(0xFF3D4A5C)
val LightTextMuted = Color(0xFF64748B)
val LightBorderSubtle = Color(0xFFDCE4EC)
val LightBorderHighlight = Color(0xFFC3CEDA)

// --- DESIGN TOKENS ---
object DesignTokens {
    // Spacing Grid
    val SpaceXSmall = 4.dp
    val SpaceSmall = 8.dp
    val SpaceMedium = 12.dp
    val SpaceLarge = 16.dp
    val SpaceXLarge = 24.dp
    val SpaceHuge = 32.dp

    // Corner Radii
    val RadiusSmall = 8.dp
    val RadiusMedium = 12.dp
    val RadiusLarge = 16.dp
    val RadiusXLarge = 20.dp
    val RadiusPill = 100.dp

    // Elevation & Borders
    val BorderWidth = 1.dp

    // Typography Sizes
    val FontSizeHero = 28.sp
    val FontSizeTitle = 22.sp
    val FontSizeSection = 16.sp
    val FontSizeBody = 14.sp
    val FontSizeCaption = 12.sp
    val FontSizeTiny = 10.sp
}
