package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.HfSpeechToSpeechClient
import com.example.ai.HfSpeechToSpeechConfig
import com.example.ai.StudentMemoryEngine
import com.example.ai.ReasoningAgentRouter
import com.example.service.CybVoiceAssistantManager
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    currentDeadline: String,
    lectureBaseHours: Float = 2.0f,
    playbackSpeed: Float = 1.25f,
    isDarkTheme: Boolean = true,
    onToggleTheme: () -> Unit,
    onUpdateDeadline: (String) -> Unit,
    onUpdatePlaybackSettings: (Float, Float) -> Unit,
    onResetProgress: () -> Unit,
    onNavigateToVoiceEnrollment: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var deadlineText by remember { mutableStateOf(currentDeadline) }
    var showResetDialog by remember { mutableStateOf(false) }

    // Cyb Voice Assistant state
    var alwaysListenWakeWord by remember { mutableStateOf(CybVoiceAssistantManager.isAlwaysListenEnabled(context)) }
    val voiceState by CybVoiceAssistantManager.voiceState.collectAsState()

    // Hugging Face Speech-to-Speech state
    var hfEnabled by remember { mutableStateOf(HfSpeechToSpeechConfig.isEnabled(context)) }
    var hfServerUrl by remember { mutableStateOf(HfSpeechToSpeechConfig.getServerUrl(context)) }
    var hfToken by remember { mutableStateOf(HfSpeechToSpeechConfig.getHfToken(context)) }
    var hfTestStatus by remember { mutableStateOf<String?>(null) }
    var isTestingConnection by remember { mutableStateOf(false) }

    // awesome-llm-apps: Agentic Memory & Reasoning state
    var reasoningMode by remember { mutableStateOf(StudentMemoryEngine.isReasoningModeEnabled(context)) }
    var memoriesList by remember { mutableStateOf(StudentMemoryEngine.getMemories(context)) }
    var newMemoryInput by remember { mutableStateOf("") }

    val effectiveMins = ((lectureBaseHours * 60) / playbackSpeed).toInt()
    val dailyLectureHours = (5 * effectiveMins) / 60.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SYSTEM SETTINGS",
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Manage your theme, lecture pace, exam deadline, and study configurations",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
        }

        // --- DYNAMIC LIGHT / DARK EYE-PROTECTION THEME TOGGLE CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                    .testTag("theme_toggle_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = "Theme Toggle",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isDarkTheme) "DARK THEME (LATE-NIGHT)" else "LIGHT THEME (DAYTIME)",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isDarkTheme) "Eye-protection dark canvas reduces eye strain during late-night JEE sessions." else "High-contrast bright canvas for daylight study clarity.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }

                    Switch(
                        checked = isDarkTheme,
                        onCheckedChange = { onToggleTheme() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }

        // --- LECTURE DURATION & SPEED CONTROLS CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CybNateGreenMuted, RoundedCornerShape(16.dp))
                    .testTag("lecture_speed_settings_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "Playback Speed",
                            tint = CybNateGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LECTURE DURATION & SPEED",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Summary Badge
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CybNateGreenGlow,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Effective Lecture Duration:", color = TextSecondary, fontSize = 12.sp)
                                Text("$effectiveMins Minutes", color = CybNateGreen, fontSize = 13.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Daily 5-Lecture Workload:", color = TextSecondary, fontSize = 12.sp)
                                Text("${String.format("%.1f", dailyLectureHours)} Hours / Day", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Formula: ${lectureBaseHours.toInt()}h (120m) / ${playbackSpeed}x speed = $effectiveMins min focus session",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Playback Speed:", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1.0f, 1.25f, 1.5f).forEach { speed ->
                            val isSelected = playbackSpeed == speed
                            FilterChip(
                                selected = isSelected,
                                onClick = { onUpdatePlaybackSettings(lectureBaseHours, speed) },
                                label = {
                                    Text(
                                        text = "${speed}x (${((lectureBaseHours * 60) / speed).toInt()}m)",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CybNateGreen,
                                    selectedLabelColor = Color.Black,
                                    containerColor = SurfaceElevated,
                                    labelColor = TextPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Base Lecture Length:", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1.5f, 2.0f, 2.5f).forEach { hours ->
                            val isSelected = lectureBaseHours == hours
                            FilterChip(
                                selected = isSelected,
                                onClick = { onUpdatePlaybackSettings(hours, playbackSpeed) },
                                label = {
                                    Text(
                                        text = "${hours}h (${(hours * 60).toInt()}m)",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CybNateGreen,
                                    selectedLabelColor = Color.Black,
                                    containerColor = SurfaceElevated,
                                    labelColor = TextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }

        // --- DEADLINE CONFIGURATION CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = "Deadline",
                            tint = CybNateGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "JEE TARGET DEADLINE",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Specify your target deadline date (YYYY-MM-DD):",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = deadlineText,
                            onValueChange = { deadlineText = it },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = SurfaceElevated,
                                unfocusedContainerColor = SurfaceElevated,
                                focusedBorderColor = CybNateGreen,
                                unfocusedBorderColor = BorderSubtle,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("deadline_input_field")
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = { onUpdateDeadline(deadlineText) },
                            colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("update_deadline_btn")
                        ) {
                            Text("SAVE", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- CYB VOICE ASSISTANT & PRIVACY CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CybNateGreen.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                    .testTag("voice_assistant_settings_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Cyb Voice Assistant",
                                tint = if (voiceState.isListening) StatusRed else CybNateGreen,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CYB VOICE & MIC PRIVACY",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (voiceState.isListening) StatusRed.copy(alpha = 0.15f) else StatusGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (voiceState.isListening) "MIC ACTIVE" else "MIC OFF",
                                color = if (voiceState.isListening) StatusRed else StatusGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (alwaysListenWakeWord) {
                            "Microphone listens continuously in the background — say \"Hey CybNate\", \"Hello CybNate\", \"Hey Cyb\" or just \"Cyb\" to wake your assistant, then speak your command."
                        } else {
                            "Strict Privacy Mode Active: Microphone is 100% OFF by default. It does not listen to you in the background. It turns ON only when activated, listens for your query, and immediately turns OFF."
                        },
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Continuous Wake Word Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Continuous 'CybNate' Listening",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Background wake words: 'Hey CybNate', 'Hello CybNate', 'Cyb'",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = alwaysListenWakeWord,
                            onCheckedChange = { isChecked ->
                                val prefs = context.getSharedPreferences("cybnate_voice_prefs", Context.MODE_PRIVATE)
                                val isEnrolled = prefs.getBoolean("voice_enrolled", false)
                                
                                if (isChecked && !isEnrolled) {
                                    android.widget.Toast.makeText(context, "Voice Blueprint required. Please enroll first.", android.widget.Toast.LENGTH_LONG).show()
                                    onNavigateToVoiceEnrollment()
                                } else {
                                    alwaysListenWakeWord = isChecked
                                    CybVoiceAssistantManager.setAlwaysListenEnabled(context, isChecked)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CybNateGreen,
                                checkedTrackColor = CybNateGreen.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.testTag("always_listen_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))


                    // Voice Biometric Enrollment Button
                    val prefs = context.getSharedPreferences("cybnate_voice_prefs", Context.MODE_PRIVATE)
                    val isEnrolled = prefs.getBoolean("voice_enrolled", false)
                    
                    Button(
                        onClick = onNavigateToVoiceEnrollment,
                        colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = CybNateGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isEnrolled) "UPDATE VOICE BIOMETRIC" else "ENROLL VOICE BIOMETRIC", color = CybNateGreen, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    // Test Voice Mic Activation Button
                    Button(
                        onClick = {
                            if (voiceState.isListening) {
                                CybVoiceAssistantManager.stopListening()
                            } else {
                                CybVoiceAssistantManager.wakeUpAndListen()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (voiceState.isListening) StatusRed else CybNateGreen
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_voice_activation_btn")
                    ) {
                        Icon(
                            imageVector = if (voiceState.isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (voiceState.isListening) "LISTENING TO YOU (TAP TO STOP)" else "TEST VOICE ACTIVATION (TURN MIC ON)",
                            color = Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- AI BRAIN STATUS CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "AI Status",
                            tint = CybNateGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI ENGINE & BACKUP MODE",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Primary Brain: Gemini 3.5 Flash / 3.1 Pro\nBackup Engine: Local Deterministic AI Planner (Active)",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusGreen.copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Ready",
                                tint = StatusGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AI Central Intelligence Fully Functional",
                                color = StatusGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- HUGGING FACE SPEECH-TO-SPEECH (github.com/huggingface/speech-to-speech) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (hfEnabled) CybNateGreen.copy(alpha = 0.6f) else BorderSubtle, RoundedCornerShape(16.dp))
                    .testTag("hf_speech_to_speech_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Speech Pipeline",
                                tint = if (hfEnabled) CybNateGreen else TextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "HUGGING FACE SPEECH-TO-SPEECH",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "github.com/huggingface/speech-to-speech",
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Switch(
                            checked = hfEnabled,
                            onCheckedChange = { checked ->
                                hfEnabled = checked
                                HfSpeechToSpeechConfig.setEnabled(context, checked)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CybNateGreen,
                                checkedTrackColor = CybNateGreen.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.testTag("hf_s2s_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Connects CybNate to the modular Hugging Face Speech-to-Speech pipeline (Silero VAD + Parakeet/Whisper STT + LLM + Fast TTS) via WebSockets/WebRTC.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = hfServerUrl,
                        onValueChange = {
                            hfServerUrl = it
                            HfSpeechToSpeechConfig.setServerUrl(context, it)
                        },
                        label = { Text("Server WebSocket / Space URL", fontSize = 11.sp) },
                        placeholder = { Text("wss://huggingface-speech-to-speech.hf.space/ws", fontSize = 11.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("hf_server_url_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CybNateGreen,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = hfToken,
                        onValueChange = {
                            hfToken = it
                            HfSpeechToSpeechConfig.setHfToken(context, it)
                        },
                        label = { Text("Hugging Face API Token (Optional, hf_...)", fontSize = 11.sp) },
                        placeholder = { Text("hf_xxxxxxxxxxxxxxxxxxxxxx", fontSize = 11.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("hf_token_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CybNateGreen,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                isTestingConnection = true
                                hfTestStatus = "Testing pipeline handshake..."
                                coroutineScope.launch {
                                    val result = HfSpeechToSpeechClient.testConnection(hfServerUrl, hfToken)
                                    isTestingConnection = false
                                    hfTestStatus = if (result.isSuccess) {
                                        "🟢 " + result.getOrNull()
                                    } else {
                                        "🔴 " + (result.exceptionOrNull()?.message ?: "Connection failed")
                                    }
                                }
                            },
                            enabled = !isTestingConnection,
                            colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("hf_test_connection_btn")
                        ) {
                            if (isTestingConnection) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = SpotifyDark,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = if (isTestingConnection) "Connecting..." else "TEST S2S PIPELINE",
                                color = SpotifyDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (hfEnabled) StatusGreen.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f)
                        ) {
                            Text(
                                text = if (hfEnabled) "PIPELINE ACTIVE" else "STANDBY / OFFLINE READY",
                                color = if (hfEnabled) StatusGreen else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (hfTestStatus != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = hfTestStatus!!,
                            color = if (hfTestStatus!!.startsWith("🟢")) StatusGreen else StatusYellow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // --- AWESOME LLM APPS: AGENTIC MEMORY & REASONING (github.com/Shubhamsaboo/awesome-llm-apps) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CybNateGreen.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .testTag("awesome_llm_apps_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = "AI Memory & Reasoning",
                                tint = CybNateGreen,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "AI MEMORY & REASONING AGENT",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "github.com/Shubhamsaboo/awesome-llm-apps",
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CybNateGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "AGENTIC RAG",
                                color = CybNateGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Deep Multi-Step Reasoning Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Deep Multi-Step Reasoning (CoT Agent)",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Deconstructs questions into Given, Core Laws, Derivation, and JEE -1 Trap Warnings.",
                                color = TextSecondary,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            )
                        }
                        Switch(
                            checked = reasoningMode,
                            onCheckedChange = { checked ->
                                reasoningMode = checked
                                StudentMemoryEngine.setReasoningModeEnabled(context, checked)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CybNateGreen,
                                checkedTrackColor = CybNateGreen.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.testTag("reasoning_mode_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = BorderSubtle)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Student Memory Engine
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PERSISTENT STUDENT MEMORY PROFILE",
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(
                            onClick = {
                                StudentMemoryEngine.resetMemories(context)
                                memoriesList = StudentMemoryEngine.getMemories(context)
                            },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                        ) {
                            Text("Reset", color = TextSecondary, fontSize = 10.sp)
                        }
                    }

                    Text(
                        text = "Autonomous memory agent retains your study goals, weak spots, and pace to personalize every explanation.",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Stored memories list
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        memoriesList.forEach { mem ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SpotifyDark,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = mem,
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = {
                                            StudentMemoryEngine.removeMemory(context, mem)
                                            memoriesList = StudentMemoryEngine.getMemories(context)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Remove Memory",
                                            tint = TextSecondary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Add custom memory
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newMemoryInput,
                            onValueChange = { newMemoryInput = it },
                            placeholder = { Text("Add memory (e.g. Weak in Optics)", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("new_memory_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CybNateGreen,
                                unfocusedBorderColor = BorderSubtle,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (newMemoryInput.isNotBlank()) {
                                    StudentMemoryEngine.addMemory(context, newMemoryInput)
                                    memoriesList = StudentMemoryEngine.getMemories(context)
                                    newMemoryInput = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_memory_btn")
                        ) {
                            Text("ADD", color = SpotifyDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- DANGER ZONE / RESET PROGRESS ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StatusRed.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Reset",
                            tint = StatusRed,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RESET PROGRESS",
                            color = StatusRed,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Reset all chapters, lectures, DPPs, and user statistics to initial starting state.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showResetDialog = true },
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("reset_progress_btn")
                    ) {
                        Text("RESET ALL SYLLABUS DATA", color = StatusRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            containerColor = CardDark,
            title = {
                Text("Confirm Reset Progress", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Are you sure you want to reset all syllabus completion data to the initial state? This action cannot be undone.",
                    color = TextPrimary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                        onResetProgress()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                ) {
                    Text("RESET DATA", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
