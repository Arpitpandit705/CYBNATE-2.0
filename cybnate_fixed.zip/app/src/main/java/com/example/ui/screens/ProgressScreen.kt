package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChapterEntity
import com.example.data.UserStatsEntity
import com.example.ui.theme.*

@Composable
fun ProgressScreen(
    stats: UserStatsEntity,
    chapters: List<ChapterEntity>
) {
    val totalLectures = chapters.sumOf { it.totalLectures }
    val compLectures = chapters.sumOf { it.completedLectures }
    val remLectures = maxOf(0, totalLectures - compLectures)

    val totalDpps = chapters.sumOf { it.totalDpps }
    val compDpps = chapters.sumOf { it.completedDpps }
    val remDpps = maxOf(0, totalDpps - compDpps)

    val completedChaptersCount = chapters.count { it.status == "COMPLETED" }

    val overallPct = if (totalLectures > 0) ((compLectures.toFloat() / totalLectures) * 100).toInt() else 0

    val currentXp = stats.totalXp
    val xpProgress = (currentXp % 500).toFloat() / 500f

    val levelTitle = when (stats.level) {
        1 -> "LEVEL 01 — STARTER"
        2 -> "LEVEL 02 — FOCUS MASTER"
        3 -> "LEVEL 03 — SYLLABUS CRUSHER"
        4 -> "LEVEL 04 — JEE SCHOLAR"
        else -> "LEVEL ${stats.level} — RANK LEGEND"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SpotifyDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "OVERALL SYLLABUS ANALYTICS",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Real-time metrics, streak records, and level progression",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        // --- OVERALL PROGRESS HERO CARD (Section 17) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDarkElevated),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CybNateGreenMuted, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("OVERALL SYLLABUS COMPLETION", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        Text("$overallPct%", color = CybNateGreen, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { overallPct / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = CybNateGreen,
                        trackColor = SurfaceElevated
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "$compLectures / $totalLectures total lectures • $compDpps / $totalDpps total DPPs completed",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // --- LEVEL & XP CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(levelTitle, color = CybNateGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("$currentXp XP", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { xpProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = CybNateGreen,
                        trackColor = SurfaceElevated
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${(currentXp % 500)} / 500 XP to Level ${stats.level + 1}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // --- METRICS GRID ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricBox("Completed Lectures", "$compLectures", "of $totalLectures total", Icons.Default.OndemandVideo, Modifier.weight(1f))
                    MetricBox("Completed DPPs", "$compDpps", "of $totalDpps total", Icons.Default.TaskAlt, Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val remHours = (remLectures * stats.effectiveLectureMinutes) / 60
                    MetricBox("Remaining Study Time", "${remHours}h", "${stats.effectiveLectureMinutes}m/lec @ ${stats.playbackSpeed}x", Icons.Default.HourglassEmpty, Modifier.weight(1f))
                    MetricBox("Remaining DPPs", "$remDpps", "to deadline", Icons.Default.FormatListNumbered, Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricBox("Current Streak", "${stats.currentStreak} Days", "Longest: ${stats.longestStreak}d", Icons.Default.LocalFireDepartment, Modifier.weight(1f))
                    MetricBox("Focus Hours", "${stats.totalFocusMinutes / 60}h ${stats.totalFocusMinutes % 60}m", "Total study time", Icons.Default.Timer, Modifier.weight(1f))
                }
            }
        }

        // --- CHAPTERS COMPLETED METRIC ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceElevated),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed Chapters",
                            tint = CybNateGreen,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("CHAPTERS FULLY COMPLETED", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("$completedChaptersCount / ${chapters.size} Chapters", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricBox(
    title: String,
    value: String,
    subValue: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardDark),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = title, tint = CybNateGreen, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(subValue, color = TextSecondary, fontSize = 11.sp)
        }
    }
}
