package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChapterEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectsScreen(
    chapters: List<ChapterEntity>,
    organicActivated: Boolean,
    onStartTaskFocus: (String, String, Int, Int, String) -> Unit,
    onCompleteDirect: (Int, String) -> Unit,
    onShowLockedMessage: (String) -> Unit
) {
    var selectedSubject by remember { mutableStateOf("PHYSICS") }
    var selectedChapterForDetail by remember { mutableStateOf<ChapterEntity?>(null) }

    val subjectKeys = listOf(
        "PHYSICS" to "Physics",
        "MATHEMATICS" to "Mathematics",
        "PHYSICAL_CHEMISTRY" to "Physical Chem",
        "INORGANIC_CHEMISTRY" to "Inorganic Chem",
        "ORGANIC_CHEMISTRY" to "Organic Chem"
    )

    val currentSubjectChapters = chapters.filter { it.subject == selectedSubject }.sortedBy { it.chapterOrder }

    val totalLec = currentSubjectChapters.sumOf { it.totalLectures }
    val compLec = currentSubjectChapters.sumOf { it.completedLectures }
    val totalDpp = currentSubjectChapters.sumOf { it.totalDpps }
    val compDpp = currentSubjectChapters.sumOf { it.completedDpps }

    val subjectPct = if (totalLec > 0) ((compLec.toFloat() / totalLec) * 100).toInt() else 0

    val activeChapter = currentSubjectChapters.firstOrNull { it.unlocked && it.status != "COMPLETED" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SpotifyDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SUBJECT SYLLABUS COMMAND",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Strict sequential order. A chapter unlocks only when previous lectures AND DPPs are complete.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        // --- SUBJECT TAB SELECTOR ---
        item {
            ScrollableTabRow(
                selectedTabIndex = subjectKeys.indexOfFirst { it.first == selectedSubject },
                containerColor = CardDark,
                contentColor = CybNateGreen,
                edgePadding = 0.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                subjectKeys.forEach { (key, label) ->
                    val isSelected = selectedSubject == key
                    Tab(
                        selected = isSelected,
                        onClick = { selectedSubject = key },
                        modifier = Modifier.testTag("tab_$key")
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) CybNateGreen else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp)
                        )
                    }
                }
            }
        }

        // --- SUBJECT OVERVIEW METRICS CARD ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedSubject.replace("_", " "),
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$subjectPct%",
                            color = CybNateGreen,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { subjectPct / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = CybNateGreen,
                        trackColor = SurfaceElevated
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("LECTURES", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("$compLec / $totalLec", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("DPPs", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("$compDpp / $totalDpp", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("ACTIVE CHAPTER", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(activeChapter?.chapterName ?: "None", color = CybNateGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (selectedSubject == "ORGANIC_CHEMISTRY" && !organicActivated) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = StatusYellow.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🔒 Organic Chemistry activates when Physical Chemistry OR Inorganic Chemistry is completely finished.",
                                color = StatusYellow,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        // --- CHAPTER LIST ---
        item {
            Text(
                text = "CHAPTER SEQUENCE",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(currentSubjectChapters) { chapter ->
            val isLocked = !chapter.unlocked || (chapter.subject == "ORGANIC_CHEMISTRY" && !organicActivated)

            val statusColor = when (chapter.status) {
                "COMPLETED" -> StatusGreen
                "READY_TO_COMPLETE" -> CybNateGreen
                "IN_PROGRESS", "CURRENT" -> StatusYellow
                else -> TextMuted
            }

            val statusText = when {
                isLocked -> "🔒 LOCKED"
                chapter.status == "COMPLETED" -> "✅ COMPLETED"
                chapter.status == "READY_TO_COMPLETE" -> "🏁 READY TO FINISH"
                chapter.status == "IN_PROGRESS" -> "⏳ IN PROGRESS"
                else -> "⚡ CURRENT"
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = if (isLocked) CardDark.copy(alpha = 0.5f) else CardDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (chapter.status == "CURRENT" || chapter.status == "IN_PROGRESS") CybNateGreen else BorderSubtle,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable {
                        selectedChapterForDetail = chapter
                    }
                    .testTag("chapter_card_${chapter.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (isLocked) SurfaceElevated else CybNateGreenGlow,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${chapter.chapterOrder}",
                                        color = if (isLocked) TextMuted else CybNateGreen,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = chapter.chapterName,
                                color = if (isLocked) TextMuted else TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = statusColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = statusText,
                                color = statusColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Lectures: ${chapter.completedLectures} / ${chapter.totalLectures}",
                                color = if (isLocked) TextMuted else TextSecondary,
                                fontSize = 12.sp
                            )
                            if (chapter.totalDpps > 0) {
                                Text(
                                    text = "DPPs: ${chapter.completedDpps} / ${chapter.totalDpps}",
                                    color = if (isLocked) TextMuted else TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        if (!isLocked && chapter.status != "COMPLETED") {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (chapter.completedLectures < chapter.totalLectures) {
                                    Button(
                                        onClick = {
                                            onStartTaskFocus(
                                                chapter.subject,
                                                chapter.chapterName,
                                                chapter.id,
                                                chapter.completedLectures + 1,
                                                "LECTURE"
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp).testTag("lec_btn_${chapter.id}")
                                    ) {
                                        Text("+1 Lec", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (chapter.totalDpps > 0 && chapter.completedDpps < chapter.totalDpps) {
                                    OutlinedButton(
                                        onClick = {
                                            onStartTaskFocus(
                                                chapter.subject,
                                                chapter.chapterName,
                                                chapter.id,
                                                chapter.completedDpps + 1,
                                                "DPP"
                                            )
                                        },
                                        border = androidx.compose.foundation.BorderStroke(1.dp, CybNateGreen),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp).testTag("dpp_btn_${chapter.id}")
                                    ) {
                                        Text("+1 DPP", color = CybNateGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- CHAPTER DETAIL MODAL DIALOG (Section 13) ---
    selectedChapterForDetail?.let { chap ->
        ModalBottomSheet(
            onDismissRequest = { selectedChapterForDetail = null },
            containerColor = CardDarkElevated,
            contentColor = TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = chap.subject.replace("_", " "),
                    color = CybNateGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = chap.chapterName,
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Two Large Progress Sections
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("LECTURES", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${chap.completedLectures} / ${chap.totalLectures}", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("DPP", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${chap.completedDpps} / ${chap.totalDpps}", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                val isChapLocked = !chap.unlocked || (chap.subject == "ORGANIC_CHEMISTRY" && !organicActivated)
                if (isChapLocked) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = StatusYellow.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusYellow.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("🔒 PREREQUISITE NOTICE", color = StatusYellow, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                if (chap.subject == "ORGANIC_CHEMISTRY" && !organicActivated)
                                    "Complete all chapters of Physical or Inorganic Chemistry to unlock Organic Chemistry. You can start focused practice below anytime."
                                else
                                    "This chapter formally unlocks in syllabus sequence after chapter ${chap.chapterOrder - 1}. You can practice or review it now.",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                val nextLec = chap.completedLectures + 1
                val isLec = nextLec <= chap.totalLectures
                val taskType = if (isLec) "LECTURE" else "DPP"
                val taskIdx = if (isLec) nextLec else chap.completedDpps + 1

                if (chap.status != "COMPLETED") {
                    Text("CURRENT TASK", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    val taskDurationNotice = if (taskType == "LECTURE") "96 min (2h @ 1.25x)" else "45 min"
                    Button(
                        onClick = {
                            selectedChapterForDetail = null
                            onStartTaskFocus(chap.subject, chap.chapterName, chap.id, taskIdx, taskType)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text(
                            if (isChapLocked) "START FOCUS PRACTICE • $taskType $taskIdx • $taskDurationNotice"
                            else "START FOCUS • $taskType $taskIdx • $taskDurationNotice",
                            color = Color.Black,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text("CHAPTER QUEUE", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(chap.totalLectures) { i ->
                        val done = i + 1 <= chap.completedLectures
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (done) CybNateGreenGlow else CardDark, RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Lecture ${i + 1} (2h @ 1.25x • 96m)", color = TextPrimary, fontSize = 13.sp)
                            Text(if (done) "✓ Completed" else "Pending", color = if (done) CybNateGreen else TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
