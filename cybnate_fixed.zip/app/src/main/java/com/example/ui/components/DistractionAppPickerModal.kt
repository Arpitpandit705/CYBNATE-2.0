package com.example.ui.components

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val iconBitmap: Bitmap?
)

private fun drawableToBitmap(drawable: Drawable): Bitmap {
    if (drawable is BitmapDrawable && drawable.bitmap != null) {
        return drawable.bitmap
    }
    val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
    val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bitmap
}

// Low-level internal system utilities to hide so user only sees real apps
private val IGNORED_PACKAGES = setOf(
    "com.android.traceur",
    "com.android.stk",
    "com.android.systemui",
    "com.android.shell",
    "com.android.keychain",
    "com.android.providers.telephony",
    "com.android.providers.calendar",
    "com.android.providers.media",
    "com.android.providers.downloads",
    "com.android.providers.contacts",
    "com.android.location.fused",
    "com.android.wallpaper.livepicker",
    "com.android.companiondevicemanager",
    "com.android.internal.display.cutout.emulation",
    "com.android.bluetooth",
    "com.android.bluetoothmidiservice",
    "com.android.mtp",
    "com.android.externalstorage"
)

@Composable
fun DistractionAppPickerModal(
    selectedBlockedPackages: Set<String>,
    onTogglePackage: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var installedApps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(launcherIntent, 0)
            val list = mutableListOf<InstalledAppItem>()
            val seenPackages = mutableSetOf<String>()

            // Popular user-installed / social distractions to prioritize or ensure they are recognized
            for (resolveInfo in resolveInfos) {
                val pkgName = resolveInfo.activityInfo.packageName
                if (pkgName == context.packageName) continue
                if (seenPackages.contains(pkgName)) continue
                if (IGNORED_PACKAGES.contains(pkgName)) continue
                
                val appLabel = resolveInfo.loadLabel(pm).toString()
                val lower = appLabel.lowercase()
                // Filter out system utilities that aren't apps user wants to block
                if (lower == "sim toolkit" || lower == "system tracing" || lower.startsWith("qualcomm") || lower.startsWith("mediatek")) {
                    continue
                }

                seenPackages.add(pkgName)
                val icon = try {
                    val d = resolveInfo.loadIcon(pm)
                    drawableToBitmap(d)
                } catch (e: Throwable) {
                    null
                }

                list.add(InstalledAppItem(packageName = pkgName, appName = appLabel, iconBitmap = icon))
            }

            // Fallback: Also check if WhatsApp, YouTube, Instagram, etc. exist via PackageManager even if intent query missed
            val popularApps = listOf(
                "com.instagram.android" to "Instagram",
                "com.google.android.youtube" to "YouTube",
                "com.whatsapp" to "WhatsApp",
                "com.facebook.katana" to "Facebook",
                "com.snapchat.android" to "Snapchat",
                "org.telegram.messenger" to "Telegram",
                "com.telegram.messenger" to "Telegram",
                "com.netflix.mediaclient" to "Netflix",
                "com.spotify.music" to "Spotify",
                "com.reddit.frontpage" to "Reddit",
                "com.discord" to "Discord",
                "com.twitter.android" to "X (Twitter)"
            )

            for ((pkg, defaultName) in popularApps) {
                if (!seenPackages.contains(pkg)) {
                    try {
                        val appInfo = pm.getApplicationInfo(pkg, 0)
                        val name = pm.getApplicationLabel(appInfo).toString().ifBlank { defaultName }
                        val icon = try {
                            drawableToBitmap(pm.getApplicationIcon(appInfo))
                        } catch (t: Throwable) {
                            null
                        }
                        seenPackages.add(pkg)
                        list.add(InstalledAppItem(packageName = pkg, appName = name, iconBitmap = icon))
                    } catch (_: PackageManager.NameNotFoundException) {
                        // Not installed on this specific emulator/device
                    } catch (_: Throwable) {}
                }
            }

            // Sort alphabetically
            installedApps = list.sortedBy { it.appName }
            isLoading = false
        }
    }

    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) installedApps
        else installedApps.filter { it.appName.contains(searchQuery, ignoreCase = true) || it.packageName.contains(searchQuery, ignoreCase = true) }
    }

    Surface(
        color = SpotifyDark,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = null,
                        tint = StatusRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "DISTRACTION APP PICKER",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "${selectedBlockedPackages.size} apps selected for blocking",
                            color = CybNateGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(40.dp)
                        .background(CardDark, RoundedCornerShape(10.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search apps (e.g. YouTube, WhatsApp)...", color = TextSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CybNateGreen) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CybNateGreen,
                    unfocusedBorderColor = BorderSubtle,
                    focusedContainerColor = CardDark,
                    unfocusedContainerColor = CardDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = CybNateGreen)
                }
            } else if (filteredApps.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No apps found", color = TextSecondary, fontSize = 14.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val isSelected = selectedBlockedPackages.contains(app.packageName)
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) StatusRed.copy(alpha = 0.15f) else CardDark
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (isSelected) StatusRed else BorderSubtle,
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { onTogglePackage(app.packageName) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    // App Icon
                                    if (app.iconBitmap != null) {
                                        Image(
                                            bitmap = app.iconBitmap.asImageBitmap(),
                                            contentDescription = app.appName,
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                        )
                                    } else {
                                        Surface(
                                            modifier = Modifier.size(42.dp),
                                            shape = RoundedCornerShape(10.dp),
                                            color = SurfaceElevated
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = app.appName.take(1).uppercase(),
                                                    color = TextPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Text(
                                            text = app.appName,
                                            color = TextPrimary,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = app.packageName,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { onTogglePackage(app.packageName) },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = StatusRed,
                                        uncheckedColor = TextSecondary,
                                        checkmarkColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(
                    text = "DONE (${selectedBlockedPackages.size} APPS BLOCKED)",
                    color = Color.Black,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }
        }
    }
}

