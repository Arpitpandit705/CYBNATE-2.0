package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.service.CybVoiceState
import com.example.ui.theme.*

@Composable
fun CybVoiceAssistantModal(
    voiceState: CybVoiceState,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onDismiss: () -> Unit,
    onAskQuestion: (String) -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (voiceState.isListening || voiceState.isSpeaking) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val sampleQueries = listOf(
        "What's my next lecture?",
        "Start physics",
        "Am I on track for IIT JEE?",
        "Explain Lenz's Law"
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = CardDarkElevated,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CybNateGreen),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = CybNateGreen,
                            modifier = Modifier.size(10.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CYB VOICE ASSISTANT",
                            color = CybNateGreen,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Pulsing Voice Orb
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(110.dp)
                        .scale(pulseScale)
                        .background(
                            color = if (voiceState.isSpeaking) CybNateGreen.copy(alpha = 0.2f)
                            else if (voiceState.isListening) StatusRed.copy(alpha = 0.25f)
                            else CybNateGreenGlow,
                            shape = CircleShape
                        )
                        .border(
                            2.dp,
                            if (voiceState.isListening) StatusRed else CybNateGreen,
                            CircleShape
                        )
                        .clickable {
                            if (voiceState.isListening) onStopListening() else onStartListening()
                        }
                ) {
                    Icon(
                        imageVector = if (voiceState.isSpeaking) Icons.Default.VolumeUp
                        else if (voiceState.isListening) Icons.Default.GraphicEq
                        else Icons.Default.Mic,
                        contentDescription = "Voice State",
                        tint = if (voiceState.isListening) StatusRed else CybNateGreen,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = if (voiceState.isSpeaking) "Cyb is speaking • Mic is OFF"
                    else if (voiceState.isListening) "Mic is ON • Listening to you..."
                    else "Mic is OFF • Tap Orb to speak",
                    color = if (voiceState.isListening) StatusRed else CybNateGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (voiceState.recognizedText.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CardDark,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("YOU SAID:", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(voiceState.recognizedText, color = TextPrimary, fontSize = 14.sp)
                        }
                    }
                }

                if (voiceState.assistantResponse.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SpotifyDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("CYB RESPONSE:", color = CybNateGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(voiceState.assistantResponse, color = TextPrimary, fontSize = 14.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Question Suggestions
                Text("QUICK VOICE PROMPTS", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    sampleQueries.take(2).forEach { query ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    onAskQuestion(query)
                                }
                        ) {
                            Text(
                                text = "💬 $query",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            if (voiceState.isListening) onStopListening() else onStartListening()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (voiceState.isListening) StatusRed else CybNateGreen
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Text(
                            text = if (voiceState.isListening) "STOP LISTENING" else "SPEAK TO CYB",
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
