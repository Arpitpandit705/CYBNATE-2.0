package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CybNateDarkColorScheme = darkColorScheme(
    primary = CybNateGreen,
    onPrimary = Color(0xFF052012),
    primaryContainer = Color(0xFF123B28),
    onPrimaryContainer = Color(0xFFA9F5CB),
    secondary = CybTeal,
    onSecondary = Color(0xFF03252B),
    secondaryContainer = Color(0xFF0E2F36),
    onSecondaryContainer = Color(0xFFA5F3FC),
    tertiary = CybViolet,
    onTertiary = Color(0xFF1E1240),
    tertiaryContainer = Color(0xFF2E2452),
    onTertiaryContainer = Color(0xFFDDD0FE),
    background = SpotifyDark,
    onBackground = TextPrimary,
    surface = CardDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = Color(0xFF080A0E),
    surfaceContainerLow = Color(0xFF10151B),
    surfaceContainer = CardDarkElevated,
    surfaceContainerHigh = Color(0xFF1B232C),
    surfaceContainerHighest = SurfaceElevated,
    outline = BorderSubtle,
    outlineVariant = BorderHighlight,
    error = StatusRed,
    onError = Color(0xFF3B0A0A),
    errorContainer = Color(0xFF4A1D1D),
    onErrorContainer = Color(0xFFFECACA),
    inverseSurface = LightSurfaceElevated,
    inverseOnSurface = LightTextPrimary,
    inversePrimary = LightPrimaryGreen,
    scrim = Color(0xB3000000)
)

private val CybNateLightColorScheme = lightColorScheme(
    primary = LightPrimaryGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCFF5E2),
    onPrimaryContainer = Color(0xFF064E3B),
    secondary = LightAccentTeal,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCBF0F8),
    onSecondaryContainer = Color(0xFF083344),
    tertiary = LightAccentViolet,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFE9E2FC),
    onTertiaryContainer = Color(0xFF2E1A63),
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = LightTextSecondary,
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = LightBackground,
    surfaceContainer = LightSurfaceElevated,
    surfaceContainerHigh = Color(0xFFDFE7EF),
    surfaceContainerHighest = Color(0xFFD3DDE8),
    outline = LightBorderSubtle,
    outlineVariant = LightBorderHighlight,
    error = Color(0xFFDC2626),
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D),
    inverseSurface = Color(0xFF1A212B),
    inverseOnSurface = TextPrimary,
    inversePrimary = CybNateGreen,
    scrim = Color(0x73000000)
)

@Composable
fun CybNateTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) CybNateDarkColorScheme else CybNateLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
