package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.ActiveFocusSessionData
import com.example.viewmodel.CybNateUiState
import kotlinx.coroutines.delay

@Composable
fun FocusScreen(
    state: CybNateUiState,
    session: ActiveFocusSessionData?,
    onToggleTimer: () -> Unit,
    onTick: () -> Unit,
    onFinishSession: (Boolean) -> Unit,
    onEmergencyPause: () -> Unit,
    onMinimize: () -> Unit = {},
    onStartMission: () -> Unit = {}
) {
    var showCompletionModal by remember { mutableStateOf(false) }

    if (session == null) {
        // Empty State (Section 29)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SpotifyDark)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = "No Session",
                    tint = CybNateGreen,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "NO ACTIVE FOCUS SESSION",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Start your 96-minute (2h @ 1.25x) focused study cycle now with distracting apps locked.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onStartMission,
                    colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(48.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("START NEXT MISSION (96 MIN)", color = Color.Black, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))
                TextButton(onClick = onMinimize) {
                    Text("← Back to Home", color = TextSecondary)
                }
            }
        }
        return
    }

    val totalSec = session.targetDurationMinutes * 60
    val remSec = maxOf(0, totalSec - session.elapsedSeconds)
    val progress = if (totalSec > 0) (session.elapsedSeconds.toFloat() / totalSec).coerceIn(0f, 1f) else 0f
    val isPaused = !session.isRunning

    val mins = remSec / 60
    val secs = remSec % 60
    val timeDisplay = String.format("%02d:%02d", mins, secs)
    val elapsedMins = session.elapsedSeconds / 60

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SpotifyDark)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP APP BAR WITH MINIMIZE & PAUSE
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMinimize) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = "Minimize",
                    tint = TextPrimary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Text(
                text = "CYBNATE STUDY LOCK",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            IconButton(onClick = onEmergencyPause) {
                Icon(
                    imageVector = Icons.Default.PauseCircle,
                    contentDescription = "Emergency Pause",
                    tint = StatusYellow,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // TOP HEADER
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CybNateGreenGlow,
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Text(
                    text = "${session.subject.replace("_", " ")} • ${session.taskType} ${session.itemIndex}",
                    color = CybNateGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = session.chapterName,
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Psychology, contentDescription = null, tint = CybNateGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                val paceInfo = if (session.taskType == "LECTURE") "2h @ ${session.playbackSpeed}x • ${session.targetDurationMinutes} min target" else "${session.targetDurationMinutes} min target"
                Text(
                    text = "$paceInfo • Focus: $elapsedMins min",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // CENTRAL DIAL (Section 15)
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(260.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Background Track
                drawCircle(
                    color = SurfaceElevated,
                    style = Stroke(width = 16.dp.toPx())
                )
                // Active CybNate Green Fill Arc
                drawArc(
                    color = CybNateGreen,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    style = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = timeDisplay,
                    color = TextPrimary,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (isPaused) "PAUSED" else if (session.taskType == "LECTURE") "${session.targetDurationMinutes} MIN (2H @ ${session.playbackSpeed}X)" else "${session.targetDurationMinutes} MIN MISSION",
                    color = if (isPaused) StatusYellow else CybNateGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // BOTTOM CONTROLS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onToggleTimer,
                    colors = ButtonDefaults.buttonColors(containerColor = CardDarkElevated),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .border(1.dp, BorderHighlight, RoundedCornerShape(14.dp))
                        .testTag("focus_pause_resume_btn")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = "Pause",
                            tint = if (isPaused) CybNateGreen else TextPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isPaused) "RESUME" else "PAUSE",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Button(
                    onClick = { showCompletionModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("focus_finish_btn")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Finish",
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "VERIFY & COMPLETE",
                            color = Color.Black,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            TextButton(
                onClick = onEmergencyPause,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Emergency Pause / Exit Focus", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }

    // FOCUS COMPLETION MODAL
    if (showCompletionModal) {
        AlertDialog(
            onDismissRequest = { showCompletionModal = false },
            containerColor = CardDarkElevated,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = {
                Text(
                    text = "AI FOCUS VERIFICATION",
                    color = CybNateGreen,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            },
            text = {
                Column {
                    Text(
                        text = "${session.subject.replace("_", " ")} — ${session.chapterName}",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Task: ${session.taskType} ${session.itemIndex} • Target: ${session.targetDurationMinutes} min (2h @ ${session.playbackSpeed}x) • Focused: $elapsedMins min",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "CybNate AI will evaluate session signals and update your 5-lecture daily mission progress.",
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCompletionModal = false
                        onFinishSession(true)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CybNateGreen)
                ) {
                    Text("VERIFY & RECORD", color = Color.Black, fontWeight = FontWeight.ExtraBold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showCompletionModal = false
                        onFinishSession(false)
                    }
                ) {
                    Text("CANCEL SESSION", color = StatusRed, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
