package com.example.repository

import com.example.data.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CybNateRepository(private val dao: CybNateDao) {

    val allChapters: Flow<List<ChapterEntity>> = dao.getAllChapters()
    val userStats: Flow<UserStatsEntity?> = dao.getUserStats()
    val recoveryTasks: Flow<List<RecoveryTaskEntity>> = dao.getUnresolvedRecoveryTasks()
    val focusSessions: Flow<List<FocusSessionEntity>> = dao.getAllFocusSessions()

    suspend fun populateIfEmpty() {
        val chapters = dao.getAllChaptersSync()
        if (chapters.isEmpty()) {
            dao.deleteAllChapters()
            dao.insertChapters(InitialSyllabus.initialChapters)
            if (dao.getUserStatsSync() == null) {
                dao.insertUserStats(
                    UserStatsEntity(
                        id = 1,
                        deadlineDate = "2027-01-05", // 5 January 2027
                        dailyLectureTarget = 5,
                        currentStreak = 1,
                        longestStreak = 1,
                        totalXp = 150,
                        level = 1,
                        lastStudyDate = "",
                        totalFocusMinutes = 45,
                        preferredStudyHours = "08:00 - 22:00",
                        organicActivated = false,
                        lectureBaseHours = 2.0f,
                        playbackSpeed = 1.25f
                    )
                )
            }
        }
    }

    fun getDailyTasks(date: String): Flow<List<DailyTaskEntity>> = dao.getDailyTasks(date)

    suspend fun getActiveChapter(subject: String): ChapterEntity? {
        return dao.getActiveChapterForSubject(subject)
    }

    suspend fun completeTask(
        chapterId: Int,
        taskType: String, // "LECTURE", "DPP"
        durationMinutes: Int
    ): Pair<String, ChapterEntity?> {
        val chapter = dao.getChapterById(chapterId) ?: return Pair("Chapter not found", null)
        val currentStats = dao.getUserStatsSync() ?: UserStatsEntity()

        var newCompletedLec = chapter.completedLectures
        var newCompletedDpp = chapter.completedDpps
        var xpEarned = 0L
        var progressed = false

        if (taskType == "LECTURE") {
            if (newCompletedLec < chapter.totalLectures) {
                newCompletedLec += 1
                xpEarned += 50L
                progressed = true
            }
        } else if (taskType == "DPP") {
            if (newCompletedDpp < chapter.totalDpps) {
                newCompletedDpp += 1
                xpEarned += 30L
                progressed = true
            }
        }

        // Check completion criteria
        val isLecturesDone = newCompletedLec >= chapter.totalLectures
        val isDppsDone = chapter.totalDpps == 0 || newCompletedDpp >= chapter.totalDpps
        val isChapterComplete = isLecturesDone && isDppsDone

        val newStatus = when {
            isChapterComplete -> "COMPLETED"
            isLecturesDone -> "READY_TO_COMPLETE"
            newCompletedLec > 0 || newCompletedDpp > 0 -> "IN_PROGRESS"
            else -> "CURRENT"
        }

        val updatedChapter = chapter.copy(
            completedLectures = newCompletedLec,
            completedDpps = newCompletedDpp,
            status = newStatus,
            completedAt = if (isChapterComplete) System.currentTimeMillis() else chapter.completedAt
        )

        dao.updateChapter(updatedChapter)

        if (isChapterComplete && chapter.status != "COMPLETED") {
            xpEarned += 500L // Chapter completion bonus
            unlockNextChapterInSubject(chapter.subject, chapter.chapterOrder)
            checkOrganicChemistryActivation()
        }

        // Nothing left to complete for this task type: don't award XP, bump streaks,
        // or log a phantom focus session.
        if (!progressed) {
            val nothingMsg = if (taskType == "LECTURE") {
                "All lectures for ${chapter.chapterName} are already completed."
            } else {
                "All DPPs for ${chapter.chapterName} are already completed."
            }
            return Pair(nothingMsg, chapter)
        }

        // Update User Stats
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val isNewDay = currentStats.lastStudyDate != todayStr
        val newStreak = if (isNewDay) currentStats.currentStreak + 1 else currentStats.currentStreak
        val newLongestStreak = maxOf(newStreak, currentStats.longestStreak)
        val newTotalXp = currentStats.totalXp + xpEarned
        val newLevel = (newTotalXp / 500).toInt() + 1
        val newFocusMinutes = currentStats.totalFocusMinutes + durationMinutes

        dao.updateUserStats(
            currentStats.copy(
                totalXp = newTotalXp,
                level = newLevel,
                currentStreak = newStreak,
                longestStreak = newLongestStreak,
                lastStudyDate = todayStr,
                totalFocusMinutes = newFocusMinutes
            )
        )

        // Log focus session
        dao.insertFocusSession(
            FocusSessionEntity(
                startTime = System.currentTimeMillis() - (durationMinutes * 60 * 1000L),
                endTime = System.currentTimeMillis(),
                durationMinutes = durationMinutes,
                subject = chapter.subject,
                chapterName = chapter.chapterName,
                itemIndex = if (taskType == "LECTURE") newCompletedLec else newCompletedDpp,
                taskType = taskType,
                completed = true,
                verificationStatus = if (durationMinutes >= 15) "VERIFIED" else "NEEDS_CONFIRMATION"
            )
        )

        val message = if (isChapterComplete) {
            "🎉 Chapter Completed! +${xpEarned} XP! Next chapter unlocked."
        } else {
            "✅ Task completed! +${xpEarned} XP."
        }

        return Pair(message, updatedChapter)
    }

    private suspend fun unlockNextChapterInSubject(subject: String, completedOrder: Int) {
        val subjectChapters = dao.getChaptersBySubjectSync(subject)
        val nextChapter = subjectChapters.firstOrNull { it.chapterOrder == completedOrder + 1 }
        if (nextChapter != null && !nextChapter.unlocked) {
            dao.updateChapter(
                nextChapter.copy(
                    unlocked = true,
                    status = "CURRENT"
                )
            )
        }
    }

    suspend fun checkOrganicChemistryActivation() {
        val physicalChapters = dao.getChaptersBySubjectSync("PHYSICAL_CHEMISTRY")
        val inorganicChapters = dao.getChaptersBySubjectSync("INORGANIC_CHEMISTRY")

        val physicalFinished = physicalChapters.isNotEmpty() && physicalChapters.all { it.status == "COMPLETED" }
        val inorganicFinished = inorganicChapters.isNotEmpty() && inorganicChapters.all { it.status == "COMPLETED" }

        if (physicalFinished || inorganicFinished) {
            val stats = dao.getUserStatsSync() ?: UserStatsEntity()
            if (!stats.organicActivated) {
                dao.updateUserStats(stats.copy(organicActivated = true))
                val organicChapters = dao.getChaptersBySubjectSync("ORGANIC_CHEMISTRY")
                val firstOrganic = organicChapters.firstOrNull()
                if (firstOrganic != null && !firstOrganic.unlocked) {
                    dao.updateChapter(firstOrganic.copy(unlocked = true, status = "CURRENT"))
                }
            }
        }
    }

    suspend fun addMissedTaskToRecovery(subject: String, chapterName: String, taskType: String, itemIndex: Int) {
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        dao.insertRecoveryTask(
            RecoveryTaskEntity(
                subject = subject,
                chapterName = chapterName,
                itemIndex = itemIndex,
                taskType = taskType,
                addedDate = todayStr,
                isResolved = false
            )
        )
    }

    suspend fun updateDeadlineDate(newDeadline: String) {
        val stats = dao.getUserStatsSync() ?: UserStatsEntity()
        dao.updateUserStats(stats.copy(deadlineDate = newDeadline))
    }

    suspend fun updateDailyTarget(target: Int) {
        val stats = dao.getUserStatsSync() ?: UserStatsEntity()
        dao.updateUserStats(stats.copy(dailyLectureTarget = target))
    }

    suspend fun updatePlaybackSettings(baseHours: Float, speed: Float) {
        val stats = dao.getUserStatsSync() ?: UserStatsEntity()
        dao.updateUserStats(stats.copy(lectureBaseHours = baseHours, playbackSpeed = speed))
    }

    suspend fun resetAllProgress() {
        dao.deleteAllChapters()
        dao.insertChapters(InitialSyllabus.initialChapters)
        dao.deleteAllDailyTasks()
        dao.deleteAllRecoveryTasks()
        dao.insertUserStats(
            UserStatsEntity(
                id = 1,
                deadlineDate = "2027-01-05",
                dailyLectureTarget = 5,
                currentStreak = 1,
                longestStreak = 1,
                totalXp = 150,
                level = 1,
                lastStudyDate = "",
                totalFocusMinutes = 45,
                organicActivated = false,
                lectureBaseHours = 2.0f,
                playbackSpeed = 1.25f
            )
        )
    }
}
