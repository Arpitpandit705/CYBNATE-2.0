package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CybNateDao {
    // --- CHAPTERS ---
    @Query("SELECT * FROM chapters ORDER BY subject, chapterOrder ASC")
    fun getAllChapters(): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters ORDER BY subject, chapterOrder ASC")
    suspend fun getAllChaptersSync(): List<ChapterEntity>

    @Query("SELECT * FROM chapters WHERE subject = :subject ORDER BY chapterOrder ASC")
    fun getChaptersBySubject(subject: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE subject = :subject ORDER BY chapterOrder ASC")
    suspend fun getChaptersBySubjectSync(subject: String): List<ChapterEntity>

    @Query("SELECT * FROM chapters WHERE subject = :subject AND unlocked = 1 AND status != 'COMPLETED' ORDER BY chapterOrder ASC LIMIT 1")
    suspend fun getActiveChapterForSubject(subject: String): ChapterEntity?

    @Query("SELECT * FROM chapters WHERE id = :id")
    suspend fun getChapterById(id: Int): ChapterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Query("DELETE FROM chapters")
    suspend fun deleteAllChapters()

    // --- DAILY TASKS ---
    @Query("SELECT * FROM daily_tasks WHERE date = :date ORDER BY id ASC")
    fun getDailyTasks(date: String): Flow<List<DailyTaskEntity>>

    @Query("SELECT * FROM daily_tasks WHERE date = :date ORDER BY id ASC")
    suspend fun getDailyTasksSync(date: String): List<DailyTaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyTasks(tasks: List<DailyTaskEntity>)

    @Update
    suspend fun updateDailyTask(task: DailyTaskEntity)

    @Query("DELETE FROM daily_tasks WHERE date = :date")
    suspend fun deleteDailyTasksForDate(date: String)

    @Query("DELETE FROM daily_tasks")
    suspend fun deleteAllDailyTasks()

    // --- FOCUS SESSIONS ---
    @Query("SELECT * FROM focus_sessions ORDER BY startTime DESC")
    fun getAllFocusSessions(): Flow<List<FocusSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFocusSession(session: FocusSessionEntity)

    // --- USER STATS ---
    @Query("SELECT * FROM user_stats WHERE id = 1")
    fun getUserStats(): Flow<UserStatsEntity?>

    @Query("SELECT * FROM user_stats WHERE id = 1")
    suspend fun getUserStatsSync(): UserStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserStats(stats: UserStatsEntity)

    @Update
    suspend fun updateUserStats(stats: UserStatsEntity)

    // --- RECOVERY TASKS ---
    @Query("SELECT * FROM recovery_tasks WHERE isResolved = 0 ORDER BY id ASC")
    fun getUnresolvedRecoveryTasks(): Flow<List<RecoveryTaskEntity>>

    @Query("SELECT * FROM recovery_tasks WHERE isResolved = 0 ORDER BY id ASC")
    suspend fun getUnresolvedRecoveryTasksSync(): List<RecoveryTaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecoveryTask(task: RecoveryTaskEntity)

    @Update
    suspend fun updateRecoveryTask(task: RecoveryTaskEntity)

    @Query("DELETE FROM recovery_tasks")
    suspend fun deleteAllRecoveryTasks()

    // --- CHAT MESSAGES ---
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllChatMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatHistory()
}
