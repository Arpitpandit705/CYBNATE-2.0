package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String, // "PHYSICS", "MATHEMATICS", "ORGANIC_CHEMISTRY", "PHYSICAL_CHEMISTRY", "INORGANIC_CHEMISTRY"
    val chapterOrder: Int,
    val chapterName: String,
    val totalLectures: Int,
    val completedLectures: Int = 0,
    val totalDpps: Int = 0,
    val completedDpps: Int = 0,
    val status: String = "LOCKED", // "LOCKED", "CURRENT", "IN_PROGRESS", "READY_TO_COMPLETE", "COMPLETED"
    val unlocked: Boolean = false,
    val startedAt: Long? = null,
    val completedAt: Long? = null
)
