package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_tasks")
data class DailyTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // "YYYY-MM-DD"
    val subject: String,
    val chapterName: String,
    val lectureNumber: Int = 0,
    val dppNumber: Int = 0,
    val taskType: String, // "LECTURE", "DPP"
    val timeSlot: String = "", // e.g. "08:00"
    val status: String = "PENDING", // "PENDING", "COMPLETED", "RECOVERY", "MISSED"
    val estimatedDurationMinutes: Int = 60,
    val actualDurationMinutes: Int = 0,
    val verificationStatus: String = "UNVERIFIED", // "VERIFIED", "NEEDS_CONFIRMATION", "UNVERIFIED"
    val notes: String = ""
)
