package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recovery_tasks")
data class RecoveryTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val chapterName: String,
    val itemIndex: Int,
    val taskType: String, // "LECTURE", "DPP"
    val addedDate: String,
    val isResolved: Boolean = false
)
