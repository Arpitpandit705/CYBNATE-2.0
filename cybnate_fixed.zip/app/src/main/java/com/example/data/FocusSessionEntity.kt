package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val startTime: Long,
    val endTime: Long,
    val durationMinutes: Int,
    val subject: String,
    val chapterName: String,
    val itemIndex: Int,
    val taskType: String, // "LECTURE", "DPP"
    val completed: Boolean,
    val userConfirmation: String = "YES",
    val verificationStatus: String = "VERIFIED" // "VERIFIED", "NEEDS_CONFIRMATION"
)
