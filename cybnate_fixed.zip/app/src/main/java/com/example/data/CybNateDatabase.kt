package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ChapterEntity::class,
        DailyTaskEntity::class,
        FocusSessionEntity::class,
        UserStatsEntity::class,
        RecoveryTaskEntity::class,
        ChatMessageEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class CybNateDatabase : RoomDatabase() {
    abstract fun dao(): CybNateDao

    companion object {
        @Volatile
        private var INSTANCE: CybNateDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): CybNateDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CybNateDatabase::class.java,
                    "cybnate_database"
                )
                .addCallback(DatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database.dao())
                    }
                }
            }

            override fun onDestructiveMigration(db: SupportSQLiteDatabase) {
                super.onDestructiveMigration(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database.dao())
                    }
                }
            }

            suspend fun populateDatabase(dao: CybNateDao) {
                dao.deleteAllChapters()
                dao.insertChapters(InitialSyllabus.initialChapters)
                dao.insertUserStats(
                    UserStatsEntity(
                        id = 1,
                        deadlineDate = "2027-01-05", // 5 January 2027
                        dailyLectureTarget = 5,
                        currentStreak = 1,
                        longestStreak = 1,
                        totalXp = 150,
                        level = 1,
                        lastStudyDate = "",
                        totalFocusMinutes = 45,
                        preferredStudyHours = "08:00 - 22:00",
                        organicActivated = false,
                        lectureBaseHours = 2.0f,
                        playbackSpeed = 1.25f
                    )
                )
            }
        }
    }
}
