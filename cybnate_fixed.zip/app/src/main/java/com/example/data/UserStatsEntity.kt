package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey val id: Int = 1,
    val deadlineDate: String = "2027-01-05", // "5 January 2027" in YYYY-MM-DD
    val dailyLectureTarget: Int = 5,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val totalXp: Long = 0,
    val level: Int = 1,
    val lastStudyDate: String = "",
    val totalFocusMinutes: Int = 0,
    val preferredStudyHours: String = "08:00-22:00",
    val organicActivated: Boolean = false,
    val lectureBaseHours: Float = 2.0f,
    val playbackSpeed: Float = 1.25f
) {
    val effectiveLectureMinutes: Int
        get() = ((lectureBaseHours * 60) / playbackSpeed).toInt() // 2hr (120min) / 1.25 = 96 min
}
