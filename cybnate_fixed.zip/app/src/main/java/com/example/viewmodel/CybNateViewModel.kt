package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.*
import com.example.data.*
import com.example.repository.CybNateRepository
import com.example.service.AppBlockingManager
import com.example.service.CybFloatingIslandService
import com.example.service.CybVoiceAssistantManager
import com.example.service.CybVoiceCommandDispatcher
import com.example.service.VoiceCommandResult
import com.example.service.FocusMonitorService
import com.example.util.NetworkMonitor
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class ActiveFocusSessionData(
    val subject: String,
    val chapterName: String,
    val chapterId: Int,
    val itemIndex: Int,
    val taskType: String, // "LECTURE", "DPP"
    val targetDurationMinutes: Int = 96,
    val elapsedSeconds: Int = 0,
    val isRunning: Boolean = false,
    val baseDurationHours: Float = 2.0f,
    val playbackSpeed: Float = 1.25f,
    // Wall-clock anchor for drift-free timing. While running:
    // elapsedSeconds == (now - startedAtMs) / 1000. On pause the computed
    // elapsed is frozen into elapsedSeconds and re-anchored on resume, so
    // backgrounding the app or missed 1s ticks can never skew the timer.
    val startedAtMs: Long = System.currentTimeMillis()
)

data class CybNateUiState(
    val userStats: UserStatsEntity = UserStatsEntity(),
    val allChapters: List<ChapterEntity> = emptyList(),
    val recoveryTasks: List<RecoveryTaskEntity> = emptyList(),
    val activeChapters: Map<String, ChapterEntity?> = emptyMap(),
    val todayTimeline: List<AiDailyScheduleItem> = emptyList(),
    val riskAnalysis: AiRiskAnalysis? = null,
    val aiCoachMessages: List<Pair<String, String>> = listOf(
        Pair("CYBNATE", "Welcome to CybNate. I am your AI study command center brain. Ask me anything about your progress, pace, or deadline!")
    ),
    val activeFocusSession: ActiveFocusSessionData? = null,
    val toastMessage: String? = null,
    val isFocusModeActive: Boolean = false,
    val selectedTab: String = "HOME", // "HOME", "PLAN", "SUBJECTS", "FOCUS", "PROGRESS", "COACH", "SETTINGS"
    val isDarkTheme: Boolean = true,
    val isOnline: Boolean = true,
    val feedbackBannerMessage: String? = null,
    val feedbackBannerIcon: String? = null,

    // --- HARD STUDY LOCK & AI VERIFICATION ---
    val isStudyLockActive: Boolean = true,
    val missionCompletedCount: Int = 0,
    val missionTotalTarget: Int = 5,
    val optInScreenMonitoring: Boolean = true,
    val distractionAttemptsCount: Int = 0,
    val primaryLearningApp: String = "PW (Physics Wallah)",
    val primaryLearningAppPackage: String = "com.pw.live",
    val customBlocklist: Set<String> = emptySet(),
    val showDistractionAppPicker: Boolean = false,

    // --- DIALOG & MODAL VISIBILITY ---
    val showStartFocusModal: Boolean = false,
    val showDistractionIntervention: Boolean = false,
    val showEmergencyPauseDialog: Boolean = false,
    val showMissionCompleteCelebration: Boolean = false,
    val showPermissionsModal: Boolean = false,
    val verificationPending: Boolean = false,
    val verificationDecision: AiVerificationDecision? = null,
    val pendingFocusSubject: String? = null,
    val pendingFocusChapterName: String? = null,
    val pendingFocusChapterId: Int? = null,
    val pendingFocusItemIndex: Int? = null,
    val pendingFocusTaskType: String? = null
)

class CybNateViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CybNateRepository
    private val database: CybNateDatabase
    private val networkMonitor: NetworkMonitor
    private val _uiState = MutableStateFlow(CybNateUiState())
    val uiState: StateFlow<CybNateUiState> = _uiState.asStateFlow()

    init {
        database = CybNateDatabase.getDatabase(application, viewModelScope)
        repository = CybNateRepository(database.dao())
        networkMonitor = NetworkMonitor(application)

        // Observe real-time network status
        viewModelScope.launch {
            networkMonitor.isOnline.collect { online ->
                _uiState.update { it.copy(isOnline = online) }
            }
        }

        // Load the persisted custom block list so the picker and state agree with the services
        _uiState.update {
            it.copy(customBlocklist = AppBlockingManager.getCustomBlockedPackages(application))
        }

        // Observe persisted chat history from Room DB
        viewModelScope.launch {
            database.dao().getAllChatMessages().collect { dbMessages ->
                if (dbMessages.isNotEmpty()) {
                    val messagesList = dbMessages.map { Pair(it.sender, it.content) }
                    _uiState.update { it.copy(aiCoachMessages = messagesList) }
                }
            }
        }

        // Initialize Cyb Voice Assistant Manager with speech callback
        CybVoiceAssistantManager.init(application) { spokenQuery ->
            when (val result = CybVoiceCommandDispatcher.dispatch(spokenQuery, this)) {
                is VoiceCommandResult.Executed -> {
                    CybVoiceAssistantManager.speak(result.spokenFeedback)
                }
                is VoiceCommandResult.AskAi -> {
                    askAiCoach(result.originalQuery, speakAnswer = true)
                }
            }
        }

        viewModelScope.launch {
            repository.populateIfEmpty()
            combine(
                repository.userStats.filterNotNull(),
                repository.allChapters,
                repository.recoveryTasks
            ) { stats, chapters, recovery ->
                Triple(stats, chapters, recovery)
            }.collect { (stats, chapters, recovery) ->
                // Reset the daily mission / study lock when the last completed study day is not today.
                val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                if (stats.lastStudyDate.isNotBlank() && stats.lastStudyDate != todayStr &&
                    (_uiState.value.missionCompletedCount > 0 || !_uiState.value.isStudyLockActive)
                ) {
                    _uiState.update {
                        it.copy(
                            missionCompletedCount = 0,
                            isStudyLockActive = true,
                            distractionAttemptsCount = 0
                        )
                    }
                }
                val activeMap = mapOf(
                    "PHYSICS" to chapters.firstOrNull { it.subject == "PHYSICS" && it.unlocked && it.status != "COMPLETED" },
                    "MATHEMATICS" to chapters.firstOrNull { it.subject == "MATHEMATICS" && it.unlocked && it.status != "COMPLETED" },
                    "INORGANIC_CHEMISTRY" to chapters.firstOrNull { it.subject == "INORGANIC_CHEMISTRY" && it.unlocked && it.status != "COMPLETED" },
                    "PHYSICAL_CHEMISTRY" to chapters.firstOrNull { it.subject == "PHYSICAL_CHEMISTRY" && it.unlocked && it.status != "COMPLETED" },
                    "ORGANIC_CHEMISTRY" to chapters.firstOrNull { it.subject == "ORGANIC_CHEMISTRY" && it.unlocked && it.status != "COMPLETED" }
                )

                val timeline = AIService.generateDailyTimeline(stats, activeMap, recovery)
                val risk = AIService.analyzeDeadlineAndPace(stats, chapters)

                _uiState.update { current ->
                    current.copy(
                        userStats = stats,
                        allChapters = chapters,
                        recoveryTasks = recovery,
                        activeChapters = activeMap,
                        todayTimeline = timeline,
                        riskAnalysis = risk
                    )
                }
            }
        }
    }

    fun selectTab(tab: String) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun checkAndPromptPermissions() {
        val context = getApplication<Application>().applicationContext
        val usageOk = AppBlockingManager.isUsagePermissionGranted(context)
        val overlayOk = AppBlockingManager.isOverlayPermissionGranted(context)
        val accessibilityOk = AppBlockingManager.isAccessibilityPermissionGranted(context)
        val micOk = androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (!usageOk || !overlayOk || !accessibilityOk || !micOk) {
            _uiState.update { it.copy(showPermissionsModal = true) }
        } else {
            _uiState.update { it.copy(showPermissionsModal = false) }
            // Start background floating island overlay
            try {
                CybFloatingIslandService.start(context)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun closePermissionsModal() {
        _uiState.update { it.copy(showPermissionsModal = false) }
    }

    fun toggleScreenMonitoring(enabled: Boolean) {
        _uiState.update { it.copy(optInScreenMonitoring = enabled) }
    }

    fun triggerStartFocusConfirmation(
        subject: String,
        chapterName: String,
        chapterId: Int,
        itemIndex: Int,
        taskType: String
    ) {
        _uiState.update {
            it.copy(
                showStartFocusModal = true,
                pendingFocusSubject = subject,
                pendingFocusChapterName = chapterName,
                pendingFocusChapterId = chapterId,
                pendingFocusItemIndex = itemIndex,
                pendingFocusTaskType = taskType
            )
        }
    }

    fun cancelStartFocus() {
        _uiState.update {
            it.copy(
                showStartFocusModal = false,
                pendingFocusSubject = null,
                pendingFocusChapterName = null,
                pendingFocusChapterId = null,
                pendingFocusItemIndex = null,
                pendingFocusTaskType = null
            )
        }
    }

    fun confirmStartFocus() {
        val st = _uiState.value
        val subject = st.pendingFocusSubject ?: "PHYSICS"
        val chapterName = st.pendingFocusChapterName ?: "General Study"
        val chapterId = st.pendingFocusChapterId ?: 1
        val itemIndex = st.pendingFocusItemIndex ?: 1
        val taskType = st.pendingFocusTaskType ?: "LECTURE"

        val targetDuration = if (taskType == "LECTURE") {
            st.userStats.effectiveLectureMinutes // 96 minutes (2 hr @ 1.25x)
        } else {
            45
        }

        _uiState.update {
            it.copy(
                showStartFocusModal = false,
                isFocusModeActive = true,
                selectedTab = "FOCUS",
                activeFocusSession = ActiveFocusSessionData(
                    subject = subject,
                    chapterName = chapterName,
                    chapterId = chapterId,
                    itemIndex = itemIndex,
                    taskType = taskType,
                    targetDurationMinutes = targetDuration,
                    elapsedSeconds = 0,
                    isRunning = true,
                    baseDurationHours = st.userStats.lectureBaseHours,
                    playbackSpeed = st.userStats.playbackSpeed
                )
            )
        }

        startFocusTimerLoop()
        AppBlockingManager.setFocusSessionActive(getApplication(), true)
        // Start Foreground Focus Monitor
        try {
            FocusMonitorService.startService(getApplication())
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private var focusTimerJob: Job? = null

    private fun startFocusTimerLoop() {
        focusTimerJob?.cancel()
        focusTimerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                updateFocusTick()
            }
        }
    }

    private fun stopFocusTimerLoop() {
        focusTimerJob?.cancel()
        focusTimerJob = null
    }

    fun minimizeFocus() {
        _uiState.update {
            it.copy(
                isFocusModeActive = false,
                selectedTab = "HOME"
            )
        }
    }

    fun startFocusSession(
        subject: String,
        chapterName: String,
        chapterId: Int,
        itemIndex: Int,
        taskType: String,
        durationMinutes: Int = 96
    ) {
        triggerStartFocusConfirmation(subject, chapterName, chapterId, itemIndex, taskType)
    }

    fun startFocusSessionDirect(
        subject: String,
        chapterName: String,
        chapterId: Int,
        itemIndex: Int,
        taskType: String,
        durationMinutes: Int = 96
    ) {
        val st = _uiState.value
        val targetDuration = if (taskType == "LECTURE") {
            st.userStats.effectiveLectureMinutes
        } else {
            45
        }

        _uiState.update {
            it.copy(
                showStartFocusModal = false,
                isFocusModeActive = true,
                selectedTab = "FOCUS",
                activeFocusSession = ActiveFocusSessionData(
                    subject = subject,
                    chapterName = chapterName,
                    chapterId = chapterId,
                    itemIndex = itemIndex,
                    taskType = taskType,
                    targetDurationMinutes = targetDuration,
                    elapsedSeconds = 0,
                    isRunning = true,
                    baseDurationHours = st.userStats.lectureBaseHours,
                    playbackSpeed = st.userStats.playbackSpeed
                )
            )
        }

        startFocusTimerLoop()
        AppBlockingManager.setFocusSessionActive(getApplication(), true)
        try {
            FocusMonitorService.startService(getApplication())
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    fun toggleFocusTimer() {
        val currentSession = _uiState.value.activeFocusSession ?: return
        if (currentSession.isRunning) {
            // PAUSE: freeze the wall-clock elapsed time into the snapshot
            val elapsedNow = ((System.currentTimeMillis() - currentSession.startedAtMs) / 1000L).toInt()
            _uiState.update {
                it.copy(
                    activeFocusSession = currentSession.copy(
                        isRunning = false,
                        elapsedSeconds = elapsedNow
                    )
                )
            }
            stopFocusTimerLoop()
            AppBlockingManager.setFocusSessionActive(getApplication(), false)
        } else {
            // RESUME: re-anchor the wall clock so paused time is never counted
            _uiState.update {
                it.copy(
                    activeFocusSession = currentSession.copy(
                        isRunning = true,
                        startedAtMs = System.currentTimeMillis() - currentSession.elapsedSeconds * 1000L
                    )
                )
            }
            startFocusTimerLoop()
            AppBlockingManager.setFocusSessionActive(getApplication(), true)
        }
    }

    fun updateFocusTick() {
        val currentSession = _uiState.value.activeFocusSession ?: return
        if (!currentSession.isRunning) return
        // Derive elapsed time from the wall clock instead of incrementing blindly;
        // a missed or doubled tick can no longer corrupt the study timer.
        val elapsedNow = ((System.currentTimeMillis() - currentSession.startedAtMs) / 1000L).toInt()
        if (elapsedNow != currentSession.elapsedSeconds) {
            _uiState.update {
                it.copy(
                    activeFocusSession = currentSession.copy(elapsedSeconds = elapsedNow)
                )
            }
        }
    }

    fun triggerDistractionAttempt(blockedApp: String = "Instagram") {
        _uiState.update {
            it.copy(
                distractionAttemptsCount = it.distractionAttemptsCount + 1,
                showDistractionIntervention = true
            )
        }
        // Speak Cyb voice distraction warning through phone speaker
        CybVoiceAssistantManager.speakDistractionWarning(blockedApp)
    }

    fun openCybVoiceAssistant() {
        CybVoiceAssistantManager.openVoiceAssistant()
    }

    fun startListeningCybVoice() {
        CybVoiceAssistantManager.startListeningForQuery()
    }

    fun stopListeningCybVoice() {
        CybVoiceAssistantManager.stopListening()
    }

    fun closeCybVoiceAssistant() {
        CybVoiceAssistantManager.closeVoiceAssistant()
    }

    fun speakCyb(text: String) {
        CybVoiceAssistantManager.speak(text)
    }

    fun dismissDistractionIntervention() {
        _uiState.update { it.copy(showDistractionIntervention = false) }
    }

    fun triggerEmergencyPause() {
        _uiState.update { it.copy(showEmergencyPauseDialog = true) }
    }

    fun confirmEmergencyPause(reason: String) {
        stopFocusTimerLoop()
        _uiState.update {
            it.copy(
                showEmergencyPauseDialog = false,
                isFocusModeActive = false,
                selectedTab = "HOME",
                activeFocusSession = null,
                toastMessage = "Session paused for: $reason"
            )
        }
        FocusMonitorService.stopService(getApplication())
        AppBlockingManager.setFocusSessionActive(getApplication(), false)
    }

    fun dismissEmergencyPause() {
        _uiState.update { it.copy(showEmergencyPauseDialog = false) }
    }

    fun finishFocusSession(confirmed: Boolean) {
        stopFocusTimerLoop()
        val session = _uiState.value.activeFocusSession ?: return
        val currentSt = _uiState.value

        if (!confirmed) {
            _uiState.update {
                it.copy(
                    isFocusModeActive = false,
                    selectedTab = "HOME",
                    activeFocusSession = null,
                    toastMessage = "Focus session cancelled."
                )
            }
            FocusMonitorService.stopService(getApplication())
            AppBlockingManager.setFocusSessionActive(getApplication(), false)
            return
        }

        // Run AI Verification Pipeline (Sections 5, 8, 9, 15)
        _uiState.update { it.copy(verificationPending = true) }

        viewModelScope.launch {
            val mins = maxOf(1, session.elapsedSeconds / 60)
            val telemetry = FocusTelemetry(
                subject = session.subject,
                chapterName = session.chapterName,
                taskType = session.taskType,
                itemIndex = session.itemIndex,
                sessionDurationMinutes = mins,
                targetDurationMinutes = session.targetDurationMinutes,
                playbackSpeed = session.playbackSpeed,
                distractionAttempts = currentSt.distractionAttemptsCount,
                optInScreenMonitoring = currentSt.optInScreenMonitoring
            )

            val decision = LectureVerificationEngine.evaluateLectureCompletion(
                telemetry = telemetry,
                userStats = currentSt.userStats
            )

            if (decision.status == "VERIFIED" || decision.recommendedAction == "COMPLETE_LECTURE") {
                val (msg, updatedChapter) = repository.completeTask(
                    chapterId = session.chapterId,
                    taskType = session.taskType,
                    durationMinutes = mins
                )

                // Only advance the daily mission when the completion actually progressed the chapter
                val madeProgress = updatedChapter != null && !msg.startsWith("All ")
                val newMissionCount = if (madeProgress) currentSt.missionCompletedCount + 1 else currentSt.missionCompletedCount
                val isMissionDone = newMissionCount >= currentSt.missionTotalTarget

                _uiState.update {
                    it.copy(
                        verificationPending = false,
                        verificationDecision = decision,
                        isFocusModeActive = false,
                        selectedTab = "HOME",
                        activeFocusSession = null,
                        missionCompletedCount = newMissionCount,
                        isStudyLockActive = !isMissionDone,
                        showMissionCompleteCelebration = isMissionDone,
                        toastMessage = if (isMissionDone) "🎉 ALL 5 MISSION LECTURES COMPLETE! STUDY LOCK RELEASED!" else msg
                    )
                }
                showFeedbackBanner(
                    message = if (isMissionDone) "Outstanding work! All 5 daily mission lectures completed—lock released!" else "Session Completed! Inspiring effort—you're one step closer to IIT JEE success! 🎯",
                    icon = if (isMissionDone) "🏆" else "🌟"
                )
            } else {
                _uiState.update {
                    it.copy(
                        verificationPending = false,
                        verificationDecision = decision,
                        toastMessage = "⚠️ AI Verification: ${decision.reason}"
                    )
                }
            }
            FocusMonitorService.stopService(getApplication())
            AppBlockingManager.setFocusSessionActive(getApplication(), false)
        }
    }

    fun dismissMissionCelebration() {
        _uiState.update { it.copy(showMissionCompleteCelebration = false) }
    }

    fun completeTaskDirect(chapterId: Int, taskType: String) {
        viewModelScope.launch {
            val duration = if (taskType == "LECTURE") _uiState.value.userStats.effectiveLectureMinutes else 45
            val (msg, updatedChapter) = repository.completeTask(chapterId, taskType, duration)
            val madeProgress = updatedChapter != null && !msg.startsWith("All ")
            val newMissionCount = if (madeProgress) _uiState.value.missionCompletedCount + 1 else _uiState.value.missionCompletedCount
            val isMissionDone = newMissionCount >= _uiState.value.missionTotalTarget
            _uiState.update {
                it.copy(
                    missionCompletedCount = newMissionCount,
                    isStudyLockActive = !isMissionDone,
                    showMissionCompleteCelebration = isMissionDone,
                    toastMessage = msg
                )
            }
            showFeedbackBanner(
                message = "Goal Met! Task marked complete. Keep up the high-focus momentum! 🚀",
                icon = "🔥"
            )
        }
    }

    fun updatePlaybackSettings(baseHours: Float, speed: Float) {
        viewModelScope.launch {
            repository.updatePlaybackSettings(baseHours, speed)
            val effective = ((baseHours * 60) / speed).toInt()
            _uiState.update {
                it.copy(toastMessage = "Lecture configuration updated: ${baseHours.toInt()}h @ ${speed}x ($effective min/lecture)")
            }
        }
    }

    fun askAiCoach(question: String, speakAnswer: Boolean = false) {
        if (question.isBlank()) return

        val updatedMessages = _uiState.value.aiCoachMessages + Pair("USER", question)
        _uiState.update { it.copy(aiCoachMessages = updatedMessages) }

        viewModelScope.launch {
            try {
                database.dao().insertChatMessage(
                    ChatMessageEntity(sender = "USER", content = question)
                )
            } catch (e: Exception) {}

            try {
                var answer: String? = null
                var senderTag = "CYBNATE"

                val app = getApplication<android.app.Application>()
                // 1. Check if Hugging Face Speech-to-Speech (https://github.com/huggingface/speech-to-speech) is enabled
                if (com.example.ai.HfSpeechToSpeechConfig.isEnabled(app)) {
                    val hfResult = com.example.ai.HfSpeechToSpeechClient.querySpeechPipeline(app, question)
                    if (hfResult.isSuccess && !hfResult.getOrNull().isNullOrBlank()) {
                        answer = hfResult.getOrThrow()
                        senderTag = "CYBNATE (HF S2S)"
                    }
                }

                // 2. Primary / Local Fallback
                if (answer.isNullOrBlank()) {
                    answer = AIService.answerStudyQuestion(
                        userQuery = question,
                        stats = _uiState.value.userStats,
                        allChapters = _uiState.value.allChapters,
                        dailyTasks = emptyList(),
                        context = app
                    )
                }

                val finalAnswer = answer
                _uiState.update {
                    it.copy(aiCoachMessages = it.aiCoachMessages + Pair(senderTag, finalAnswer))
                }
                try {
                    database.dao().insertChatMessage(
                        ChatMessageEntity(sender = senderTag, content = finalAnswer)
                    )
                } catch (e: Exception) {}

                if (speakAnswer) {
                    CybVoiceAssistantManager.speak(finalAnswer)
                }
            } catch (e: Exception) {
                val fallbackAnswer = "I ran into a temporary connection issue while reaching the AI engine. However, your study schedule and offline command center remain fully operational."
                _uiState.update {
                    it.copy(
                        aiCoachMessages = it.aiCoachMessages + Pair("CYBNATE", fallbackAnswer),
                        toastMessage = "AI Coach network notice: offline fallback used"
                    )
                }
                if (speakAnswer) {
                    CybVoiceAssistantManager.speak(fallbackAnswer)
                }
            }
        }
    }

    fun openAppPicker() {
        _uiState.update { it.copy(showDistractionAppPicker = true) }
    }

    fun closeAppPicker() {
        _uiState.update { it.copy(showDistractionAppPicker = false) }
    }

    fun toggleBlockedPackage(packageName: String) {
        val currentList = _uiState.value.customBlocklist.toMutableSet()
        if (currentList.contains(packageName)) {
            currentList.remove(packageName)
        } else {
            currentList.add(packageName)
        }
        AppBlockingManager.saveCustomBlockedPackages(getApplication(), currentList)
        _uiState.update { it.copy(customBlocklist = currentList) }
    }

    fun updateDeadline(newDeadline: String) {
        viewModelScope.launch {
            repository.updateDeadlineDate(newDeadline)
            _uiState.update { it.copy(toastMessage = "Deadline updated to $newDeadline") }
        }
    }

    fun resetProgress() {
        viewModelScope.launch {
            repository.resetAllProgress()
            _uiState.update {
                it.copy(
                    missionCompletedCount = 0,
                    isStudyLockActive = true,
                    toastMessage = "All study progress reset to initial syllabus state."
                )
            }
        }
    }

    fun toggleTheme() {
        val newDark = !_uiState.value.isDarkTheme
        _uiState.update { it.copy(isDarkTheme = newDark) }
        showFeedbackBanner(
            message = if (newDark) "Late-Night Eye Protection Active 🌙 High-contrast dark theme enabled." else "Bright Day Study Mode Active ☀️ High-contrast light theme enabled.",
            icon = if (newDark) "🌙" else "☀️"
        )
    }

    fun showFeedbackBanner(message: String, icon: String = "✨") {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    feedbackBannerMessage = message,
                    feedbackBannerIcon = icon
                )
            }
            delay(4000L)
            if (_uiState.value.feedbackBannerMessage == message) {
                _uiState.update { it.copy(feedbackBannerMessage = null) }
            }
        }
    }

    fun clearFeedbackBanner() {
        _uiState.update { it.copy(feedbackBannerMessage = null) }
    }

    fun showToast(msg: String) {
        _uiState.update { it.copy(toastMessage = msg) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        stopFocusTimerLoop()
    }
}
