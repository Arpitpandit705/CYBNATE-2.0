package com.example

import android.content.Intent
import android.Manifest
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.CybNateTheme
import com.example.viewmodel.CybNateViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: CybNateViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            com.example.service.CybFloatingIslandService.start(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        handleIntentExtra(intent)

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            val cybVoiceState by com.example.service.CybVoiceAssistantManager.voiceState.collectAsStateWithLifecycle()
            val context = LocalContext.current


            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { permissions ->
                viewModel.checkAndPromptPermissions()
            }

            LaunchedEffect(Unit) {
                val permissionsToRequest = mutableListOf<String>()
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && 
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (permissionsToRequest.isNotEmpty()) {
                    permissionLauncher.launch(permissionsToRequest.toTypedArray())
                } else {
                    viewModel.checkAndPromptPermissions()
                }
            }


            // Toast listener
            LaunchedEffect(state.toastMessage) {
                state.toastMessage?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearToast()
                }
            }

            CybNateTheme(darkTheme = state.isDarkTheme) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (!state.isFocusModeActive) {
                            Column {
                                // Persistent Music-Player-Style Study Bar
                                if (state.selectedTab != "FOCUS") {
                                    StudyMiniPlayer(
                                        session = state.activeFocusSession,
                                        onTogglePlay = { viewModel.toggleFocusTimer() },
                                        onExpandFocus = { viewModel.selectTab("FOCUS") }
                                    )
                                }

                                CybNateBottomNav(
                                    selectedTab = state.selectedTab,
                                    onTabSelected = { viewModel.selectTab(it) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(if (state.isFocusModeActive) PaddingValues() else innerPadding)
                    ) {
                        when (state.selectedTab) {
                            "HOME" -> HomeScreen(
                                state = state,
                                onStartFocusClicked = { subject, chapterName, id, itemIdx, taskType ->
                                    viewModel.startFocusSession(subject, chapterName, id, itemIdx, taskType)
                                },
                                onGoToPlan = { viewModel.selectTab("PLAN") },
                                onGoToSubjects = { viewModel.selectTab("SUBJECTS") },
                                onGoToCoach = { viewModel.selectTab("COACH") },
                                onOpenAppPicker = { viewModel.openAppPicker() },
                                onOpenCybVoice = { viewModel.openCybVoiceAssistant() }
                            )

                            "PLAN" -> PlanScreen(
                                timeline = state.todayTimeline,
                                recoveryTasks = state.recoveryTasks,
                                onStartFocus = { subject, chapterName, itemIdx, taskType ->
                                    val active = state.activeChapters[subject]
                                    val chapterId = active?.id ?: 1
                                    viewModel.startFocusSession(subject, chapterName, chapterId, itemIdx, taskType)
                                }
                            )

                            "SUBJECTS" -> SubjectsScreen(
                                chapters = state.allChapters,
                                organicActivated = state.userStats.organicActivated,
                                onStartTaskFocus = { subject, chapterName, id, itemIdx, taskType ->
                                    viewModel.startFocusSession(subject, chapterName, id, itemIdx, taskType)
                                },
                                onCompleteDirect = { id, taskType ->
                                    viewModel.completeTaskDirect(id, taskType)
                                },
                                onShowLockedMessage = { msg ->
                                    viewModel.showToast(msg)
                                }
                            )

                            "FOCUS" -> FocusScreen(
                                state = state,
                                session = state.activeFocusSession,
                                onToggleTimer = { viewModel.toggleFocusTimer() },
                                onTick = { viewModel.updateFocusTick() },
                                onFinishSession = { confirmed -> viewModel.finishFocusSession(confirmed) },
                                onEmergencyPause = { viewModel.triggerEmergencyPause() },
                                onMinimize = { viewModel.minimizeFocus() },
                                onStartMission = {
                                    val curPhysics = state.activeChapters["PHYSICS"] ?: state.allChapters.firstOrNull { it.subject == "PHYSICS" && it.unlocked }
                                    val curMath = state.activeChapters["MATHEMATICS"] ?: state.allChapters.firstOrNull { it.subject == "MATHEMATICS" && it.unlocked }
                                    val curInorganic = state.activeChapters["INORGANIC_CHEMISTRY"] ?: state.allChapters.firstOrNull { it.subject == "INORGANIC_CHEMISTRY" && it.unlocked }
                                    val curPhysical = state.activeChapters["PHYSICAL_CHEMISTRY"] ?: state.allChapters.firstOrNull { it.subject == "PHYSICAL_CHEMISTRY" && it.unlocked }
                                    when (state.missionCompletedCount) {
                                        0 -> viewModel.startFocusSession("PHYSICS", curPhysics?.chapterName ?: "Circular Motion", curPhysics?.id ?: 1, 1, "LECTURE")
                                        1 -> viewModel.startFocusSession("PHYSICS", curPhysics?.chapterName ?: "Circular Motion", curPhysics?.id ?: 1, 2, "LECTURE")
                                        2 -> viewModel.startFocusSession("MATHEMATICS", curMath?.chapterName ?: "Ch-04 : Trigonometric Functions", curMath?.id ?: 65, 1, "LECTURE")
                                        3 -> viewModel.startFocusSession("INORGANIC_CHEMISTRY", curInorganic?.chapterName ?: "Ch-02 : Chemical Bonding", curInorganic?.id ?: 55, 1, "LECTURE")
                                        else -> viewModel.startFocusSession("PHYSICAL_CHEMISTRY", curPhysical?.chapterName ?: "Ch - 03: Solutions", curPhysical?.id ?: 46, 1, "LECTURE")
                                    }
                                }
                            )

                            "PROGRESS" -> ProgressScreen(
                                stats = state.userStats,
                                chapters = state.allChapters
                            )

                            "COACH" -> AiCoachScreen(
                                messages = state.aiCoachMessages,
                                onSendMessage = { question -> viewModel.askAiCoach(question) },
                                onVoiceSpeak = { viewModel.openCybVoiceAssistant() }
                            )

                                                        "SETTINGS" -> SettingsScreen(
                                currentDeadline = state.userStats.deadlineDate,
                                lectureBaseHours = state.userStats.lectureBaseHours,
                                playbackSpeed = state.userStats.playbackSpeed,
                                isDarkTheme = state.isDarkTheme,
                                onToggleTheme = { viewModel.toggleTheme() },
                                onUpdateDeadline = { viewModel.updateDeadline(it) },
                                onUpdatePlaybackSettings = { hrs, spd -> viewModel.updatePlaybackSettings(hrs, spd) },
                                onResetProgress = { viewModel.resetProgress() },
                                onNavigateToVoiceEnrollment = { viewModel.selectTab("VOICE_ENROLLMENT") }
                            )
                            "VOICE_ENROLLMENT" -> VoiceEnrollmentScreen(
                                onNavigateBack = { viewModel.selectTab("SETTINGS") }
                            )


                            else -> HomeScreen(
                                state = state,
                                onStartFocusClicked = { subject, chapterName, id, itemIdx, taskType ->
                                    viewModel.startFocusSession(subject, chapterName, id, itemIdx, taskType)
                                },
                                onGoToPlan = { viewModel.selectTab("PLAN") },
                                onGoToSubjects = { viewModel.selectTab("SUBJECTS") },
                                onGoToCoach = { viewModel.selectTab("COACH") },
                                onOpenAppPicker = { viewModel.openAppPicker() },
                                onOpenCybVoice = { viewModel.openCybVoiceAssistant() }
                            )
                        }

                        // --- REAL-TIME OFFLINE NETWORK STATUS BANNER ---
                        if (!state.isOnline) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.TopCenter)
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                                shadowElevation = 4.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("📡", fontSize = 16.sp, modifier = Modifier.padding(end = 8.dp))
                                    Text(
                                        text = "Offline Mode: Background wake-word & study timer active locally.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }

                        // --- CUSTOM SUPPORTIVE FEEDBACK BANNER OVERLAY ---
                        CybFeedbackSnackbar(
                            message = state.feedbackBannerMessage,
                            icon = state.feedbackBannerIcon ?: "🌟",
                            onDismiss = { viewModel.clearFeedbackBanner() },
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 12.dp)
                        )

                        // --- DIALOG OVERLAYS (Sections 2, 3, 7, 12, 14) ---
                        if (state.showDistractionAppPicker) {
                            DistractionAppPickerModal(
                                selectedBlockedPackages = state.customBlocklist,
                                onTogglePackage = { pkg -> viewModel.toggleBlockedPackage(pkg) },
                                onDismiss = { viewModel.closeAppPicker() }
                            )
                        }
                        if (state.showStartFocusModal) {
                            StartFocusConfirmationDialog(
                                taskType = state.pendingFocusTaskType,
                                targetDurationMinutes = if (state.pendingFocusTaskType == "LECTURE") state.userStats.effectiveLectureMinutes else 45,
                                playbackSpeed = state.userStats.playbackSpeed,
                                onConfirm = { viewModel.confirmStartFocus() },
                                onCancel = { viewModel.cancelStartFocus() }
                            )
                        }

                        if (state.showPermissionsModal) {
                            PermissionsOnboardingDialog(
                                onDismiss = { viewModel.closePermissionsModal() }
                            )
                        }

                        if (state.showDistractionIntervention) {
                            DistractionInterventionDialog(
                                missionCompleted = state.missionCompletedCount,
                                missionTotal = state.missionTotalTarget,
                                onReturnToFocus = {
                                    viewModel.dismissDistractionIntervention()
                                    viewModel.selectTab("FOCUS")
                                }
                            )
                        }

                        if (state.showEmergencyPauseDialog) {
                            EmergencyPauseDialog(
                                onConfirmPause = { reason -> viewModel.confirmEmergencyPause(reason) },
                                onCancel = { viewModel.dismissEmergencyPause() }
                            )
                        }

                        if (state.showMissionCompleteCelebration) {
                            MissionCompleteCelebrationDialog(
                                onClaimReward = { viewModel.dismissMissionCelebration() }
                            )
                        }

                        if (cybVoiceState.isVoiceModalVisible) {
                            CybVoiceAssistantModal(
                                voiceState = cybVoiceState,
                                onStartListening = { viewModel.startListeningCybVoice() },
                                onStopListening = { viewModel.stopListeningCybVoice() },
                                onDismiss = { viewModel.closeCybVoiceAssistant() },
                                onAskQuestion = { question -> viewModel.askAiCoach(question, speakAnswer = true) }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntentExtra(intent)
    }

    private fun handleIntentExtra(intent: Intent?) {
        if (intent?.getBooleanExtra("TRIGGER_DISTRACTION_INTERVENTION", false) == true ||
            intent?.getBooleanExtra("SHOW_LOCK_SCREEN", false) == true) {
            val blockedPkg = intent.getStringExtra("BLOCKED_PACKAGE") ?: "Distracting App"
            // Consume the extras so a configuration change / activity recreation
            // with the same intent can't re-trigger a phantom intervention.
            intent.removeExtra("TRIGGER_DISTRACTION_INTERVENTION")
            intent.removeExtra("SHOW_LOCK_SCREEN")
            intent.removeExtra("BLOCKED_PACKAGE")
            viewModel.triggerDistractionAttempt(blockedPkg)
        }
    }
}
