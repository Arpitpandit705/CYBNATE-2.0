package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import com.example.service.AppBlockingManager
import com.example.service.CybFloatingIslandService
import com.example.service.CybVoiceAssistantManager

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d("BootReceiver", "Received boot action: $action")
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        // 1) Restore focus monitoring ONLY if a focus session was actually active
        //    when the device rebooted. Previously this always started, and a single
        //    shared try/catch meant one failure killed both service starts.
        try {
            if (AppBlockingManager.isFocusSessionActive(context)) {
                FocusMonitorServiceStart.run(context)
                Log.i("BootReceiver", "Focus monitor restored after reboot.")
            } else {
                Log.d("BootReceiver", "No active focus session; skipping monitor restore.")
            }
        } catch (e: Exception) {
            Log.e("BootReceiver", "Failed to restore focus monitor on boot", e)
        }

        // 2) Restart the Siri-style floating island only when the user opted into
        //    always-listen AND overlay permission is granted. Microphone-typed
        //    foreground services cannot be started from a background boot on
        //    Android 12+, so this start is guarded and failures are isolated.
        try {
            if (CybVoiceAssistantManager.isAlwaysListenEnabled(context) && Settings.canDrawOverlays(context)) {
                CybFloatingIslandService.start(context)
                Log.i("BootReceiver", "Floating island restored after reboot.")
            }
        } catch (e: Exception) {
            Log.e("BootReceiver", "Failed to restore floating island on boot", e)
        }
    }

    /** Isolated helper so a boot-time SecurityException never escapes the receiver. */
    private object FocusMonitorServiceStart {
        fun run(context: Context) {
            com.example.service.FocusMonitorService.startService(context)
        }
    }
}
