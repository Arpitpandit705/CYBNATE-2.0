import re

with open('app/src/main/java/com/example/service/CybVoiceAssistantManager.kt', 'r') as f:
    content = f.read()

content = content.replace("""                if (detectedText.isNotBlank()) {
                    processSpokenQuery(detectedText)
                } else {
                    // Turn mic completely OFF
                    stopListening()
                }""", """                if (detectedText.isNotBlank()) {
                    processSpokenQuery(detectedText)
                } else {
                    restartWakeWordListeningIfNeeded()
                }""")

with open('app/src/main/java/com/example/service/CybVoiceAssistantManager.kt', 'w') as f:
    f.write(content)
