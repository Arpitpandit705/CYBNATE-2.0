# CybNate — Fixes & Improvements Applied

## 1. Voice Assistant (now Siri-style)

### Wake words — `CybVoiceAssistantManager.kt`
The wake-word engine now responds to all of these, exactly like "Hey Siri":
- **"Hey CybNate"**, **"Hello CybNate"**, **"Hi CybNate"**, **"OK CybNate"**
- **"Hey Cyb"**, **"Hello Cyb"**, or just **"Cyb"** / **"CybNate"** on their own
- Common speech-recognizer mishearings: *cibnate, syb nate, sib nate, cyber nate, cyb net, signate, side nate, cynate…*
- You can also speak the command in the same breath: *"Hey CybNate, what's my progress?"* works in one shot.

### Voice bugs fixed
1. **Assistant sheet never opened** — `isVoiceModalVisible` was never set to `true` anywhere in the app, so tapping the mic button woke the recognizer but the UI never appeared. Fixed in `openVoiceAssistant()`.
2. **Infinite restart loop without mic permission** — `ERROR_INSUFFICIENT_PERMISSIONS` fell into the generic retry branch and restarted the recognizer every 300 ms forever (battery drain). It now stops cleanly. `ERROR_TOO_MANY_REQUESTS` gets a 5 s backoff; network/server errors get a 1.5 s warm restart.
3. **AI answers silently dropped** — if the TTS engine wasn't ready yet, spoken answers were discarded. They are now queued (`pendingSpeech`) and spoken as soon as the engine initializes.
4. **Wake lock held forever** — the partial wake lock was acquired with no timeout. It now uses a 1-hour safety timeout, re-acquired on every listening restart.
5. **Siri-style wake chime** — replaced the single flat beep with an ascending double tone, and the tone generator is now released (previously leaked).
6. **Polite dismissals** — saying *"never mind"*, *"cancel"*, *"thanks"*, *"bye"* etc. now closes the mic with a short acknowledgement instead of sending junk text to the AI.

### New voice commands — `CybVoiceCommandDispatcher.kt`
- **"What can you do?" / "help"** — assistant lists its capabilities.
- **"Dark theme" / "Light theme"** — switches the app theme by voice.
- Removed a redundant safe-call (`stats?.currentStreak`) that produced a compiler warning.

## 2. Logic errors fixed elsewhere
1. **`BootReceiver.kt`** — both services were started inside one `try/catch`; since a microphone-type foreground service cannot legally start from a background boot on Android 12+, the first failure also killed the focus-monitor start. Now each start is isolated, the focus monitor only restarts if a session was actually active at reboot, and the island only restarts when always-listen is enabled AND overlay permission exists.
2. **`CybNateViewModel.kt` focus timer drift** — elapsed time was a naive `+1` increment per loop tick; any missed/doubled tick (backgrounding, GC, doze) corrupted the study timer. It's now anchored to the wall clock (`startedAtMs`) with proper pause/resume re-anchoring — drift-proof.
3. **`MainActivity.kt` phantom interventions** — the distraction-intervention intent extras survived configuration changes, re-triggering the lock dialog on rotation. Extras are now consumed with `removeExtra()` after handling.
4. Removed an unused variable in `confirmEmergencyPause()`.

## 3. Theme improvements ("Aurora Mint")
- **`Color.kt`** — deeper space-charcoal backgrounds (`#0B0E13`), refined mint primary (`#2BE080`), new teal + violet supporting accents, ready-to-use brand gradients (`CybAccentGradient`, `CybHeroGradient`), and a fully reworked high-contrast light palette. All original token names kept, so no screen code broke.
- **`Theme.kt`** — full Material 3 color roles (surface containers, tertiary, error, inverse, scrim), and the theme now defaults to the system dark/light setting.
- **`Type.kt`** — replaced the template stub with a complete M3 type scale (display → label).
- **`themes.xml`** — dark window background (no more white flash on cold launch), transparent status/navigation bars.
- **`colors.xml`** — removed leftover purple template colors; added brand colors.
- **`SettingsScreen.kt`** — the always-listen section now tells the user exactly which wake phrases work.

## Verification
`verify_cybnate.py` (included output) — 22 wake phrases detected, 0 false positives on 9 lookalike phrases, balanced braces/parens across all Kotlin files, all XML well-formed.
