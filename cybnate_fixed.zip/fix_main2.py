with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = '''                                onNavigateToVoiceEnrollment = { viewModel.selectTab("VOICE_ENROLLMENT") }
                            )'''
replacement = '''                                onNavigateToVoiceEnrollment = { viewModel.selectTab("VOICE_ENROLLMENT") }
                            )
                            "VOICE_ENROLLMENT" -> VoiceEnrollmentScreen(
                                onNavigateBack = { viewModel.selectTab("SETTINGS") }
                            )'''

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
