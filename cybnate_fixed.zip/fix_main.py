import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Let's just do a manual search and replace because the regex failed
content = content.replace('''                            "VOICE_ENROLLMENT" -> VoiceEnrollmentScreen(
                                onNavigateBack = { viewModel.selectTab("SETTINGS") }
                            ) },
                                onUpdateDeadline = { newDeadline -> viewModel.updateDeadline(newDeadline) },
                                onUpdatePlaybackSettings = { baseHours, speed ->
                                    viewModel.updatePlaybackSettings(baseHours, speed)
                                },
                                onResetProgress = { viewModel.resetProgress() }
                            )''', '')

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
