with open('app/src/main/java/com/example/ui/components/StudyLockModals.kt', 'r') as f:
    content = f.read()

target = """                Text(
                    "This application is restricted during your active study mission. Cyb has intercepted this action.",
                    color = TextPrimary,
                    fontSize = 14.sp
                )"""

replacement = """                Text(
                    "This application is restricted during your active study mission. Cyb has intercepted this action.",
                    color = TextPrimary,
                    fontSize = 14.sp
                )
                
                AlternatingVideoPlayer()
"""

if "AlternatingVideoPlayer" not in content:
    content = content.replace(target, replacement)
    
with open('app/src/main/java/com/example/ui/components/StudyLockModals.kt', 'w') as f:
    f.write(content)
