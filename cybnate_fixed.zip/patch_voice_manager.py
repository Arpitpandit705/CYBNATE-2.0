import re

with open('app/src/main/java/com/example/service/CybVoiceAssistantManager.kt', 'r') as f:
    content = f.read()

helper = """
    private fun restartWakeWordListeningIfNeeded() {
        val ctx = appContext
        if (ctx != null && isAlwaysListenEnabled(ctx)) {
            mainHandler.postDelayed({
                startWakeWordListening()
            }, 500)
        } else {
            stopListening()
        }
    }
"""

if "fun restartWakeWordListeningIfNeeded" not in content:
    content = content.replace("    fun speak(text: String, isGreeting: Boolean = false) {", helper + "\n    fun speak(text: String, isGreeting: Boolean = false) {")

content = content.replace("""        if (!isTtsReady || tts == null) {
            Log.w(TAG, "TTS not ready: $text")
            return
        }""", """        if (!isTtsReady || tts == null) {
            Log.w(TAG, "TTS not ready: $text")
            restartWakeWordListeningIfNeeded()
            return
        }""")

content = content.replace("""        // Never speak if empty or if user is uttering the "cybnate" wake word
        if (cleanText.isBlank() || cleanText.equals("cybnate", ignoreCase = true) || cleanText.equals("cyb nate", ignoreCase = true)) {
            return
        }""", """        // Never speak if empty or if user is uttering the "cybnate" wake word
        if (cleanText.isBlank() || cleanText.equals("cybnate", ignoreCase = true) || cleanText.equals("cyb nate", ignoreCase = true)) {
            restartWakeWordListeningIfNeeded()
            return
        }""")

content = content.replace("""        val speechFormattedText = sanitizeForSpeech(cleanText)
        if (speechFormattedText.isBlank()) return""", """        val speechFormattedText = sanitizeForSpeech(cleanText)
        if (speechFormattedText.isBlank()) {
            restartWakeWordListeningIfNeeded()
            return
        }""")


with open('app/src/main/java/com/example/service/CybVoiceAssistantManager.kt', 'w') as f:
    f.write(content)
