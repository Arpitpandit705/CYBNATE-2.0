import re

files = [
    'app/src/main/java/com/example/ui/screens/HomeScreen.kt',
    'app/src/main/java/com/example/ai/AIService.kt',
    'app/src/main/java/com/example/MainActivity.kt'
]

replacements = {
    '"Trigonometric Functions"': '"Ch-04 : Trigonometric Functions"',
    '"Chemical Bonding"': '"Ch-02 : Chemical Bonding"',
    '"Solutions"': '"Ch - 03: Solutions"'
}

for file_path in files:
    with open(file_path, 'r') as f:
        content = f.read()
    for old, new in replacements.items():
        content = content.replace(old, new)
    
    # Custom for HomeScreen's static string
    content = content.replace("1 lecture/day • Trigonometric Functions", "1 lecture/day • Ch-04 : Trigonometric Functions")
    content = content.replace("1 lecture/day • Chemical Bonding", "1 lecture/day • Ch-02 : Chemical Bonding")
    content = content.replace("1 lecture/day • Solutions", "1 lecture/day • Ch - 03: Solutions")
    
    with open(file_path, 'w') as f:
        f.write(content)
