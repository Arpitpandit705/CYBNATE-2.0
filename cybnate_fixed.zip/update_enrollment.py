import re

with open('app/src/main/java/com/example/ui/screens/VoiceEnrollmentScreen.kt', 'r') as f:
    content = f.read()

import_sp = "import androidx.compose.ui.platform.LocalContext\nimport android.content.Context\n"
if "LocalContext" not in content:
    content = content.replace("import androidx.compose.ui.Modifier", import_sp + "import androidx.compose.ui.Modifier")

setup_context = """
    val context = LocalContext.current
    var step by remember { mutableStateOf(0) }
"""
content = content.replace("    var step by remember { mutableStateOf(0) }", setup_context)

done_btn = """                    Button(
                        onClick = {
                            context.getSharedPreferences("cybnate_voice_prefs", Context.MODE_PRIVATE)
                                .edit()
                                .putBoolean("voice_enrolled", true)
                                .apply()
                            onNavigateBack()
                        },"""

content = content.replace("""                    Button(
                        onClick = onNavigateBack,""", done_btn)

with open('app/src/main/java/com/example/ui/screens/VoiceEnrollmentScreen.kt', 'w') as f:
    f.write(content)
