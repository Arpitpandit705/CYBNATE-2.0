if [ -f "/app/.env" ]; then
    echo ".env exists in /app"
    cat /app/.env
else
    echo ".env not found in /app"
fi
