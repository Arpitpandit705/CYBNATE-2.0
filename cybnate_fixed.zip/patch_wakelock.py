import re

with open('app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()

if "android.permission.WAKE_LOCK" not in content:
    content = content.replace("<uses-permission android:name=\"android.permission.INTERNET\" />", "<uses-permission android:name=\"android.permission.INTERNET\" />\n    <uses-permission android:name=\"android.permission.WAKE_LOCK\" />")

with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/service/CybVoiceAssistantManager.kt', 'r') as f:
    content = f.read()

if "android.os.PowerManager" not in content:
    content = content.replace("import android.os.Looper", "import android.os.Looper\nimport android.os.PowerManager")

wakelock_vars = """    private var appContext: Context? = null
    private var wakeIntent: Intent? = null
    private var partialWakeLock: PowerManager.WakeLock? = null"""

if "partialWakeLock: PowerManager.WakeLock?" not in content:
    content = content.replace("""    private var appContext: Context? = null
    private var wakeIntent: Intent? = null""", wakelock_vars)

update_wakelock = """
    private fun updateWakeLock(context: Context, enabled: Boolean) {
        try {
            if (partialWakeLock == null) {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                partialWakeLock = powerManager?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "CybNate::VoiceAssistantWakeLock"
                )?.apply {
                    setReferenceCounted(false)
                }
            }
            if (enabled) {
                if (partialWakeLock?.isHeld == false) {
                    partialWakeLock?.acquire()
                }
            } else {
                if (partialWakeLock?.isHeld == true) {
                    partialWakeLock?.release()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating WakeLock", e)
        }
    }
"""

if "fun updateWakeLock" not in content:
    content = content.replace("    fun isAlwaysListenEnabled(context: Context): Boolean {", update_wakelock + "\n    fun isAlwaysListenEnabled(context: Context): Boolean {")

toggle_listen = """    fun setAlwaysListenEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ALWAYS_LISTEN, enabled)
            .apply()
            
        updateWakeLock(context, enabled)

        if (!enabled) {"""

if "updateWakeLock(context, enabled)" not in content:
    content = content.replace("""    fun setAlwaysListenEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ALWAYS_LISTEN, enabled)
            .apply()

        if (!enabled) {""", toggle_listen)
        
    content = content.replace("""    fun setAlwaysListenEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ALWAYS_LISTEN, enabled)
            .apply()
        if (!enabled) {""", toggle_listen)


init_wake_lock = """
        this.appContext = context
        this.onUserSpokeCallback = onUserSpoke
        
        // Setup wakelock matching current state
        updateWakeLock(context, isAlwaysListenEnabled(context))
"""

content = content.replace("""
        this.appContext = context
        this.onUserSpokeCallback = onUserSpoke
""", init_wake_lock)


with open('app/src/main/java/com/example/service/CybVoiceAssistantManager.kt', 'w') as f:
    f.write(content)

