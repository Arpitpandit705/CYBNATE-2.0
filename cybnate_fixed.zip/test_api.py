import json
import os
import urllib.request

key = os.environ.get("GEMINI_API_KEY2") or os.environ.get("GEMINI_API_KEY")
if not key:
    raise SystemExit("Set GEMINI_API_KEY2 (or GEMINI_API_KEY) before running this script.")

url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + key
data = json.dumps({"contents": [{"parts": [{"text": "Hello, answer in 3 words"}]}]}).encode("utf-8")
req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})

try:
    with urllib.request.urlopen(req) as response:
        print(response.read().decode("utf-8"))
except Exception as e:
    print("Error:", e)
