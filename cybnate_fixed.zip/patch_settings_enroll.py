import re

with open('app/src/main/java/com/example/ui/screens/SettingsScreen.kt', 'r') as f:
    content = f.read()

target = """                            onCheckedChange = { isChecked ->
                                alwaysListenWakeWord = isChecked
                                CybVoiceAssistantManager.setAlwaysListenEnabled(context, isChecked)
                            },"""

replacement = """                            onCheckedChange = { isChecked ->
                                val prefs = context.getSharedPreferences("cybnate_voice_prefs", Context.MODE_PRIVATE)
                                val isEnrolled = prefs.getBoolean("voice_enrolled", false)
                                
                                if (isChecked && !isEnrolled) {
                                    android.widget.Toast.makeText(context, "Voice Blueprint required. Please enroll first.", android.widget.Toast.LENGTH_LONG).show()
                                    onNavigateToVoiceEnrollment()
                                } else {
                                    alwaysListenWakeWord = isChecked
                                    CybVoiceAssistantManager.setAlwaysListenEnabled(context, isChecked)
                                }
                            },"""

content = content.replace(target, replacement)

# Let's also update the "ENROLL VOICE BIOMETRIC" button text to show if enrolled
target_btn = """                    Button(
                        onClick = onNavigateToVoiceEnrollment,"""

replacement_btn = """                    val prefs = context.getSharedPreferences("cybnate_voice_prefs", Context.MODE_PRIVATE)
                    val isEnrolled = prefs.getBoolean("voice_enrolled", false)
                    
                    Button(
                        onClick = onNavigateToVoiceEnrollment,"""
                        
target_btn_text = """Text("ENROLL VOICE BIOMETRIC", color = CybNateGreen, fontWeight = FontWeight.Bold)"""
replacement_btn_text = """Text(if (isEnrolled) "UPDATE VOICE BIOMETRIC" else "ENROLL VOICE BIOMETRIC", color = CybNateGreen, fontWeight = FontWeight.Bold)"""

content = content.replace(target_btn, replacement_btn)
content = content.replace(target_btn_text, replacement_btn_text)


with open('app/src/main/java/com/example/ui/screens/SettingsScreen.kt', 'w') as f:
    f.write(content)
