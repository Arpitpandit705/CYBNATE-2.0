import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

import_statement = "import com.example.ui.screens.VoiceEnrollmentScreen\n"
if "VoiceEnrollmentScreen" not in content:
    content = content.replace("import com.example.ui.screens.SettingsScreen", "import com.example.ui.screens.SettingsScreen\n" + import_statement)

settings_screen_case = """                            "SETTINGS" -> SettingsScreen(
                                currentDeadline = state.userStats.targetDeadline,
                                lectureBaseHours = state.userStats.lectureBaseHours,
                                playbackSpeed = state.userStats.playbackSpeed,
                                isDarkTheme = state.isDarkTheme,
                                onToggleTheme = { viewModel.toggleTheme() },
                                onUpdateDeadline = { viewModel.updateDeadline(it) },
                                onUpdatePlaybackSettings = { hrs, spd -> viewModel.updatePlaybackSettings(hrs, spd) },
                                onResetProgress = { viewModel.resetProgress() },
                                onNavigateToVoiceEnrollment = { viewModel.selectTab("VOICE_ENROLLMENT") }
                            )
                            "VOICE_ENROLLMENT" -> VoiceEnrollmentScreen(
                                onNavigateBack = { viewModel.selectTab("SETTINGS") }
                            )"""

content = re.sub(r'"SETTINGS" -> SettingsScreen\([^)]+\)', settings_screen_case, content)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
