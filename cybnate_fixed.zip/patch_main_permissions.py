import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

import_stmt = """import android.Manifest
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
"""

if "import android.Manifest" not in content:
    content = content.replace("import android.os.Bundle\n", import_stmt + "import android.os.Bundle\n")

launcher_code = """
            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { permissions ->
                viewModel.checkAndPromptPermissions()
            }

            LaunchedEffect(Unit) {
                val permissionsToRequest = mutableListOf<String>()
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && 
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (permissionsToRequest.isNotEmpty()) {
                    permissionLauncher.launch(permissionsToRequest.toTypedArray())
                } else {
                    viewModel.checkAndPromptPermissions()
                }
            }
"""

content = re.sub(r'            // On initial launch check OS permissions\n            LaunchedEffect\(Unit\) \{\n                viewModel\.checkAndPromptPermissions\(\)\n            \}', launcher_code, content)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
