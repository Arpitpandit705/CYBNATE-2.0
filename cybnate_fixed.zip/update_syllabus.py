import re

physics_names = [
    "Circular Motion", "Work Power Energy", "Center of Mass", "Rotational Motion",
    "Oscillation", "Kinetic Theory and Thermodynamic", "Mechanical prop of solid",
    "Thermal property of mater", "Mechanical Properties of Fluids", "Waves",
    "Electric Charges & Fields", "Modern Physics", "Current Electricity", "Capacitor",
    "Wave Optics", "Gravitation", "Magnetism", "Electromagnetic Wave", "Semiconductor",
    "Electromagnetic Induction", "Error & Measurement", "Alternating Current",
    "Ray Optics", "Unit & Dimension"
]

organic_names = [
    "Ch- 01 : IUPAC Nomenclature", "Ch- 02 : General Organic Chemistry", "Ch- 03 : Isomerism",
    "Ch- 04 : Hydrocarbon", "Ch- 05 : Haloalkanes And Haloarenes", "Ch- 06 : Alcohols, Phenols And Ethers",
    "Ch- 07 : Amines", "Ch- 08 : Aldehyde, Ketone & Carboxylic Acid", "Ch- 09 : Biomolecules",
    "Ch- 10 : Chemistry in Everyday Life", "Ch- 11 : Polymer", "Ch- 12 : Environmental Chemistry"
]

physical_names = [
    "Ch - 03: Solutions", "Ch - 04: Chemical Kinetics", "Ch - 05: Thermodynamics",
    "Ch - 06: Chemical Equilibrium", "Ch - 07: Ionic Equilibrium", "Ch - 08: Electrochemistry",
    "Ch - 09: Structure of Atom"
]

inorganic_names = [
    "Ch-02 : Chemical Bonding", "Ch-03 : Coordination Compounds", "Ch-04 : P-block Elements",
    "Ch-05 : The d and f-Block Elements", "Ch-06 : Principles of Qualitative Analysis:Salt analysis",
    "Ch-07 : Metallurgy", "Ch-08 : S Block", "Ch-09 : Hydrogen"
]

math_names = [
    "Ch-04 : Trigonometric Functions", "Ch-05 : Trigonometric Equation", "Ch-06 : Permutations and Combinations",
    "Ch-07 : Binomial Theorem", "Ch - 08 : Straight Lines", "Ch - 09 : Circles", "Ch-10 : Parabola",
    "Ch-11 : Ellipse", "Ch - 12 : Determinants", "Ch - 13 : Hyperbola", "Ch - 14 : Matrices", "Ch-15 : Sets",
    "Ch-16 : Relations and Functions", "Ch - 17 : Methods of Differentiation", "Ch-18 : Inverse Trigonometric Functions",
    "Ch-19 : Limit, Continuity and Differentiability", "Ch-20 : Indefinite Integration", "Ch-21 : Application of Derivatives",
    "Ch-22 : Definite Integration", "Ch-23 : Differential Equation", "Ch-24 : Application of integrals",
    "Ch-25 : Vector Algebra", "Ch-26 : Three Dimensional Geometry", "Ch-27 : Statistics", "Ch-28 : Probability",
    "Ch-29 : Complex Number", "Ch-30 : Solution of Triangle"
]

name_maps = {
    'PHYSICS': physics_names,
    'ORGANIC_CHEMISTRY': organic_names,
    'PHYSICAL_CHEMISTRY': physical_names,
    'INORGANIC_CHEMISTRY': inorganic_names,
    'MATHEMATICS': math_names
}

with open('app/src/main/java/com/example/data/InitialSyllabus.kt', 'r') as f:
    content = f.read()

def replacer(match):
    subject = match.group(1)
    chapterOrder = int(match.group(2))
    rest = match.group(3)
    
    # chapterOrder is 1-indexed, lists are 0-indexed
    new_name = name_maps[subject][chapterOrder - 1]
    
    # Reconstruct the line with the new chapterName
    # The original matched string looks like:
    # subject = "PHYSICS", chapterOrder = 1, chapterName = "Circular Motion"
    return f'subject = "{subject}", chapterOrder = {chapterOrder}, chapterName = "{new_name}"'

# Regex to match: subject = "XYZ", chapterOrder = 1, chapterName = "ABC"
pattern = r'subject\s*=\s*"([^"]+)",\s*chapterOrder\s*=\s*(\d+),\s*chapterName\s*=\s*"([^"]+)"'
new_content = re.sub(pattern, replacer, content)

with open('app/src/main/java/com/example/data/InitialSyllabus.kt', 'w') as f:
    f.write(new_content)

print("Updated syllabus.")
